import { createCanvas, type SKRSContext2D } from '@napi-rs/canvas';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const OUT_DIR = path.resolve(process.cwd(), 'public/assets/gifs');
fs.mkdirSync(OUT_DIR, { recursive: true });

const FRAMES = 32;
const FPS = 18;

type DrawFn = (ctx: SKRSContext2D, w: number, h: number, u: number) => void;

function rr(
  ctx: SKRSContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const rad = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function drawGardenBackdrop(
  ctx: SKRSContext2D,
  w: number,
  h: number,
  u: number,
  palette: { top: string; mid: string; bot: string; tableTop: string; tableBot: string; bokeh: string }
) {
  const phi = u * Math.PI * 2;
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, palette.top);
  bg.addColorStop(0.55, palette.mid);
  bg.addColorStop(1, palette.bot);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // Soft warm garden horizon / lantern glow
  const glowR = w * 0.52 * (0.96 + 0.04 * Math.sin(phi));
  const glow = ctx.createRadialGradient(w * 0.5, h * 0.48, 8, w * 0.5, h * 0.48, glowR);
  glow.addColorStop(0, palette.bokeh);
  glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);

  // Subtle garden foliage silhouettes at top corners
  ctx.save();
  ctx.fillStyle = 'rgba(16, 30, 22, 0.45)';
  const sway = Math.sin(phi) * 5;
  for (let i = 0; i < 5; i++) {
    ctx.save();
    ctx.translate(w * (0.04 + i * 0.06) + sway * 0.5, h * (0.05 + (i % 2) * 0.04));
    ctx.rotate(-0.4 + Math.sin(phi + i) * 0.05);
    ctx.beginPath();
    ctx.ellipse(0, 0, 32, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(w * (0.72 + i * 0.06) - sway * 0.5, h * (0.05 + ((i + 1) % 2) * 0.04));
    ctx.rotate(0.4 + Math.cos(phi + i) * 0.05);
    ctx.beginPath();
    ctx.ellipse(0, 0, 32, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Twinkling warm garden fairy-light bokeh
  for (let i = 0; i < 9; i++) {
    const bx = w * (0.08 + ((i * 0.115) % 0.86));
    const by = h * (0.1 + ((i * 0.13) % 0.34)) + Math.sin(phi + i * 1.1) * 3;
    const pulse = 0.72 + 0.28 * Math.sin(phi + i * 1.7);
    const rad = (14 + (i % 3) * 8) * pulse;
    const bglow = ctx.createRadialGradient(bx, by, 1, bx, by, rad);
    bglow.addColorStop(0, `rgba(255, 232, 172, ${0.42 * pulse})`);
    bglow.addColorStop(0.5, `rgba(246, 188, 102, ${0.14 * pulse})`);
    bglow.addColorStop(1, 'rgba(246, 188, 102, 0)');
    ctx.fillStyle = bglow;
    ctx.beginPath();
    ctx.arc(bx, by, rad, 0, Math.PI * 2);
    ctx.fill();
  }

  // Rustic wooden garden tabletop
  const tableY = h * 0.72;
  const tGrad = ctx.createLinearGradient(0, tableY, 0, h);
  tGrad.addColorStop(0, palette.tableTop);
  tGrad.addColorStop(1, palette.tableBot);
  ctx.fillStyle = tGrad;
  ctx.fillRect(0, tableY, w, h - tableY);

  // Subtle plank lines & top highlight
  ctx.strokeStyle = 'rgba(255, 234, 200, 0.12)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, tableY + 1);
  ctx.lineTo(w, tableY + 1);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(20, 12, 7, 0.28)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(0, tableY + (h - tableY) * 0.48);
  ctx.lineTo(w, tableY + (h - tableY) * 0.48);
  ctx.stroke();
}

function drawSteamWisps(
  ctx: SKRSContext2D,
  x: number,
  y: number,
  u: number,
  count: number,
  spread: number,
  rise: number,
  opacity = 0.58
) {
  const phi = u * Math.PI * 2;
  ctx.save();
  ctx.lineCap = 'round';
  for (let i = 0; i < count; i++) {
    const p = (u + i / count) % 1;
    const alpha = Math.sin(p * Math.PI) * opacity;
    const sx = x - spread / 2 + (count === 1 ? spread / 2 : (i / (count - 1)) * spread);
    const sy = y - p * rise;
    const wave = Math.sin(phi + i * 1.9 + p * 4) * 11;
    ctx.strokeStyle = `rgba(255, 249, 238, ${alpha.toFixed(3)})`;
    ctx.lineWidth = 4.2 - p * 2.2;
    ctx.beginPath();
    ctx.moveTo(sx, sy + 24);
    ctx.bezierCurveTo(sx - wave, sy + 8, sx + wave, sy - 10, sx - wave * 0.5, sy - 28);
    ctx.stroke();
  }
  ctx.restore();
}

function drawSparkles(
  ctx: SKRSContext2D,
  points: Array<[number, number]>,
  u: number,
  color = '255, 244, 210'
) {
  const phi = u * Math.PI * 2;
  for (let i = 0; i < points.length; i++) {
    const [sx, sy] = points[i];
    const tw = 0.15 + 0.85 * (0.5 + 0.5 * Math.sin(phi + i * 1.6));
    const r = 2 + tw * 2.4;
    ctx.fillStyle = `rgba(${color}, ${tw.toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(sx, sy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = `rgba(${color}, ${(tw * 0.65).toFixed(3)})`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(sx - r * 2.2, sy);
    ctx.lineTo(sx + r * 2.2, sy);
    ctx.moveTo(sx, sy - r * 2.2);
    ctx.lineTo(sx, sy + r * 2.2);
    ctx.stroke();
  }
}

function drawPlateShadow(ctx: SKRSContext2D, cx: number, cy: number, rx: number, ry: number) {
  ctx.save();
  ctx.fillStyle = 'rgba(15, 9, 5, 0.42)';
  ctx.beginPath();
  ctx.ellipse(cx, cy + 12, rx * 1.04, ry * 0.96, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawStonewarePlate(ctx: SKRSContext2D, cx: number, cy: number, rx: number, ry: number, rimColor = '#E9E1D5', innerColor = '#D8CEC0') {
  drawPlateShadow(ctx, cx, cy, rx, ry);
  const g = ctx.createLinearGradient(cx - rx, cy - ry, cx + rx, cy + ry);
  g.addColorStop(0, rimColor);
  g.addColorStop(1, '#C4B8A7');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = innerColor;
  ctx.beginPath();
  ctx.ellipse(cx, cy - 2, rx * 0.8, ry * 0.72, 0, 0, Math.PI * 2);
  ctx.fill();
}

// 1. HERO: Open-Air Garden Cafe at Twilight
const drawGardenHero: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, '#162821');
  sky.addColorStop(0.42, '#254236');
  sky.addColorStop(0.72, '#43553E');
  sky.addColorStop(1, '#261D17');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);

  // Golden dusk glow
  const sunGlow = ctx.createRadialGradient(w * 0.5, h * 0.56, 12, w * 0.5, h * 0.56, w * 0.55);
  sunGlow.addColorStop(0, 'rgba(249, 200, 128, 0.36)');
  sunGlow.addColorStop(0.55, 'rgba(227, 152, 92, 0.14)');
  sunGlow.addColorStop(1, 'rgba(227, 152, 92, 0)');
  ctx.fillStyle = sunGlow;
  ctx.fillRect(0, 0, w, h);

  // Swaying garden hedges & trees
  for (let layer = 0; layer < 2; layer++) {
    ctx.fillStyle = layer === 0 ? 'rgba(22, 40, 31, 0.78)' : 'rgba(15, 29, 22, 0.9)';
    const sway = Math.sin(phi + layer * 1.4) * 6;
    ctx.beginPath();
    ctx.moveTo(0, h * 0.72);
    for (let x = 0; x <= w; x += w / 10) {
      const bh = h * (layer === 0 ? 0.53 : 0.6) + Math.sin(x * 0.015 + layer * 2.1) * 18;
      ctx.quadraticCurveTo(x + sway, bh - 26, x + w / 10, bh);
    }
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();
  }

  // Overhanging leafy garden branches
  const bSway = Math.sin(phi) * 5;
  ctx.fillStyle = '#12221B';
  for (let i = 0; i < 7; i++) {
    ctx.save();
    ctx.translate(w * (0.04 + i * 0.065) + bSway * 0.5, h * (0.06 + (i % 2) * 0.045));
    ctx.rotate(-0.35 + Math.sin(phi + i) * 0.06);
    ctx.beginPath();
    ctx.ellipse(0, 0, 36, 13, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(w * (0.62 + i * 0.062) - bSway * 0.5, h * (0.05 + (i % 2) * 0.045));
    ctx.rotate(0.35 + Math.cos(phi + i) * 0.06);
    ctx.beginPath();
    ctx.ellipse(0, 0, 36, 13, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Catenary warm fairy-light strings
  const drawStrand = (y0: number, ym: number, y1: number, count: number, offset: number) => {
    const sag = Math.sin(phi + offset) * 3;
    ctx.strokeStyle = 'rgba(20, 18, 15, 0.72)';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(0, y0);
    ctx.quadraticCurveTo(w * 0.5, ym + sag, w, y1);
    ctx.stroke();

    for (let i = 1; i <= count; i++) {
      const p = i / (count + 1);
      const bx = 2 * (1 - p) * p * (w * 0.5) + p * p * w;
      const by = (1 - p) * (1 - p) * y0 + 2 * (1 - p) * p * (ym + sag) + p * p * y1 + 7;
      const fl = 0.8 + 0.2 * Math.sin(phi + i * 1.4 + offset);

      const g = ctx.createRadialGradient(bx, by, 1, bx, by, 28 * fl);
      g.addColorStop(0, `rgba(255, 236, 178, ${0.95 * fl})`);
      g.addColorStop(0.35, `rgba(248, 192, 108, ${0.42 * fl})`);
      g.addColorStop(1, 'rgba(248, 192, 108, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(bx, by, 28 * fl, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FFF6DA';
      ctx.beginPath();
      ctx.arc(bx, by, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  };
  drawStrand(h * 0.14, h * 0.34, h * 0.12, 10, 0);
  drawStrand(h * 0.24, h * 0.42, h * 0.21, 8, 2.1);

  // Drifting fireflies (seamless orbital loop)
  for (let i = 0; i < 16; i++) {
    const fx = w * (0.08 + ((i * 0.061) % 0.84)) + Math.sin(phi + i * 1.7) * 18;
    const fy = h * (0.34 + ((i * 0.047) % 0.32)) + Math.cos(phi + i * 1.3) * 12;
    const alpha = 0.2 + 0.65 * (0.5 + 0.5 * Math.sin(phi + i * 2.2));
    ctx.fillStyle = `rgba(255, 228, 150, ${alpha.toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(fx, fy, 2.4 + (i % 2), 0, Math.PI * 2);
    ctx.fill();
  }

  // Open-air wooden garden table
  const tableY = h * 0.72;
  const tg = ctx.createLinearGradient(0, tableY, 0, h);
  tg.addColorStop(0, '#624530');
  tg.addColorStop(0.22, '#4C3524');
  tg.addColorStop(1, '#2B1C12');
  ctx.fillStyle = tg;
  ctx.fillRect(0, tableY, w, h - tableY);

  // Warm garden lantern on right
  const lx = w * 0.78;
  const ly = tableY - 72;
  const lp = 0.88 + 0.12 * Math.sin(phi * 2);
  const lg = ctx.createRadialGradient(lx, ly + 30, 4, lx, ly + 30, 100 * lp);
  lg.addColorStop(0, 'rgba(255, 218, 138, 0.82)');
  lg.addColorStop(0.45, 'rgba(245, 165, 80, 0.26)');
  lg.addColorStop(1, 'rgba(245, 165, 80, 0)');
  ctx.fillStyle = lg;
  ctx.beginPath();
  ctx.arc(lx, ly + 30, 100 * lp, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#211813';
  rr(ctx, lx - 24, ly, 48, 66, 8);
  ctx.fill();
  ctx.fillStyle = '#FFE3A8';
  rr(ctx, lx - 16, ly + 10, 32, 44, 5);
  ctx.fill();
  // Candle flame inside lantern
  ctx.fillStyle = '#FFF9E6';
  ctx.beginPath();
  ctx.ellipse(lx, ly + 36, 5, 10 + Math.sin(phi * 2) * 1.5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Foreground steaming ceramic coffee cup
  const cx = w * 0.36;
  const cy = tableY + 26;
  drawStonewarePlate(ctx, cx, cy + 26, 78, 17);

  ctx.strokeStyle = '#EFE9DF';
  ctx.lineWidth = 9;
  ctx.beginPath();
  ctx.arc(cx + 52, cy - 12, 20, -Math.PI * 0.45, Math.PI * 0.45);
  ctx.stroke();

  const cg = ctx.createLinearGradient(cx - 52, cy - 48, cx + 52, cy + 24);
  cg.addColorStop(0, '#F8F3EB');
  cg.addColorStop(1, '#CFC4B5');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.moveTo(cx - 54, cy - 46);
  ctx.lineTo(cx + 54, cy - 46);
  ctx.quadraticCurveTo(cx + 48, cy + 24, cx, cy + 24);
  ctx.quadraticCurveTo(cx - 48, cy + 24, cx - 54, cy - 46);
  ctx.closePath();
  ctx.fill();

  // Crema + rosetta heart
  ctx.fillStyle = '#734427';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 46, 52, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#EFE1CE';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 46, 22, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, cx, cy - 60, u, 4, 56, 95, 0.6);

  // Small plate with warm buttery croissant/bun on center-right
  const px = w * 0.58;
  const py = tableY + 34;
  drawStonewarePlate(ctx, px, py + 12, 54, 13, '#F2ECE2', '#E0D6C6');
  const crg = ctx.createLinearGradient(px - 34, py - 18, px + 34, py + 12);
  crg.addColorStop(0, '#E3A453');
  crg.addColorStop(1, '#A45E21');
  ctx.fillStyle = crg;
  ctx.beginPath();
  ctx.ellipse(px, py - 2, 34, 15, -0.1, 0, Math.PI * 2);
  ctx.fill();
};

// 2. TEA & HOT COFFEE
const drawTeaCoffee: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#241B15',
    mid: '#3A2B21',
    bot: '#1E1611',
    tableTop: '#563D2B',
    tableBot: '#2E1E14',
    bokeh: 'rgba(248, 198, 128, 0.24)',
  });

  // Left: Earthen Masala Chai Kulhad
  const kx = w * 0.31;
  const ky = h * 0.67;
  drawPlateShadow(ctx, kx, ky + 34, 48, 11);
  const kg = ctx.createLinearGradient(kx - 46, ky - 56, kx + 46, ky + 36);
  kg.addColorStop(0, '#C97748');
  kg.addColorStop(0.55, '#A95C33');
  kg.addColorStop(1, '#783B1D');
  ctx.fillStyle = kg;
  ctx.beginPath();
  ctx.moveTo(kx - 46, ky - 54);
  ctx.lineTo(kx + 46, ky - 54);
  ctx.lineTo(kx + 32, ky + 38);
  ctx.lineTo(kx - 32, ky + 38);
  ctx.closePath();
  ctx.fill();

  // Kulhad lip ridges
  ctx.strokeStyle = 'rgba(255, 224, 192, 0.28)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(kx - 44, ky - 40);
  ctx.lineTo(kx + 44, ky - 40);
  ctx.stroke();

  // Frothy Masala Chai top
  ctx.fillStyle = '#D99E64';
  ctx.beginPath();
  ctx.ellipse(kx, ky - 54, 45, 11, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#F2CFA3';
  ctx.beginPath();
  ctx.ellipse(kx, ky - 54, 34, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, kx, ky - 66, (u + 0.35) % 1, 3, 38, 86, 0.56);

  // Right: Matte Ceramic Cappuccino with Rosetta Art
  const cx = w * 0.64;
  const cy = h * 0.68;
  drawStonewarePlate(ctx, cx, cy + 32, 92, 20, '#36302C', '#24201D');

  ctx.strokeStyle = '#3B342F';
  ctx.lineWidth = 11;
  ctx.beginPath();
  ctx.arc(cx + 66, cy - 10, 24, -Math.PI * 0.45, Math.PI * 0.45);
  ctx.stroke();

  const cg = ctx.createLinearGradient(cx - 68, cy - 52, cx + 68, cy + 32);
  cg.addColorStop(0, '#463E38');
  cg.addColorStop(1, '#231E1B');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.moveTo(cx - 68, cy - 50);
  ctx.lineTo(cx + 68, cy - 50);
  ctx.quadraticCurveTo(cx + 62, cy + 32, cx, cy + 32);
  ctx.quadraticCurveTo(cx - 62, cy + 32, cx - 68, cy - 50);
  ctx.closePath();
  ctx.fill();

  // Crema + animated subtle heart pulse
  ctx.fillStyle = '#8F5630';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 50, 66, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  const rp = 1 + 0.04 * Math.sin(u * Math.PI * 2);
  ctx.fillStyle = '#F6EAD8';
  ctx.beginPath();
  ctx.ellipse(cx - 10, cy - 52, 16 * rp, 7 * rp, -0.25, 0, Math.PI * 2);
  ctx.ellipse(cx + 10, cy - 52, 16 * rp, 7 * rp, 0.25, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, cx, cy - 68, u, 4, 62, 102, 0.64);
};

// 3. COLD COFFEE
const drawColdCoffee: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#1E382E',
    mid: '#314F42',
    bot: '#1E1A16',
    tableTop: '#C5B5A0',
    tableBot: '#8D7B66',
    bokeh: 'rgba(255, 224, 162, 0.26)',
  });

  const cx = w * 0.5;
  const topY = h * 0.19;
  const botY = h * 0.8;
  const topW = 166;
  const botW = 122;

  drawPlateShadow(ctx, cx, botY - 2, 74, 15);

  // Brass straw behind rim
  ctx.strokeStyle = '#C89B5B';
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(cx + 34, topY - 46);
  ctx.lineTo(cx - 6, topY + 26);
  ctx.stroke();

  // Clipped glass body
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - topW / 2, topY);
  ctx.lineTo(cx + topW / 2, topY);
  ctx.lineTo(cx + botW / 2, botY);
  ctx.lineTo(cx - botW / 2, botY);
  ctx.closePath();
  ctx.clip();

  const lg = ctx.createLinearGradient(0, topY, 0, botY);
  lg.addColorStop(0, '#F5E8D5');
  lg.addColorStop(0.24, '#C89563');
  lg.addColorStop(0.62, '#6E3F22');
  lg.addColorStop(1, '#341C0E');
  ctx.fillStyle = lg;
  ctx.fillRect(cx - topW / 2, topY, topW, botY - topY);

  // Swirling cold milk & caramel ribbons
  ctx.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const sw = Math.sin(phi + i * 1.6) * 20;
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(252, 244, 232, 0.52)' : 'rgba(218, 152, 82, 0.42)';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(cx - 54 + i * 32, topY + 36);
    ctx.bezierCurveTo(cx + sw, topY + 110, cx - sw, topY + 190, cx + 44 - i * 26, botY - 18);
    ctx.stroke();
  }

  // Bobbing translucent ice cubes
  for (let i = 0; i < 5; i++) {
    const bob = Math.sin(phi + i * 1.3) * 6;
    const ix = cx - 44 + (i % 3) * 42;
    const iy = topY + 46 + Math.floor(i / 3) * 42 + bob;
    ctx.save();
    ctx.translate(ix, iy);
    ctx.rotate(0.22 * (i % 2 === 0 ? 1 : -1) + Math.sin(phi + i) * 0.08);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.34)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.62)';
    ctx.lineWidth = 2;
    rr(ctx, -18, -18, 36, 36, 7);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // Sliding condensation droplets
  for (let i = 0; i < 10; i++) {
    const dp = (u + i * 0.11) % 1;
    const dx = cx - 54 + ((i * 23) % 108);
    const dy = topY + 26 + dp * (botY - topY - 40);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.58)';
    ctx.beginPath();
    ctx.arc(dx, dy, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // Frothy cream cap + cocoa dusting
  ctx.fillStyle = '#FBF5EC';
  ctx.beginPath();
  ctx.ellipse(cx, topY + 6, topW * 0.49, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#734224';
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const r = (i % 3) * 16 + 10;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(a) * r, topY + 6 + Math.sin(a) * r * 0.25, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Crisp glass outline & specular vertical reflection
  ctx.strokeStyle = 'rgba(255, 252, 246, 0.72)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cx - topW / 2, topY);
  ctx.lineTo(cx + topW / 2, topY);
  ctx.lineTo(cx + botW / 2, botY);
  ctx.lineTo(cx - botW / 2, botY);
  ctx.closePath();
  ctx.stroke();

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.26)';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(cx - topW / 2 + 16, topY + 28);
  ctx.lineTo(cx - botW / 2 + 14, botY - 24);
  ctx.stroke();
};

// 4. MILKSHAKES
const drawMilkshakes: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#321F28',
    mid: '#4B2F39',
    bot: '#22171B',
    tableTop: '#6A4C3A',
    tableBot: '#3A271C',
    bokeh: 'rgba(255, 206, 178, 0.28)',
  });

  const cx = w * 0.5;
  const topY = h * 0.27;
  const botY = h * 0.8;

  drawPlateShadow(ctx, cx, botY + 2, 66, 14);

  // Pedestal glass base
  ctx.fillStyle = '#E6DDD2';
  ctx.beginPath();
  ctx.ellipse(cx, botY + 2, 54, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(cx - 12, botY - 22, 24, 24);

  // Milkshake glass cup
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - 72, topY);
  ctx.lineTo(cx + 72, topY);
  ctx.quadraticCurveTo(cx + 64, botY - 20, cx + 30, botY - 20);
  ctx.lineTo(cx - 30, botY - 20);
  ctx.quadraticCurveTo(cx - 64, botY - 20, cx - 72, topY);
  ctx.closePath();
  ctx.clip();

  const mg = ctx.createLinearGradient(cx - 70, topY, cx + 70, botY);
  mg.addColorStop(0, '#F5B8C4');
  mg.addColorStop(0.5, '#E4899F');
  mg.addColorStop(1, '#B8536E');
  ctx.fillStyle = mg;
  ctx.fillRect(cx - 80, topY, 160, botY - topY);

  // Animated chocolate swirl inside glass
  ctx.strokeStyle = 'rgba(72, 34, 20, 0.55)';
  ctx.lineWidth = 11;
  ctx.lineCap = 'round';
  for (let i = 0; i < 3; i++) {
    const sw = Math.sin(phi + i * 2) * 18;
    ctx.beginPath();
    ctx.moveTo(cx - 64 + i * 44, topY + 12);
    ctx.bezierCurveTo(cx + sw, topY + 80, cx - sw, topY + 150, cx - 22 + i * 24, botY - 28);
    ctx.stroke();
  }
  ctx.restore();

  // KitKat / chocolate wafer stick poking out
  ctx.save();
  ctx.translate(cx + 42, topY - 28);
  ctx.rotate(0.32 + Math.sin(phi) * 0.03);
  ctx.fillStyle = '#532A19';
  rr(ctx, -10, -48, 20, 74, 4);
  ctx.fill();
  ctx.strokeStyle = '#8B5034';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Tall swirled whipped cream dome
  const wSway = Math.sin(phi) * 2;
  ctx.fillStyle = '#FFF9F2';
  ctx.beginPath();
  ctx.ellipse(cx, topY + 2, 74, 22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#F7EFE6';
  ctx.beginPath();
  ctx.ellipse(cx + wSway * 0.5, topY - 18, 56, 20, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#FFFDF9';
  ctx.beginPath();
  ctx.ellipse(cx + wSway, topY - 36, 36, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  // Glossy chocolate sauce drizzle on cream
  ctx.strokeStyle = '#4B2315';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(cx - 46, topY - 12);
  ctx.bezierCurveTo(cx - 18, topY - 34, cx + 18, topY - 4, cx + 48, topY - 16);
  ctx.stroke();

  // Bright cherry on top
  ctx.fillStyle = '#C92A3B';
  ctx.beginPath();
  ctx.arc(cx + wSway, topY - 54, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.65)';
  ctx.beginPath();
  ctx.arc(cx + wSway - 4, topY - 58, 3.5, 0, Math.PI * 2);
  ctx.fill();

  drawSparkles(
    ctx,
    [
      [cx - 94, topY - 26],
      [cx + 96, topY - 42],
      [cx - 76, topY + 52],
      [cx + 88, topY + 40],
    ],
    u
  );
};

// 5. SIP INTO SUMMER & COOLERS
const drawSummerCoolers: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#173835',
    mid: '#265349',
    bot: '#1A2420',
    tableTop: '#6B533C',
    tableBot: '#3A2B1D',
    bokeh: 'rgba(155, 240, 224, 0.22)',
  });

  // Left glass: Blue Ocean Sparkler
  const lx = w * 0.35;
  const ly = h * 0.78;
  drawPlateShadow(ctx, lx, ly + 2, 54, 12);

  const blueG = ctx.createLinearGradient(lx, ly - 210, lx, ly);
  blueG.addColorStop(0, '#72E6F2');
  blueG.addColorStop(0.55, '#1CA3C8');
  blueG.addColorStop(1, '#0F5980');
  ctx.fillStyle = blueG;
  rr(ctx, lx - 54, ly - 210, 108, 210, 14);
  ctx.fill();

  // Right glass: Mint Aam Panna / Citrus Mojito
  const rx = w * 0.65;
  const ry = h * 0.79;
  drawPlateShadow(ctx, rx, ry + 2, 54, 12);

  const citG = ctx.createLinearGradient(rx, ry - 196, rx, ry);
  citG.addColorStop(0, '#F5E47C');
  citG.addColorStop(0.55, '#89C85E');
  citG.addColorStop(1, '#3D8446');
  ctx.fillStyle = citG;
  rr(ctx, rx - 52, ry - 196, 104, 196, 14);
  ctx.fill();

  // Rising fizz bubbles in both glasses
  for (let i = 0; i < 14; i++) {
    const bp = (u + i * 0.09) % 1;
    const bx1 = lx - 38 + ((i * 19) % 76);
    const by1 = ly - 14 - bp * 184;
    ctx.fillStyle = `rgba(255, 255, 255, ${(0.75 * (1 - bp)).toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(bx1, by1, 2.5 + (i % 3), 0, Math.PI * 2);
    ctx.fill();

    const bp2 = (u + 0.4 + i * 0.08) % 1;
    const bx2 = rx - 36 + ((i * 17) % 72);
    const by2 = ry - 14 - bp2 * 170;
    ctx.fillStyle = `rgba(255, 255, 235, ${(0.75 * (1 - bp2)).toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(bx2, by2, 2.5 + (i % 2), 0, Math.PI * 2);
    ctx.fill();
  }

  // Lime slice wheel on left rim
  ctx.save();
  ctx.translate(lx - 48, ly - 208);
  ctx.rotate(-0.35 + Math.sin(phi) * 0.06);
  ctx.fillStyle = '#55A842';
  ctx.beginPath();
  ctx.arc(0, 0, 26, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#D9F28E';
  ctx.beginPath();
  ctx.arc(0, 0, 20, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Swaying fresh garden mint leaves on right rim
  ctx.save();
  ctx.translate(rx + 10, ry - 200);
  ctx.rotate(Math.sin(phi) * 0.14);
  ctx.fillStyle = '#4CA65B';
  ctx.beginPath();
  ctx.ellipse(-18, -14, 24, 11, -0.5, 0, Math.PI * 2);
  ctx.ellipse(18, -18, 24, 11, 0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Glass outlines
  ctx.strokeStyle = 'rgba(255,255,255,0.68)';
  ctx.lineWidth = 3;
  rr(ctx, lx - 54, ly - 210, 108, 210, 14);
  ctx.stroke();
  rr(ctx, rx - 52, ry - 196, 104, 196, 14);
  ctx.stroke();
};

// 6. DELICIOUS BURGERS
const drawBurgers: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2C2018',
    mid: '#443022',
    bot: '#221811',
    tableTop: '#5E422E',
    tableBot: '#312015',
    bokeh: 'rgba(255, 206, 134, 0.25)',
  });

  const cx = w * 0.5;
  const cy = h * 0.72;
  drawStonewarePlate(ctx, cx, cy + 16, 188, 38);

  // Bottom toasted brioche bun
  const bunBot = ctx.createLinearGradient(cx - 110, cy - 10, cx + 110, cy + 20);
  bunBot.addColorStop(0, '#DF9949');
  bunBot.addColorStop(1, '#A96120');
  ctx.fillStyle = bunBot;
  rr(ctx, cx - 108, cy - 18, 216, 36, 14);
  ctx.fill();

  // Crispy golden herb tikki patty
  ctx.fillStyle = '#6D3B1D';
  rr(ctx, cx - 114, cy - 52, 228, 36, 14);
  ctx.fill();

  // Glistening melted cheddar cheese drape (subtle heat shimmer)
  const drip = Math.sin(phi) * 2.5;
  ctx.fillStyle = '#F7BC31';
  ctx.beginPath();
  ctx.moveTo(cx - 118, cy - 54);
  ctx.lineTo(cx + 118, cy - 54);
  ctx.lineTo(cx + 108, cy - 36);
  ctx.quadraticCurveTo(cx + 68, cy - 14 + drip, cx + 34, cy - 38);
  ctx.quadraticCurveTo(cx - 6, cy - 8 - drip, cx - 44, cy - 38);
  ctx.quadraticCurveTo(cx - 88, cy - 18 + drip, cx - 118, cy - 54);
  ctx.closePath();
  ctx.fill();

  // Fresh tomato slices
  ctx.fillStyle = '#D93B2B';
  rr(ctx, cx - 104, cy - 68, 208, 16, 8);
  ctx.fill();

  // Ruffled crisp garden lettuce
  ctx.fillStyle = '#5BA145';
  ctx.beginPath();
  ctx.moveTo(cx - 120, cy - 72);
  for (let i = -5; i <= 5; i++) {
    ctx.quadraticCurveTo(cx + i * 22, cy - 88 + (i % 2) * 14, cx + (i + 1) * 20, cy - 72);
  }
  ctx.lineTo(cx + 120, cy - 64);
  ctx.lineTo(cx - 120, cy - 64);
  ctx.closePath();
  ctx.fill();

  // Domed golden sesame brioche crown
  const crown = ctx.createRadialGradient(cx - 28, cy - 134, 14, cx, cy - 104, 128);
  crown.addColorStop(0, '#F5BE68');
  crown.addColorStop(0.65, '#D48332');
  crown.addColorStop(1, '#9A5118');
  ctx.fillStyle = crown;
  ctx.beginPath();
  ctx.moveTo(cx - 114, cy - 74);
  ctx.bezierCurveTo(cx - 118, cy - 168, cx + 118, cy - 168, cx + 114, cy - 74);
  ctx.closePath();
  ctx.fill();

  // Toasted sesame seeds
  ctx.fillStyle = '#FFF0CC';
  const seeds = [
    [-52, -124], [-22, -138], [14, -136], [48, -122],
    [-72, -104], [-34, -112], [0, -118], [32, -110], [72, -102],
  ];
  for (const [sx, sy] of seeds) {
    ctx.beginPath();
    ctx.ellipse(cx + sx, cy + sy, 5.5, 2.5, sx * 0.01, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSteamWisps(ctx, cx, cy - 162, u, 4, 120, 82, 0.52);
};

// 7. CHEESE SANDWICHES
const drawSandwiches: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2A211A',
    mid: '#3F3024',
    bot: '#1E1712',
    tableTop: '#604531',
    tableBot: '#332217',
    bokeh: 'rgba(255, 212, 142, 0.25)',
  });

  const cx = w * 0.48;
  const cy = h * 0.72;

  // Serving wooden board
  drawPlateShadow(ctx, cx + 10, cy + 12, 200, 36);
  ctx.fillStyle = '#8F623B';
  rr(ctx, cx - 196, cy - 12, 412, 42, 16);
  ctx.fill();

  // Stacked grilled triangle club sandwich (front half)
  const drawTriHalf = (ox: number, oy: number, lift: number) => {
    // Bottom toast
    ctx.fillStyle = '#C98942';
    rr(ctx, ox - 102, oy - 24 + lift, 204, 22, 7);
    ctx.fill();
    // Green mint chutney & lettuce
    ctx.fillStyle = '#539A48';
    rr(ctx, ox - 96, oy - 36 + lift, 192, 14, 5);
    ctx.fill();
    // Melted cheddar & mozzarella cheese layer
    ctx.fillStyle = '#F9C94A';
    rr(ctx, ox - 98, oy - 50 + lift, 196, 16, 6);
    ctx.fill();
    // Spiced tandoori paneer & tomato layer
    ctx.fillStyle = '#D95A36';
    rr(ctx, ox - 94, oy - 64 + lift, 188, 16, 5);
    ctx.fill();
    // Melted cheese pull shimmer
    ctx.fillStyle = '#FFF1B5';
    rr(ctx, ox - 96, oy - 76 + lift, 192, 14, 5);
    ctx.fill();
    // Top golden char-grilled toast slice
    const tg = ctx.createLinearGradient(ox - 102, oy - 104 + lift, ox + 102, oy - 74 + lift);
    tg.addColorStop(0, '#E3A453');
    tg.addColorStop(1, '#B36E27');
    ctx.fillStyle = tg;
    rr(ctx, ox - 102, oy - 102 + lift, 204, 28, 9);
    ctx.fill();
    // Grill marks
    ctx.strokeStyle = 'rgba(78, 38, 12, 0.55)';
    ctx.lineWidth = 4;
    for (let g = -2; g <= 2; g++) {
      ctx.beginPath();
      ctx.moveTo(ox + g * 34 - 10, oy - 100 + lift);
      ctx.lineTo(ox + g * 34 + 10, oy - 76 + lift);
      ctx.stroke();
    }
  };

  drawTriHalf(cx - 28, cy - 2, 0);
  // Subtle cheese-pull hover on upper deck
  drawTriHalf(cx + 18, cy - 72, Math.sin(phi) * 3);

  // Small bowl of vibrant green mint chutney on right
  ctx.fillStyle = '#EFE7DB';
  ctx.beginPath();
  ctx.ellipse(cx + 162, cy - 6, 36, 15, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#4B9B4B';
  ctx.beginPath();
  ctx.ellipse(cx + 162, cy - 10, 28, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, cx - 10, cy - 186, u, 4, 120, 74, 0.54);
};

// 8. FRIES & GARLIC BREAD
const drawFriesBread: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2C2117',
    mid: '#443222',
    bot: '#1F1710',
    tableTop: '#5E422C',
    tableBot: '#2E1E13',
    bokeh: 'rgba(255, 208, 128, 0.26)',
  });

  // Left: Overflowing golden peri-peri fries basket
  const fx = w * 0.34;
  const fy = h * 0.75;
  drawPlateShadow(ctx, fx, fy + 8, 84, 16);

  // Golden crispy fries sticking up
  const fryAngles = [-0.42, -0.3, -0.18, -0.07, 0.04, 0.14, 0.25, 0.38];
  for (let i = 0; i < fryAngles.length; i++) {
    ctx.save();
    ctx.translate(fx - 42 + i * 12, fy - 76);
    ctx.rotate(fryAngles[i] + Math.sin(phi + i) * 0.015);
    const fg = ctx.createLinearGradient(-8, -70, 8, 10);
    fg.addColorStop(0, '#FFD45C');
    fg.addColorStop(1, '#D68923');
    ctx.fillStyle = fg;
    rr(ctx, -8, -74 - (i % 3) * 14, 16, 86 + (i % 3) * 14, 5);
    ctx.fill();
    // Peri-peri spice specks
    ctx.fillStyle = '#C9381E';
    ctx.beginPath();
    ctx.arc(0, -42, 2.2, 0, Math.PI * 2);
    ctx.arc(-3, -24, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Kraft paper / metal cone basket
  ctx.fillStyle = '#332D29';
  ctx.beginPath();
  ctx.moveTo(fx - 76, fy - 86);
  ctx.lineTo(fx + 76, fy - 86);
  ctx.lineTo(fx + 56, fy + 8);
  ctx.lineTo(fx - 56, fy + 8);
  ctx.closePath();
  ctx.fill();

  // Right: Warm Herb-Butter Stuffed Garlic Bread
  const bx = w * 0.69;
  const by = h * 0.75;
  drawStonewarePlate(ctx, bx, by + 4, 118, 28);
  for (let s = 0; s < 3; s++) {
    const sx = bx - 52 + s * 36;
    const sy = by - 26 - (s % 2) * 8;
    ctx.fillStyle = '#C68236';
    rr(ctx, sx - 28, sy - 22, 56, 56, 12);
    ctx.fill();
    ctx.fillStyle = '#FCE39D';
    rr(ctx, sx - 22, sy - 16, 44, 44, 8);
    ctx.fill();
    // Herb parsley flecks
    ctx.fillStyle = '#4B8E42';
    ctx.beginPath();
    ctx.arc(sx - 6, sy, 3.5, 0, Math.PI * 2);
    ctx.arc(sx + 8, sy + 10, 3, 0, Math.PI * 2);
    ctx.arc(sx + 4, sy - 6, 2.8, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSteamWisps(ctx, fx, fy - 154, u, 3, 72, 74, 0.54);
  drawSteamWisps(ctx, bx, by - 58, (u + 0.45) % 1, 3, 76, 74, 0.54);
};

// 9. SPECIALS & ONION/ALOO PAKODE
const drawSpecialsPakode: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2E1F18',
    mid: '#4B2F21',
    bot: '#201610',
    tableTop: '#5E402C',
    tableBot: '#2E1D13',
    bokeh: 'rgba(255, 198, 120, 0.28)',
  });

  const cx = w * 0.5;
  const cy = h * 0.72;
  drawStonewarePlate(ctx, cx, cy + 12, 212, 42, '#3A322C', '#29231E');

  // Crispy golden pakode mound on left
  const pakodaCoords = [
    [-92, -16, 30], [-56, -34, 32], [-18, -14, 28], [-64, -6, 30], [-36, -48, 26],
  ];
  for (const [px, py, r] of pakodaCoords) {
    const pg = ctx.createRadialGradient(cx + px - 8, cy + py - 8, 4, cx + px, cy + py, r);
    pg.addColorStop(0, '#F0B14C');
    pg.addColorStop(0.65, '#C46F23');
    pg.addColorStop(1, '#7D3E11');
    ctx.fillStyle = pg;
    ctx.beginPath();
    ctx.arc(cx + px, cy + py, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Charred Dry Paneer Tikka skewer on right
  ctx.strokeStyle = '#C9C2B8';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(cx + 12, cy - 28);
  ctx.lineTo(cx + 178, cy - 68);
  ctx.stroke();

  const cubes = [
    { x: cx + 44, y: cy - 36, col: '#E86E2E' },
    { x: cx + 82, y: cy - 46, col: '#559E43' },
    { x: cx + 114, y: cy - 54, col: '#EB7832' },
    { x: cx + 146, y: cy - 62, col: '#D63D2A' },
  ];
  for (const cube of cubes) {
    ctx.fillStyle = cube.col;
    rr(ctx, cube.x - 18, cube.y - 18, 36, 36, 7);
    ctx.fill();
    // Tandoor char flecks
    ctx.fillStyle = 'rgba(42, 18, 8, 0.45)';
    ctx.beginPath();
    ctx.arc(cube.x + 6, cube.y - 6, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // Mint chutney bowl
  ctx.fillStyle = '#EFE6D8';
  ctx.beginPath();
  ctx.ellipse(cx + 88, cy + 6, 36, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#4A9C48';
  ctx.beginPath();
  ctx.ellipse(cx + 88, cy + 2, 28, 9, 0, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, cx - 44, cy - 78, u, 3, 80, 92, 0.58);
  drawSteamWisps(ctx, cx + 92, cy - 84, (u + 0.5) % 1, 3, 76, 86, 0.55);
};

// 10. STREET FOOD CHAAT
const drawChaat: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#321E24',
    mid: '#4C2D34',
    bot: '#221518',
    tableTop: '#634632',
    tableBot: '#332216',
    bokeh: 'rgba(255, 206, 152, 0.28)',
  });

  const cx = w * 0.5;
  const cy = h * 0.7;
  drawStonewarePlate(ctx, cx, cy + 14, 194, 42, '#E9DFCF', '#D9CCB8');

  // 5 crispy golden Dahi Puris arranged in festive ring
  const puris = [
    [-86, -12], [-26, -34], [42, -32], [90, -8], [8, 8],
  ];
  for (const [px, py] of puris) {
    // Crispy golden puri shell
    const pg = ctx.createRadialGradient(cx + px - 8, cy + py - 10, 4, cx + px, cy + py, 36);
    pg.addColorStop(0, '#F0B659');
    pg.addColorStop(1, '#B36A21');
    ctx.fillStyle = pg;
    ctx.beginPath();
    ctx.ellipse(cx + px, cy + py, 36, 26, 0, 0, Math.PI * 2);
    ctx.fill();

    // Creamy white dahi swirl
    ctx.fillStyle = '#FFFBF2';
    ctx.beginPath();
    ctx.ellipse(cx + px, cy + py - 6, 24, 13, 0, 0, Math.PI * 2);
    ctx.fill();

    // Glossy tamarind & green chutney dots
    ctx.fillStyle = '#8C2F1B';
    ctx.beginPath();
    ctx.arc(cx + px - 6, cy + py - 7, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#4B9B46';
    ctx.beginPath();
    ctx.arc(cx + px + 8, cy + py - 5, 4.5, 0, Math.PI * 2);
    ctx.fill();

    // Ruby pomegranate arils & golden nylon sev
    ctx.fillStyle = '#D92647';
    ctx.beginPath();
    ctx.arc(cx + px + 2, cy + py - 12, 3.5, 0, Math.PI * 2);
    ctx.arc(cx + px - 10, cy + py - 2, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#FFD554';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx + px - 16, cy + py - 10);
    ctx.lineTo(cx + px + 16, cy + py - 2);
    ctx.moveTo(cx + px - 12, cy + py + 2);
    ctx.lineTo(cx + px + 14, cy + py - 12);
    ctx.stroke();
  }

  drawSparkles(
    ctx,
    [
      [cx - 88, cy - 52],
      [cx + 12, cy - 72],
      [cx + 96, cy - 44],
      [cx - 32, cy - 68],
      [cx + 56, cy - 64],
    ],
    u
  );
};

// 11. SPECIAL SOUP
const drawSoups: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#1D2D25',
    mid: '#2E4337',
    bot: '#1A1C19',
    tableTop: '#593F2C',
    tableBot: '#2D1E14',
    bokeh: 'rgba(255, 222, 152, 0.25)',
  });

  const cx = w * 0.5;
  const cy = h * 0.68;

  drawPlateShadow(ctx, cx, cy + 32, 146, 26);

  // Cozy deep ceramic soup bowl
  const bg = ctx.createLinearGradient(cx - 140, cy - 40, cx + 140, cy + 44);
  bg.addColorStop(0, '#F5EFE6');
  bg.addColorStop(1, '#C5B9A9');
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(cx - 144, cy - 36);
  ctx.lineTo(cx + 144, cy - 36);
  ctx.bezierCurveTo(cx + 132, cy + 52, cx - 132, cy + 52, cx - 144, cy - 36);
  ctx.closePath();
  ctx.fill();

  // Velvety herb broccoli-almond / roasted garlic soup surface
  const sg = ctx.createRadialGradient(cx, cy - 36, 12, cx, cy - 36, 134);
  sg.addColorStop(0, '#A2B86A');
  sg.addColorStop(0.65, '#688645');
  sg.addColorStop(1, '#445C2B');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.ellipse(cx, cy - 36, 132, 34, 0, 0, Math.PI * 2);
  ctx.fill();

  // Gently breathing cream swirl
  const sw = 1 + 0.04 * Math.sin(phi);
  ctx.strokeStyle = '#FCF6EB';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 36, 68 * sw, 16 * sw, 0.1, 0, Math.PI * 1.65);
  ctx.stroke();

  // Bobbing toasted croutons
  for (let i = 0; i < 4; i++) {
    const bob = Math.sin(phi + i * 1.5) * 2.5;
    const tx = cx - 44 + i * 28;
    const ty = cy - 40 + (i % 2) * 10 + bob;
    ctx.fillStyle = '#D99443';
    rr(ctx, tx - 11, ty - 7, 22, 14, 4);
    ctx.fill();
  }

  drawSteamWisps(ctx, cx, cy - 64, u, 5, 144, 114, 0.65);
};

// 12. WRAPS
const drawWraps: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2A2118',
    mid: '#423223',
    bot: '#1E1711',
    tableTop: '#5F432E',
    tableBot: '#2F1F14',
    bokeh: 'rgba(255, 210, 138, 0.25)',
  });

  const cx = w * 0.5;
  const cy = h * 0.72;
  drawStonewarePlate(ctx, cx, cy + 12, 200, 38);

  const drawWrapHalf = (ox: number, oy: number, angle: number) => {
    ctx.save();
    ctx.translate(ox, oy);
    ctx.rotate(angle);

    // Parchment craft wrapper on back half
    ctx.fillStyle = '#EFE6D5';
    rr(ctx, -124, -36, 120, 72, 12);
    ctx.fill();

    // Char-grilled tortilla wrap body
    const wg = ctx.createLinearGradient(0, -36, 0, 36);
    wg.addColorStop(0, '#E8C58E');
    wg.addColorStop(1, '#BA8848');
    ctx.fillStyle = wg;
    rr(ctx, -40, -34, 146, 68, 22);
    ctx.fill();

    // Grill char stripes
    ctx.strokeStyle = 'rgba(92, 48, 16, 0.45)';
    ctx.lineWidth = 4;
    for (let g = 0; g < 3; g++) {
      ctx.beginPath();
      ctx.moveTo(-10 + g * 32, -32);
      ctx.lineTo(10 + g * 32, 32);
      ctx.stroke();
    }

    // Colorful exposed filling at cut end
    ctx.fillStyle = '#4B9542';
    ctx.beginPath();
    ctx.ellipse(98, -10, 14, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#E0642D';
    ctx.beginPath();
    ctx.arc(102, 8, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#F7C94A';
    ctx.beginPath();
    ctx.arc(90, 2, 10, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  };

  drawWrapHalf(cx - 18, cy - 16, -0.08);
  drawWrapHalf(cx + 12, cy - 72, 0.09);

  drawSteamWisps(ctx, cx + 10, cy - 120, u, 4, 120, 86, 0.56);
};

// 13. MOMOS
const drawMomos: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#24221C',
    mid: '#3D3529',
    bot: '#1C1813',
    tableTop: '#5B402C',
    tableBot: '#2D1E13',
    bokeh: 'rgba(255, 214, 150, 0.25)',
  });

  const cx = w * 0.46;
  const cy = h * 0.7;

  drawPlateShadow(ctx, cx, cy + 20, 168, 36);

  // Woven bamboo steamer basket
  const bg = ctx.createLinearGradient(cx - 162, cy - 52, cx + 162, cy + 36);
  bg.addColorStop(0, '#D4A564');
  bg.addColorStop(1, '#8D612D');
  ctx.fillStyle = bg;
  rr(ctx, cx - 162, cy - 42, 324, 72, 24);
  ctx.fill();

  // Dark inner steamer bed
  ctx.fillStyle = '#5C3E1D';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 38, 152, 42, 0, 0, Math.PI * 2);
  ctx.fill();

  // 5 plump pleated white momos
  const momos = [
    [-76, -42], [0, -56], [76, -42], [-42, -16], [42, -16],
  ];
  for (const [mx, my] of momos) {
    const mg = ctx.createRadialGradient(cx + mx - 8, cy + my - 12, 4, cx + mx, cy + my, 38);
    mg.addColorStop(0, '#FFFDF9');
    mg.addColorStop(1, '#DDD3C3');
    ctx.fillStyle = mg;
    ctx.beginPath();
    ctx.ellipse(cx + mx, cy + my, 38, 25, 0, 0, Math.PI * 2);
    ctx.fill();

    // Pleated ridge detail
    ctx.strokeStyle = 'rgba(155, 140, 122, 0.55)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx + mx - 24, cy + my - 4);
    ctx.quadraticCurveTo(cx + mx, cy + my - 22, cx + mx + 24, cy + my - 4);
    ctx.stroke();
  }

  // Fiery red chili momo chutney bowl on right
  const rx = w * 0.82;
  const ry = h * 0.75;
  ctx.fillStyle = '#332C28';
  ctx.beginPath();
  ctx.ellipse(rx, ry, 42, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#D12E1E';
  ctx.beginPath();
  ctx.ellipse(rx, ry - 4, 34, 11, 0, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, cx, cy - 86, u, 5, 190, 112, 0.68);
};

// 14. MAGGI
const drawMaggi: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2A2016',
    mid: '#443220',
    bot: '#1E160F',
    tableTop: '#5E422C',
    tableBot: '#2E1E13',
    bokeh: 'rgba(255, 214, 128, 0.28)',
  });

  const cx = w * 0.5;
  const cy = h * 0.7;
  drawPlateShadow(ctx, cx, cy + 28, 146, 26);

  // Cozy matte forest-green ceramic bowl
  const bg = ctx.createLinearGradient(cx - 140, cy - 36, cx + 140, cy + 44);
  bg.addColorStop(0, '#365848');
  bg.addColorStop(1, '#1B3127');
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(cx - 142, cy - 36);
  ctx.lineTo(cx + 142, cy - 36);
  ctx.bezierCurveTo(cx + 128, cy + 52, cx - 128, cy + 52, cx - 142, cy - 36);
  ctx.closePath();
  ctx.fill();

  // Golden tangled Maggi noodle bed
  ctx.fillStyle = '#E8A832';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 38, 128, 36, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#FFD766';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  for (let i = 0; i < 11; i++) {
    const ny = cy - 56 + i * 4.5;
    ctx.beginPath();
    ctx.moveTo(cx - 104 + (i % 3) * 14, ny);
    ctx.bezierCurveTo(cx - 40, ny - 14, cx + 40, ny + 14, cx + 104 - (i % 3) * 14, ny);
    ctx.stroke();
  }

  // Animated lifting fork with gently bobbing golden Maggi strands
  const lift = Math.sin(phi) * 14;
  ctx.strokeStyle = '#FFD65C';
  ctx.lineWidth = 4.5;
  for (let s = -2; s <= 2; s++) {
    ctx.beginPath();
    ctx.moveTo(cx + s * 10, cy - 42);
    ctx.quadraticCurveTo(cx + s * 14 + Math.sin(phi + s) * 4, cy - 92 - lift * 0.5, cx + s * 8, cy - 134 - lift);
    ctx.stroke();
  }

  // Wooden chopsticks / fork holding lifted noodles
  ctx.strokeStyle = '#D9B282';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(cx - 24, cy - 138 - lift);
  ctx.lineTo(cx + 112, cy - 166 - lift);
  ctx.moveTo(cx - 22, cy - 124 - lift);
  ctx.lineTo(cx + 114, cy - 146 - lift);
  ctx.stroke();

  // Sweet corn, peas & melting butter pat
  ctx.fillStyle = '#53A348';
  for (const [vx, vy] of [[-54, -36], [42, -44], [64, -26], [-24, -22]]) {
    ctx.beginPath();
    ctx.arc(cx + vx, cy + vy, 5.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#FFF0A8';
  rr(ctx, cx - 18, cy - 52, 30, 18, 5);
  ctx.fill();

  drawSteamWisps(ctx, cx, cy - 84, u, 4, 150, 96, 0.58);
};

// 15. GUJARATI SNACKS
const drawGujaratiSnacks: DrawFn = (ctx, w, h, u) => {
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#262417',
    mid: '#3F3A22',
    bot: '#1D1B12',
    tableTop: '#644830',
    tableBot: '#332316',
    bokeh: 'rgba(255, 224, 134, 0.28)',
  });

  const cx = w * 0.5;
  const cy = h * 0.72;
  // Warm brass-rimmed Gujarati thali platter
  drawStonewarePlate(ctx, cx, cy + 12, 212, 44, '#D9B25F', '#F2E7D3');

  // Left: Fluffy golden Khaman Dhokla cubes
  const dhoklas = [
    [-92, -32], [-44, -46], [-62, -6], [-12, -18],
  ];
  for (const [dx, dy] of dhoklas) {
    ctx.fillStyle = '#F5C431';
    rr(ctx, cx + dx - 26, cy + dy - 22, 52, 42, 7);
    ctx.fill();
    ctx.fillStyle = '#FFE06B';
    rr(ctx, cx + dx - 26, cy + dy - 22, 52, 16, 6);
    ctx.fill();
    // Tempered mustard seeds & curry leaf
    ctx.fillStyle = '#2B2118';
    ctx.beginPath();
    ctx.arc(cx + dx - 8, cy + dy - 14, 2.2, 0, Math.PI * 2);
    ctx.arc(cx + dx + 6, cy + dy - 12, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#438F3F';
    ctx.beginPath();
    ctx.ellipse(cx + dx + 2, cy + dy - 16, 8, 3.5, 0.3, 0, Math.PI * 2);
    ctx.fill();
  }

  // Right: Warm folded Methi Thepla + Crispy Samosa
  ctx.fillStyle = '#C98A3E';
  ctx.beginPath();
  ctx.ellipse(cx + 76, cy - 16, 74, 28, -0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#4C823B';
  for (let i = 0; i < 8; i++) {
    ctx.beginPath();
    ctx.arc(cx + 38 + i * 11, cy - 22 + (i % 3) * 8, 2.6, 0, Math.PI * 2);
    ctx.fill();
  }

  // Golden triangular Samosa
  const sg = ctx.createLinearGradient(cx + 42, cy - 88, cx + 118, cy - 18);
  sg.addColorStop(0, '#E8A44B');
  sg.addColorStop(1, '#A65B1C');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.moveTo(cx + 76, cy - 92);
  ctx.lineTo(cx + 124, cy - 24);
  ctx.lineTo(cx + 32, cy - 24);
  ctx.closePath();
  ctx.fill();

  drawSteamWisps(ctx, cx - 26, cy - 78, u, 4, 150, 88, 0.56);
};

// 16. PIZZA
const drawPizza: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2C1E17',
    mid: '#462D20',
    bot: '#1E1510',
    tableTop: '#5E422C',
    tableBot: '#2E1E13',
    bokeh: 'rgba(255, 200, 124, 0.26)',
  });

  const cx = w * 0.5;
  const cy = h * 0.67;

  // Rustic wooden pizza peel
  drawPlateShadow(ctx, cx, cy + 20, 210, 62);
  ctx.fillStyle = '#8F5E34';
  ctx.beginPath();
  ctx.ellipse(cx, cy + 12, 206, 62, 0, 0, Math.PI * 2);
  ctx.fill();

  // Blistered golden crust
  const crg = ctx.createRadialGradient(cx, cy, 30, cx, cy, 186);
  crg.addColorStop(0, '#E2A253');
  crg.addColorStop(0.82, '#C87D32');
  crg.addColorStop(1, '#8C4D1A');
  ctx.fillStyle = crg;
  ctx.beginPath();
  ctx.ellipse(cx, cy, 186, 56, 0, 0, Math.PI * 2);
  ctx.fill();

  // Rich spiced tomato base
  ctx.fillStyle = '#C23D24';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 2, 160, 44, 0, 0, Math.PI * 2);
  ctx.fill();

  // Gently bubbling melted mozzarella cheese patches
  const bubble = 1 + 0.04 * Math.sin(phi);
  ctx.fillStyle = '#FFF3D2';
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2 + 0.2;
    const rad = i % 2 === 0 ? 86 : 48;
    ctx.beginPath();
    ctx.ellipse(
      cx + Math.cos(a) * rad,
      cy - 2 + Math.sin(a) * rad * 0.28,
      28 * bubble,
      11 * bubble,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  // Tandoori paneer cubes, peppers & fresh garden basil
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + 0.6;
    const px = cx + Math.cos(a) * 94;
    const py = cy - 4 + Math.sin(a) * 26;
    ctx.fillStyle = i % 2 === 0 ? '#E36A2C' : '#F4C63D';
    rr(ctx, px - 10, py - 6, 20, 12, 4);
    ctx.fill();

    ctx.fillStyle = '#4B8F45';
    ctx.beginPath();
    ctx.ellipse(px - 14, py + 4, 11, 5, a, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSteamWisps(ctx, cx, cy - 58, u, 5, 220, 96, 0.56);
};

// 17. FRESH HOT SWEETS
const drawHotSweets: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#2C1B18',
    mid: '#472B24',
    bot: '#1E1311',
    tableTop: '#5E412D',
    tableBot: '#2D1D13',
    bokeh: 'rgba(255, 212, 152, 0.28)',
  });

  const cx = w * 0.5;
  const cy = h * 0.72;
  drawStonewarePlate(ctx, cx, cy + 12, 206, 40, '#F3ECE2', '#E2D8CA');

  // Left: Hot Molten Chocolava Cake
  const lx = cx - 64;
  const ly = cy - 12;
  const cg = ctx.createLinearGradient(lx - 54, ly - 64, lx + 54, ly + 12);
  cg.addColorStop(0, '#5A3122');
  cg.addColorStop(1, '#2D150D');
  ctx.fillStyle = cg;
  rr(ctx, lx - 54, ly - 58, 108, 72, 18);
  ctx.fill();

  // Flowing glossy molten chocolate lava river
  const flow = Math.sin(phi) * 6;
  ctx.fillStyle = '#2B1109';
  ctx.beginPath();
  ctx.ellipse(lx, ly - 56, 32, 10, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(lx - 18, ly - 52);
  ctx.bezierCurveTo(lx - 26, ly - 10, lx - 4, ly + 10 + flow, lx + 18, ly + 16);
  ctx.lineTo(lx + 42, ly + 12);
  ctx.bezierCurveTo(lx + 24, ly - 10, lx + 18, ly - 32, lx + 16, ly - 52);
  ctx.closePath();
  ctx.fill();

  // Right: Warm Golden Gulab Jamun with Vanilla Ice Cream Scoop
  const rx = cx + 74;
  const ry = cy - 4;
  // Vanilla ice cream scoop
  ctx.fillStyle = '#FFF9EE';
  ctx.beginPath();
  ctx.arc(rx + 28, ry - 20, 32, 0, Math.PI * 2);
  ctx.fill();

  // Warm syrup-glazed Gulab Jamun spheres
  for (const [gx, gy] of [[-18, -6], [6, -34]]) {
    const gj = ctx.createRadialGradient(rx + gx - 8, ry + gy - 8, 3, rx + gx, ry + gy, 24);
    gj.addColorStop(0, '#C96828');
    gj.addColorStop(0.7, '#873A12');
    gj.addColorStop(1, '#521E07');
    ctx.fillStyle = gj;
    ctx.beginPath();
    ctx.arc(rx + gx, ry + gy, 23, 0, Math.PI * 2);
    ctx.fill();
  }

  // Pistachio slivers
  ctx.fillStyle = '#73B85A';
  ctx.beginPath();
  ctx.ellipse(rx + 24, ry - 44, 6, 3, 0.4, 0, Math.PI * 2);
  ctx.ellipse(rx + 36, ry - 38, 6, 3, -0.3, 0, Math.PI * 2);
  ctx.fill();

  drawSteamWisps(ctx, lx, ly - 68, u, 3, 62, 82, 0.56);
  drawSparkles(
    ctx,
    [
      [rx + 28, ry - 68],
      [lx - 66, ly - 76],
      [cx + 6, cy - 88],
      [rx + 74, ry - 36],
    ],
    u
  );
};

// 18. COMBOS & CLUB GAMES (Toran Club Cricket, Pickleball & Swimming Pool + Cafe Combo)
const drawCombosGames: DrawFn = (ctx, w, h, u) => {
  const phi = u * Math.PI * 2;
  drawGardenBackdrop(ctx, w, h, u, {
    top: '#172E28',
    mid: '#23493D',
    bot: '#182420',
    tableTop: '#4A5B47',
    tableBot: '#243025',
    bokeh: 'rgba(176, 244, 224, 0.24)',
  });

  // Left: Glowing turquoise Toran Club swimming pool with animated ripples
  const px = w * 0.28;
  const py = h * 0.62;
  const poolG = ctx.createLinearGradient(px - 120, py - 50, px + 120, py + 70);
  poolG.addColorStop(0, '#5AD9E8');
  poolG.addColorStop(1, '#1A85A8');
  ctx.fillStyle = poolG;
  rr(ctx, px - 124, py - 46, 248, 128, 22);
  ctx.fill();
  ctx.strokeStyle = '#E6DDD0';
  ctx.lineWidth = 6;
  ctx.stroke();

  // Animated water light ripples
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.48)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 4; i++) {
    const shift = Math.sin(phi + i * 1.5) * 14;
    ctx.beginPath();
    ctx.moveTo(px - 90 + shift, py - 18 + i * 26);
    ctx.quadraticCurveTo(px + shift, py - 28 + i * 26, px + 90 + shift, py - 18 + i * 26);
    ctx.stroke();
  }

  // Right: Turf Cricket & Pickleball + Cafe Combo Cup
  const rx = w * 0.72;
  const ry = h * 0.62;
  ctx.fillStyle = '#2E6E46';
  rr(ctx, rx - 118, ry - 46, 236, 128, 22);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.lineWidth = 3;
  ctx.strokeRect(rx - 96, ry - 26, 192, 88);

  // Bouncing glowing pickleball / cricket ball arc
  const bounce = Math.abs(Math.sin(phi)) * 46;
  ctx.fillStyle = '#F7E048';
  ctx.beginPath();
  ctx.arc(rx - 28 + Math.cos(phi) * 32, ry + 12 - bounce, 14, 0, Math.PI * 2);
  ctx.fill();

  // Pickleball paddle silhouette
  ctx.save();
  ctx.translate(rx + 48, ry + 10);
  ctx.rotate(-0.35 + Math.sin(phi) * 0.14);
  ctx.fillStyle = '#E36A3A';
  rr(ctx, -24, -42, 48, 56, 16);
  ctx.fill();
  ctx.fillStyle = '#241D18';
  rr(ctx, -6, 14, 12, 28, 4);
  ctx.fill();
  ctx.restore();

  // Foreground mini steaming coffee cup (Combo 149 badge accent)
  const cx = w * 0.5;
  const cy = h * 0.8;
  ctx.fillStyle = '#F6F0E6';
  rr(ctx, cx - 32, cy - 42, 64, 58, 12);
  ctx.fill();
  ctx.fillStyle = '#6D3E22';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 40, 30, 8, 0, 0, Math.PI * 2);
  ctx.fill();
  drawSteamWisps(ctx, cx, cy - 52, u, 3, 34, 62, 0.55);
};

interface GifSpec {
  filename: string;
  width: number;
  height: number;
  draw: DrawFn;
}

const SPECS: GifSpec[] = [
  { filename: 'garden-hero.gif', width: 800, height: 520, draw: drawGardenHero },
  { filename: 'tea-coffee.gif', width: 640, height: 480, draw: drawTeaCoffee },
  { filename: 'cold-coffee.gif', width: 640, height: 480, draw: drawColdCoffee },
  { filename: 'milkshakes.gif', width: 640, height: 480, draw: drawMilkshakes },
  { filename: 'summer-coolers.gif', width: 640, height: 480, draw: drawSummerCoolers },
  { filename: 'burgers.gif', width: 640, height: 480, draw: drawBurgers },
  { filename: 'sandwiches.gif', width: 640, height: 480, draw: drawSandwiches },
  { filename: 'fries-bread.gif', width: 640, height: 480, draw: drawFriesBread },
  { filename: 'specials-pakode.gif', width: 640, height: 480, draw: drawSpecialsPakode },
  { filename: 'chaat.gif', width: 640, height: 480, draw: drawChaat },
  { filename: 'soups.gif', width: 640, height: 480, draw: drawSoups },
  { filename: 'wraps.gif', width: 640, height: 480, draw: drawWraps },
  { filename: 'momos.gif', width: 640, height: 480, draw: drawMomos },
  { filename: 'maggi.gif', width: 640, height: 480, draw: drawMaggi },
  { filename: 'gujarati-snacks.gif', width: 640, height: 480, draw: drawGujaratiSnacks },
  { filename: 'pizza.gif', width: 640, height: 480, draw: drawPizza },
  { filename: 'hot-sweets.gif', width: 640, height: 480, draw: drawHotSweets },
  { filename: 'combos-games.gif', width: 640, height: 480, draw: drawCombosGames },
];

async function renderGif(spec: GifSpec): Promise<void> {
  const outPath = path.join(OUT_DIR, spec.filename);
  const canvas = createCanvas(spec.width, spec.height);
  const ctx = canvas.getContext('2d');

  await new Promise<void>((resolve, reject) => {
    const ff = spawn('ffmpeg', [
      '-y',
      '-f',
      'rawvideo',
      '-pix_fmt',
      'rgba',
      '-s',
      `${spec.width}x${spec.height}`,
      '-r',
      String(FPS),
      '-i',
      'pipe:0',
      '-vf',
      'split[s0][s1];[s0]palettegen=max_colors=256:stats_mode=full[p];[s1][p]paletteuse=dither=sierra2_4a:diff_mode=rectangle',
      '-loop',
      '0',
      outPath,
    ]);

    let stderr = '';
    ff.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    ff.on('error', reject);
    ff.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`ffmpeg exited ${code} for ${spec.filename}: ${stderr.slice(-400)}`));
      }
    });

    for (let f = 0; f < FRAMES; f++) {
      ctx.clearRect(0, 0, spec.width, spec.height);
      spec.draw(ctx, spec.width, spec.height, f / FRAMES);
      const raw = canvas.data();
      ff.stdin.write(Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength));
    }
    ff.stdin.end();
  });

  const stat = fs.statSync(outPath);
  console.log(`Generated ${spec.filename} (${Math.round(stat.size / 1024)} KB)`);
}

async function main() {
  for (const spec of SPECS) {
    await renderGif(spec);
  }
  console.log(`All ${SPECS.length} high-quality animated GIFs generated in ${OUT_DIR}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
