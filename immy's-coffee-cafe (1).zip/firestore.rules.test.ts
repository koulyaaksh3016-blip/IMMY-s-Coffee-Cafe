/**
 * Security Rules Verification Spec for IMMY's COFFEE CAFE (Owner & Managers RBAC).
 * Documents the 12 Dirty Dozen payloads that MUST be denied by firestore.rules.
 */

export interface DirtyDozenCase {
  id: number;
  name: string;
  actor: {
    uid: string;
    email: string;
    email_verified: boolean;
    managerStatus?: 'active' | 'revoked' | 'none';
  };
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const OWNER_EMAIL = 'koulyaaksh3016@gmail.com';

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Unverified owner email spoofing',
    actor: { uid: 'spoof-1', email: OWNER_EMAIL, email_verified: false },
    operation: 'create',
    path: '/managers/bob_gmail_com',
    payload: { email: 'bob@gmail.com', name: 'Bob', role: 'manager', status: 'active' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Regular user self-appointing as manager',
    actor: { uid: 'user-2', email: 'alice@gmail.com', email_verified: true, managerStatus: 'none' },
    operation: 'create',
    path: '/managers/alice_gmail_com',
    payload: { email: 'alice@gmail.com', name: 'Alice', role: 'manager', status: 'active' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Active manager attempting to appoint another manager',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'create',
    path: '/managers/friend_gmail_com',
    payload: { email: 'friend@gmail.com', name: 'Friend', role: 'manager', status: 'active' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Active manager attempting to list all managers (PII leak)',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'list',
    path: '/managers',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Revoked manager attempting to update cafe operations',
    actor: { uid: 'mgr-rev', email: 'revoked@gmail.com', email_verified: true, managerStatus: 'revoked' },
    operation: 'update',
    path: '/cafeSettings/operations',
    payload: { acceptingOrders: false },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Shadow ghost field injection on manager record',
    actor: { uid: 'owner-1', email: OWNER_EMAIL, email_verified: true },
    operation: 'create',
    path: '/managers/mgr_gmail_com',
    payload: {
      email: 'mgr@gmail.com',
      name: 'Manager',
      role: 'manager',
      status: 'active',
      shiftNote: 'Evening',
      appointedByEmail: OWNER_EMAIL,
      appointedByUid: 'owner-1',
      isSuperOwner: true,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Forged appointedByUid on manager creation',
    actor: { uid: 'owner-1', email: OWNER_EMAIL, email_verified: true },
    operation: 'create',
    path: '/managers/mgr2_gmail_com',
    payload: {
      email: 'mgr2@gmail.com',
      name: 'Manager 2',
      role: 'manager',
      status: 'active',
      shiftNote: '',
      appointedByEmail: OWNER_EMAIL,
      appointedByUid: 'someone-else',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Client-forged timestamp on staff note creation',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'create',
    path: '/staffNotes/note_backdated',
    payload: {
      title: 'Backdated note',
      body: 'Attempted client timestamp',
      category: 'shift',
      status: 'open',
      authorUid: 'mgr-1',
      authorEmail: 'mgr@gmail.com',
      authorRole: 'manager',
      createdAt: '2020-01-01T00:00:00Z',
      updatedAt: '2020-01-01T00:00:00Z',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Document ID poisoning with illegal characters',
    actor: { uid: 'owner-1', email: OWNER_EMAIL, email_verified: true },
    operation: 'create',
    path: '/managers/bad$id!symbols',
    payload: { email: 'bad@gmail.com', name: 'Bad', role: 'manager', status: 'active' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Out-of-bounds prepTimeMinutes and array poisoning in cafeSettings',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'update',
    path: '/cafeSettings/operations',
    payload: {
      acceptingOrders: true,
      prepTimeMinutes: 999,
      dailySpecialNotice: 'Test',
      unavailableItemIds: [12345],
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Manager spoofing authorRole as owner in staffNotes',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'create',
    path: '/staffNotes/note_spoof_role',
    payload: {
      title: 'Spoof',
      body: 'Claiming owner role',
      category: 'shift',
      status: 'open',
      authorUid: 'mgr-1',
      authorEmail: 'mgr@gmail.com',
      authorRole: 'owner',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Manager modifying an already resolved staff note (terminal state lock)',
    actor: { uid: 'mgr-1', email: 'mgr@gmail.com', email_verified: true, managerStatus: 'active' },
    operation: 'update',
    path: '/staffNotes/note_resolved_1',
    payload: {
      status: 'open',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
];
