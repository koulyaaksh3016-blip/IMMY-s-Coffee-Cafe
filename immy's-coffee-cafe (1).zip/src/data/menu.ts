export type MenuGroupId = 'beverages' | 'food' | 'sweets-club';

export interface MenuItem {
  id: string;
  categoryId: string;
  subCategory?: string;
  name: string;
  description: string;
  price: number;
  serving: string;
  dietary: 'Veg' | 'Club Activity';
  note?: string;
  customizable?: boolean;
}

export interface MenuCategory {
  id: string;
  groupId: MenuGroupId;
  title: string;
  shortTitle: string;
  subtitle: string;
  atmosphereNote: string;
  gifUrl: string;
  items: MenuItem[];
}

export const MENU_GROUPS: Array<{ id: MenuGroupId; label: string; description: string }> = [
  {
    id: 'beverages',
    label: 'Beverages',
    description: 'Hot chai, espresso brews, cold coffees, thick milkshakes & summer coolers',
  },
  {
    id: 'food',
    label: 'Cafe Bites & Mains',
    description: 'Burgers, cheese sandwiches, fries, chaat, wraps, momos, Maggi, Gujarati snacks & pizza',
  },
  {
    id: 'sweets-club',
    label: 'Hot Sweets & Club',
    description: 'Warm freshly prepared desserts, value combos & Toran Club outdoor games',
  },
];

export const CAFE_INFO = {
  name: "IMMY's COFFEE CAFE",
  shortName: "IMMY's",
  address: 'Toran Club, Shop 11/12, B/H Shell Petrol Pump, Ahmedabad - Palanpur Hwy, Gujarat, 385001',
  cityRegion: 'Palanpur Highway, Gujarat',
  phone: '6353405943',
  formattedPhone: '+91 63534 05943',
  hours: '10:30 AM – 11:00 PM',
  days: 'Open Daily',
  minPrepTime: '15 mins',
  heroGifUrl: '/assets/gifs/garden-hero.gif',
  zomatoUrl: 'https://www.zomato.com/search?q=IMMY%27s+Coffee+Cafe+Toran+Club+Palanpur',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=Toran+Club,+Ahmedabad+-+Palanpur+Hwy,+Gujarat,+385001',
} as const;

export const MENU_CATEGORIES: MenuCategory[] = [
  // =========================================================================
  // BEVERAGES (57 items across 4 categories)
  // =========================================================================
  {
    id: 'tea-coffee',
    groupId: 'beverages',
    title: 'Tea & Hot Coffee',
    shortTitle: 'Tea & Coffee',
    subtitle: 'Freshly brewed garden chai, spiced milks, and aromatic hot espresso classics.',
    atmosphereNote: 'Steaming Hot · Min prep 15 mins',
    gifUrl: '/assets/gifs/tea-coffee.gif',
    items: [
      { id: 'tea-black', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Black Tea', description: 'Crisp, briskly steeped loose-leaf garden black tea.', price: 20, serving: 'Cup', dietary: 'Veg' },
      { id: 'tea-regular', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Tea', description: 'Classic Indian milk chai simmered warm and fragrant.', price: 30, serving: 'Cup', dietary: 'Veg', note: 'Garden Favorite' },
      { id: 'tea-green', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Green Tea', description: 'Light, soothing steeped green tea for a calm garden break.', price: 50, serving: 'Cup', dietary: 'Veg' },
      { id: 'tea-haldi-milk', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Haldi Milk', description: 'Comforting warm golden turmeric milk gently spiced.', price: 60, serving: 'Cup', dietary: 'Veg' },
      { id: 'tea-masala-milk', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Masala Milk', description: 'Rich saffron-nut spiced hot milk, ideal for breezy evenings.', price: 60, serving: 'Cup', dietary: 'Veg' },
      { id: 'tea-bournvita', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Bournvita', description: 'Warm malted chocolate milk whisked frothy and cozy.', price: 100, serving: 'Mug', dietary: 'Veg' },
      { id: 'tea-ice-lemon', categoryId: 'tea-coffee', subCategory: 'Tea', name: 'Ice Lemon Tea', description: 'Chilled brewed tea brightened with fresh citrus zest.', price: 100, serving: 'Tall Glass', dietary: 'Veg' },

      { id: 'cof-normal', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Normal Coffee', description: 'Smooth classic hot cafe coffee whipped lightly.', price: 50, serving: 'Cup', dietary: 'Veg' },
      { id: 'cof-espresso', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Espresso Coffee', description: 'Bold freshly extracted single-origin espresso shot.', price: 50, serving: 'Shot', dietary: 'Veg' },
      { id: 'cof-americano', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Americano Coffee', description: 'Rich espresso lengthened with hot filtered water.', price: 70, serving: 'Mug', dietary: 'Veg' },
      { id: 'cof-flat-white', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Flat White Coffee', description: 'Silky micro-foam poured smoothly over bold espresso.', price: 80, serving: 'Cup', dietary: 'Veg' },
      { id: 'cof-macchiato', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Macchiato Coffee', description: 'Espresso marked with a velvety dollop of steamed milk foam.', price: 90, serving: 'Cup', dietary: 'Veg' },
      { id: 'cof-cappuccino', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Cappuccino Coffee', description: 'Balanced espresso topped with thick, airy steamed foam.', price: 100, serving: 'Cup', dietary: 'Veg', note: 'Bestseller' },
      { id: 'cof-latte', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Latte Coffee', description: 'Creamy steamed milk folded over smooth house espresso.', price: 100, serving: 'Mug', dietary: 'Veg' },
      { id: 'cof-hot-chocolate', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Hot Chocolate', description: 'Thick, velvety melted cocoa served piping hot.', price: 120, serving: 'Mug', dietary: 'Veg', note: 'Cozy Pick' },
      { id: 'cof-mocha', categoryId: 'tea-coffee', subCategory: 'Coffee', name: 'Mocha Coffee', description: 'Dark chocolate melted into espresso and creamy steamed milk.', price: 120, serving: 'Mug', dietary: 'Veg' },
    ],
  },
  {
    id: 'cold-coffee',
    groupId: 'beverages',
    title: 'Cold Coffee',
    shortTitle: 'Cold Coffee',
    subtitle: 'Chilled blended brews, iced lattes, and creamy cold coco — all customizable to taste.',
    atmosphereNote: 'Chilled & Swirling · Customizable',
    gifUrl: '/assets/gifs/cold-coffee.gif',
    items: [
      { id: 'cc-classic', categoryId: 'cold-coffee', name: 'Cold Coffee', description: 'Signature creamy blended iced coffee whipped frothy.', price: 100, serving: '350 ml', dietary: 'Veg', customizable: true, note: 'Bestseller' },
      { id: 'cc-ice-americano', categoryId: 'cold-coffee', name: 'Ice Americano Coffee', description: 'Crisp espresso poured over crystal ice and chilled water.', price: 130, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-vietnamese', categoryId: 'cold-coffee', name: 'Ice Vietnamese Coffee', description: 'Bold slow-style iced coffee sweetened with silky condensed milk.', price: 130, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-cold-coco', categoryId: 'cold-coffee', name: 'Cold Coco', description: 'Gujarat’s favorite thick, chilled velvety dark chocolate drink.', price: 150, serving: '350 ml', dietary: 'Veg', customizable: true, note: 'House Favorite' },
      { id: 'cc-hazelnut', categoryId: 'cold-coffee', name: 'Hazelnut Coffee', description: 'Chilled espresso infused with toasted hazelnut aroma.', price: 150, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-oreo', categoryId: 'cold-coffee', name: 'Oreo Coffee', description: 'Creamy cold coffee blended with crunchy Oreo cookies.', price: 150, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-frappuccino', categoryId: 'cold-coffee', name: 'Frappuccino Coffee', description: 'Rich ice-blended cafe frappe with velvety crema.', price: 160, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-ice-mocha', categoryId: 'cold-coffee', name: 'Ice Mocha Coffee', description: 'Chilled espresso layered with chocolate syrup and cold milk.', price: 160, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-caramel-macchiato', categoryId: 'cold-coffee', name: 'Iced Caramel Macchiato', description: 'Layered chilled milk, espresso, and golden buttery caramel.', price: 170, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-thai', categoryId: 'cold-coffee', name: 'Thai Iced Coffee', description: 'Aromatic sweet creamy spiced coffee served over ice.', price: 180, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-whipped', categoryId: 'cold-coffee', name: 'Whipped Coffee', description: 'Cloud-like whipped coffee foam over chilled velvety milk.', price: 180, serving: '350 ml', dietary: 'Veg', customizable: true },
      { id: 'cc-spanish', categoryId: 'cold-coffee', name: 'Spanish Iced Latte', description: 'Indulgent condensed-milk iced latte with rich espresso crema.', price: 200, serving: '350 ml', dietary: 'Veg', customizable: true, note: 'Signature' },
    ],
  },
  {
    id: 'milkshakes',
    groupId: 'beverages',
    title: 'Milk Shakes',
    shortTitle: 'Milk Shakes',
    subtitle: 'Thick, chilled dessert shakes spun fresh with real fruits, dry fruits, and chocolates.',
    atmosphereNote: 'Thick & Creamy · Spun Fresh',
    gifUrl: '/assets/gifs/milkshakes.gif',
    items: [
      { id: 'ms-vanilla', categoryId: 'milkshakes', name: 'Vanilla Milk Shake', description: 'Classic smooth chilled vanilla bean milkshake.', price: 100, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-gulab', categoryId: 'milkshakes', name: 'Gulab Milk Shake', description: 'Fragrant chilled rose petal milkshake with rich creaminess.', price: 140, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-strawberry', categoryId: 'milkshakes', name: 'Strawberry Milk Shake', description: 'Fruity, bright pink strawberry shake blended silky.', price: 140, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-banana', categoryId: 'milkshakes', name: 'Banana Milk Shake', description: 'Wholesome, creamy ripe banana chilled milkshake.', price: 150, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-mango', categoryId: 'milkshakes', name: 'Mango Milk Shake', description: 'Lush tropical mango milkshake spun thick and chilled.', price: 150, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-chocolate', categoryId: 'milkshakes', name: 'Chocolate Milk Shake', description: 'Deep, rich chocolate shake finished with cocoa richness.', price: 160, serving: '350 ml', dietary: 'Veg', note: 'Bestseller' },
      { id: 'ms-oreo', categoryId: 'milkshakes', name: 'Oreo Milk Shake', description: 'Crushed Oreo cookies folded into thick vanilla-cream shake.', price: 160, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-pineapple', categoryId: 'milkshakes', name: 'Pineapple Milk Shake', description: 'Refreshing sweet-tangy chilled pineapple milkshake.', price: 160, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-butterscotch', categoryId: 'milkshakes', name: 'Butterscotch Milk Shake', description: 'Caramelized butterscotch praline spun into creamy chilled milk.', price: 170, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-kitkat', categoryId: 'milkshakes', name: 'KitKat Milk Shake', description: 'Crispy chocolate wafer blended thick into chilled chocolate cream.', price: 170, serving: '350 ml', dietary: 'Veg', note: 'Crowd Favorite' },
      { id: 'ms-honey-walnut', categoryId: 'milkshakes', name: 'Honey Walnut Milk Shake', description: 'Toasted walnuts and golden honey blended into a rich shake.', price: 190, serving: '350 ml', dietary: 'Veg' },
      { id: 'ms-kaju-anjir', categoryId: 'milkshakes', name: 'Kaju Anjir Milk Shake', description: 'Royal blend of roasted cashews and sweet figs.', price: 190, serving: '350 ml', dietary: 'Veg', note: 'Signature' },
    ],
  },
  {
    id: 'summer-coolers',
    groupId: 'beverages',
    title: 'Sip Into Summer & Coolers',
    shortTitle: 'Summer Coolers',
    subtitle: 'Sparkling garden mojitos, tropical coolers, and chilled soft drinks & water bottles.',
    atmosphereNote: 'Sparkling Garden Fizz · Served Chilled',
    gifUrl: '/assets/gifs/summer-coolers.gif',
    items: [
      { id: 'sc-aam-panna', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Aam Panna Mojito', description: 'Tangy raw mango cooler muddled with mint and fizz.', price: 80, serving: '350 ml', dietary: 'Veg', note: 'Garden Favorite' },
      { id: 'sc-mint-mojito', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Mint Virgin Mojito', description: 'Fresh crushed mint, zesty lime, and sparkling soda over ice.', price: 80, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-berry-bliss', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Berry Bliss', description: 'Vibrant mixed berry spritz served ice-cold.', price: 120, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-citrus-sparkler', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Citrus Sparkler', description: 'Zesty orange-lemon botanical fizz with crisp bubbles.', price: 120, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-tropical-cooler', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Tropical Cooler', description: 'Sun-ripened tropical fruit cooler poured over crushed ice.', price: 120, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-apple-ginger', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Apple Ginger Spritz', description: 'Crisp orchard apple balanced with warm spiced ginger fizz.', price: 130, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-cucumber-mint', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Cucumber Mint Fizz', description: 'Cooling garden cucumber and mint sparkling refresher.', price: 130, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-pomegranate', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Pomegranate Mojito', description: 'Ruby pomegranate juice muddled with mint and fresh lime.', price: 140, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-watermelon', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Watermelon Breeze', description: 'Chilled summer watermelon cooler with crisp mint notes.', price: 140, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-blue-ocean', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Blue Ocean', description: 'Electric blue curacao-style citrus mocktail over sparkling ice.', price: 150, serving: '350 ml', dietary: 'Veg', note: 'Bestseller' },
      { id: 'sc-pinacolada', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Pinacolada', description: 'Creamy chilled coconut and sweet pineapple island blend.', price: 150, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-strawberry-splash', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Strawberry Splash', description: 'Sparkling strawberry refresher finished with crushed ice.', price: 150, serving: '350 ml', dietary: 'Veg' },
      { id: 'sc-fruit-flash', categoryId: 'summer-coolers', subCategory: 'Sip Into Summer', name: 'Fruit Flash', description: 'House layered mixed-fruit punch bursting with garden freshness.', price: 170, serving: '350 ml', dietary: 'Veg' },

      { id: 'wb-500ml', categoryId: 'summer-coolers', subCategory: 'Water & Soft Drinks', name: 'Water Bottle 500 Ml', description: 'Sealed chilled 500 ml packaged drinking water.', price: 10, serving: '500 ml', dietary: 'Veg' },
      { id: 'wb-1ltr', categoryId: 'summer-coolers', subCategory: 'Water & Soft Drinks', name: 'Water Bottle 1 Ltr', description: 'Sealed chilled 1 litre packaged drinking water.', price: 20, serving: '1 Ltr', dietary: 'Veg' },
      { id: 'wb-sprite', categoryId: 'summer-coolers', subCategory: 'Water & Soft Drinks', name: 'Sprite', description: 'Chilled crisp lemon-lime sparkling bottle.', price: 20, serving: 'Bottle', dietary: 'Veg' },
      { id: 'wb-thumsup', categoryId: 'summer-coolers', subCategory: 'Water & Soft Drinks', name: 'Thums Up', description: 'Chilled bold fizzy cola bottle.', price: 20, serving: 'Bottle', dietary: 'Veg' },
    ],
  },

  // =========================================================================
  // CAFE BITES & MAINS (111 items across 11 categories)
  // =========================================================================
  {
    id: 'burgers',
    groupId: 'food',
    title: 'Delicious Burgers',
    shortTitle: 'Burgers',
    subtitle: 'Toasted buns stacked with crispy house patties, melted cheese, and garden dressings.',
    atmosphereNote: 'Grilled to Order · Warm & Hearty',
    gifUrl: '/assets/gifs/burgers.gif',
    items: [
      { id: 'bg-tikki', categoryId: 'burgers', name: 'Tikki Burger', description: 'Crispy spiced aloo tikki with fresh onion, tomato, and house sauces.', price: 80, serving: '1 Burger', dietary: 'Veg' },
      { id: 'bg-veg', categoryId: 'burgers', name: 'Veg Burger', description: 'Golden garden vegetable patty in a warm toasted bun.', price: 100, serving: '1 Burger', dietary: 'Veg' },
      { id: 'bg-tawa', categoryId: 'burgers', name: 'Tawa Burger', description: 'Butter-griddled desi masala tawa burger loaded with spices.', price: 120, serving: '1 Burger', dietary: 'Veg' },
      { id: 'bg-classic', categoryId: 'burgers', name: 'Classic Burger', description: 'Crispy cafe patty with cheddar slice, crisp lettuce, and creamy mayo.', price: 140, serving: '1 Burger', dietary: 'Veg' },
      { id: 'bg-mania', categoryId: 'burgers', name: 'Mania Burger', description: 'Loaded saucy burger stacked with crispy veggies and zesty drizzle.', price: 150, serving: '1 Burger', dietary: 'Veg' },
      { id: 'bg-momo', categoryId: 'burgers', name: 'Momo Burger', description: 'Fusion favorite featuring crispy momos tucked inside a spicy bun.', price: 150, serving: '1 Burger', dietary: 'Veg', note: 'Chef Fusion' },
      { id: 'bg-immys-spe', categoryId: 'burgers', name: "Immy's Special Burger", description: 'Our grand signature garden burger with double richness and house sauce.', price: 200, serving: '1 Burger', dietary: 'Veg', note: 'Signature' },
    ],
  },
  {
    id: 'sandwiches',
    groupId: 'food',
    title: 'Cheese Sandwiches',
    shortTitle: 'Sandwiches',
    subtitle: 'Golden grilled sandwiches, open toasts, and sweet slices — all customizable.',
    atmosphereNote: 'Crisp & Cheesy · Customizable',
    gifUrl: '/assets/gifs/sandwiches.gif',
    items: [
      { id: 'sw-bread-butter', categoryId: 'sandwiches', name: 'Bread Butter Slice', description: 'Soft fresh bread generously layered with creamy salted butter.', price: 30, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-bread-jam', categoryId: 'sandwiches', name: 'Bread Jam Slice', description: 'Classic comforting mixed-fruit jam and butter bread slice.', price: 30, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-sing-slice', categoryId: 'sandwiches', name: 'Sing Slice', description: 'Crunchy spiced masala peanut spread on buttered bread.', price: 30, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-peanut-butter', categoryId: 'sandwiches', name: 'Peanut Butter Slice', description: 'Rich creamy roasted peanut butter on warm sliced bread.', price: 40, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-cheese-chutney', categoryId: 'sandwiches', name: 'Cheese Chutney Sandwich', description: 'Fresh green coriander-mint chutney paired with grated cheese.', price: 50, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-chocolate-slice', categoryId: 'sandwiches', name: 'Chocolate Slice', description: 'Warm toasted slice drizzled generously with melted chocolate.', price: 50, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-chilli-garlic', categoryId: 'sandwiches', name: 'Cheese Chilli Garlic Sandwich', description: 'Garlicky green chili butter and melted cheese toasted crisp.', price: 60, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-veg', categoryId: 'sandwiches', name: 'Veg Sandwich', description: 'Garden cucumber, tomato, potato, and green chutney classic.', price: 60, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-aloo-mutter', categoryId: 'sandwiches', name: 'Aloo Mutter Sandwich', description: 'Spiced mashed potato and green pea filling grilled golden.', price: 80, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-cheese-chili-open', categoryId: 'sandwiches', name: 'Cheese Chili Open Toast', description: 'Open-faced toasted bread bubbling with chili and molten cheese.', price: 80, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-paneer-open', categoryId: 'sandwiches', name: 'Paneer Open Toast', description: 'Spiced cottage cheese and melted cheese on crisp open toast.', price: 80, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-veg-cheese', categoryId: 'sandwiches', name: 'Veg Cheese Sandwich', description: 'Loaded garden vegetables layered with generous melted cheese.', price: 80, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-aloo-mutter-cheese', categoryId: 'sandwiches', name: 'Aloo Mutter Cheese Sandwich', description: 'Savory aloo mutter masala topped with gooey melted cheese.', price: 100, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-aloo-tikki', categoryId: 'sandwiches', name: 'Aloo Tikki Sandwich', description: 'Crispy golden aloo tikki pressed inside a spiced toasted sandwich.', price: 110, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'sw-cheese-corn', categoryId: 'sandwiches', name: 'Cheese Corn Sandwich', description: 'Sweet golden corn kernels folded into creamy herb-cheese melt.', price: 120, serving: 'Plate', dietary: 'Veg', customizable: true, note: 'Bestseller' },
      { id: 'sw-tandoori-paneer', categoryId: 'sandwiches', name: 'Tandoori Paneer Sandwich', description: 'Smoky tandoori-marinated paneer grilled golden with cheese.', price: 130, serving: 'Plate', dietary: 'Veg', customizable: true, note: 'Popular' },
      { id: 'sw-club', categoryId: 'sandwiches', name: 'Club Sandwich', description: 'Triple-decker toasted garden club packed with veggies and cheese.', price: 140, serving: 'Triple Deck', dietary: 'Veg', customizable: true },
      { id: 'sw-immys-spe', categoryId: 'sandwiches', name: "Immy's Special Sandwich", description: 'Chef’s loaded signature sandwich with rich fillings and cheese.', price: 140, serving: 'House Special', dietary: 'Veg', customizable: true, note: 'Signature' },
    ],
  },
  {
    id: 'fries-bread',
    groupId: 'food',
    title: 'Fries & Garlic Bread',
    shortTitle: 'Fries & Bread',
    subtitle: 'Crisp specialty potato fries, cheesy pops, and warm herb-butter garlic breads.',
    atmosphereNote: 'Hot & Crispy · Shareable Plates',
    gifUrl: '/assets/gifs/fries-bread.gif',
    items: [
      { id: 'fr-salted', categoryId: 'fries-bread', subCategory: 'Fries', name: 'French Fries Salted Fries', description: 'Golden crisp classic potato fries tossed in fine sea salt.', price: 90, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-peri-peri', categoryId: 'fries-bread', subCategory: 'Fries', name: 'French Fries Peri Peri Fries', description: 'Crisp fries dusted generously with tangy-spicy peri peri seasoning.', price: 100, serving: 'Basket', dietary: 'Veg', note: 'Bestseller' },
      { id: 'fr-wedges', categoryId: 'fries-bread', subCategory: 'Fries', name: 'Potato Wedges Fries', description: 'Thick-cut seasoned herb potato wedges fried golden.', price: 100, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-aloo-tikki', categoryId: 'fries-bread', subCategory: 'Fries', name: 'Fried Aloo Tikki Fries', description: 'Crisp spiced potato tikki strips served piping hot.', price: 120, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-accordion', categoryId: 'fries-bread', subCategory: 'Fries', name: 'Accordion Potato Fries', description: 'Crunchy spiral-cut accordion potato bites seasoned warm.', price: 130, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-cheese', categoryId: 'fries-bread', subCategory: 'Fries', name: 'French Fries Cheese Fries', description: 'Crispy fries drizzled heavily with warm liquid cheddar sauce.', price: 130, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-hasselback', categoryId: 'fries-bread', subCategory: 'Fries', name: 'Hasselback Potatoes Fries', description: 'Fanned crispy hasselback potatoes roasted with herb butter.', price: 130, serving: 'Plate', dietary: 'Veg' },
      { id: 'fr-cheese-pops', categoryId: 'fries-bread', subCategory: 'Fries', name: 'Cheese Potato Pops Fries', description: 'Bite-sized crunchy potato pops oozing warm melted cheese.', price: 150, serving: 'Basket', dietary: 'Veg' },
      { id: 'fr-signature', categoryId: 'fries-bread', subCategory: 'Fries', name: 'French Fries Signature Fries', description: 'Loaded house-style fries finished with specialty sauces and herbs.', price: 150, serving: 'Basket', dietary: 'Veg', note: 'Signature' },

      { id: 'br-garlic', categoryId: 'fries-bread', subCategory: 'Garlic Bread', name: 'Garlic Bread', description: 'Warm baked crusty slices brushed with roasted garlic herb butter.', price: 100, serving: '4 pcs', dietary: 'Veg' },
      { id: 'br-supreme', categoryId: 'fries-bread', subCategory: 'Garlic Bread', name: 'Supreme Garlic Bread', description: 'Cheesy garlic bread topped with sweet corn, herbs, and jalapenos.', price: 120, serving: '4 pcs', dietary: 'Veg' },
      { id: 'br-zingi', categoryId: 'fries-bread', subCategory: 'Garlic Bread', name: 'Paneer Zingi Parcel', description: 'Flaky golden baked parcel stuffed with tangy spiced paneer.', price: 140, serving: 'Plate', dietary: 'Veg', note: 'Popular' },
      { id: 'br-stuffed', categoryId: 'fries-bread', subCategory: 'Garlic Bread', name: 'Stuffed Garlic Bread', description: 'Oven-baked pull-apart garlic bread packed with molten cheese & corn.', price: 160, serving: 'Full Loaf', dietary: 'Veg', note: 'Bestseller' },
    ],
  },
  {
    id: 'specials-pakode',
    groupId: 'food',
    title: 'Cafe Specials & Pakode',
    shortTitle: 'Specials & Pakode',
    subtitle: 'Signature cafe starters, sizzling paneer tikka, and crisp monsoon-style bhajiya & pakode.',
    atmosphereNote: 'Fresh from the Kitchen · Garden Platter',
    gifUrl: '/assets/gifs/specials-pakode.gif',
    items: [
      { id: 'sp-paper-samosa', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Paper Samosa', description: 'Ultra-thin crispy layered samosas filled with savory spiced stuffing.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-biscuit-pie', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Biscuit Pie', description: 'Crunchy house savory-baked biscuit pie layered with flavor.', price: 120, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-dabeli', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Signature Dabeli', description: 'Kutchi-style spiced potato dabeli studded with masala peanuts and sev.', price: 120, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-taco-veg', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Taco Veg', description: 'Crisp taco shells loaded with seasoned veggies and tangy salsa.', price: 120, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-thatte-idly', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Thatte Idly', description: 'Soft pillowy South-style plate idli brushed with ghee and podi.', price: 120, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-litti-chokha', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Litti Chokha', description: 'Traditional ghee-dipped roasted wheat litti served with smoky chokha.', price: 140, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-spring-roll', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Spring Roll', description: 'Golden crisp vegetable spring rolls served with sweet chili dip.', price: 140, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-biryani', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Hyderabadi Biryani', description: 'Fragrant saffron-spiced basmati vegetable biryani served warm.', price: 150, serving: 'Bowl', dietary: 'Veg', note: 'Filling' },
      { id: 'sp-hara-bhara', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Hara Bhara Kabab', description: 'Crisp spinach, green pea, and spiced paneer medallions.', price: 150, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-taco-paneer', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Taco Paneer', description: 'Crunchy tacos filled with smoky spiced paneer and creamy drizzle.', price: 150, serving: 'Plate', dietary: 'Veg' },
      { id: 'sp-dry-paneer-tikka', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Dry Paneer Tikka', description: 'Char-grilled marinated paneer cubes tossed with roasted peppers.', price: 170, serving: 'Plate', dietary: 'Veg', note: 'Bestseller' },
      { id: 'sp-thecha-paneer', categoryId: 'specials-pakode', subCategory: 'Special', name: 'Thecha Paneer', description: 'Bold rustic green chili-garlic thecha tossed over soft grilled paneer.', price: 170, serving: 'Plate', dietary: 'Veg', note: 'Chef Special' },

      { id: 'pk-aloo-chips', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Aloo Chips Bhajiya', description: 'Paper-thin potato slices dipped in spiced gram flour batter and fried crisp.', price: 50, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-mirchi-patti', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Mirchi Patti Bhajiya', description: 'Crispy golden green chili fritters seasoned with tangy chaat masala.', price: 50, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-onion', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Onion Pakoda', description: 'Crunchy spiced onion kanda bhajiya served hot with chutney.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-palak-methi', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Palak Methi Gota', description: 'Fluffy, aromatic Gujarati spinach and fenugreek fritters.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-bataka-vada', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Bataka Vada', description: 'Golden spiced potato dumplings in a crisp besan crust.', price: 70, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-bread-vada', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Bread Vada', description: 'Hearty spiced potato stuffed bread vada fried golden brown.', price: 70, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-onion-ring', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Onion Ring Pakoda', description: 'Crisp batter-fried golden onion rings served with tangy dip.', price: 70, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-bread-pakoda', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Bread Pakoda', description: 'Classic stuffed triangle bread pakoda fried crisp and hot.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-paneer', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Paneer Pakoda', description: 'Soft masala-layered cottage cheese slices in a golden crisp coat.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'pk-combo-platter', categoryId: 'specials-pakode', subCategory: 'Onion & Aloo Pakode', name: 'Combo Pakoda Platter', description: 'Assorted sharing platter of hot onion, aloo, gota, and paneer pakode.', price: 170, serving: 'Sharing Platter', dietary: 'Veg', note: 'Great to Share' },
    ],
  },
  {
    id: 'chaat',
    groupId: 'food',
    title: 'Street Food Chaat',
    shortTitle: 'Chaat',
    subtitle: 'Crisp, tangy, sweet-and-spicy garden chaat plates made fresh to order.',
    atmosphereNote: 'Tangy, Crisp & Chilled · Freshly Assembled',
    gifUrl: '/assets/gifs/chaat.gif',
    items: [
      { id: 'ch-panipuri', categoryId: 'chaat', name: 'Panipuri', description: 'Crisp hollow puris served with chilled spiced mint water and stuffing.', price: 50, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-dahi-puri', categoryId: 'chaat', name: 'Dahi Puri', description: 'Crisp puris topped with chilled sweet curd, chutneys, and nylon sev.', price: 70, serving: 'Plate', dietary: 'Veg', note: 'Bestseller' },
      { id: 'ch-papadi-puri', categoryId: 'chaat', name: 'Papadi Puri', description: 'Crunchy flat papdis layered with spiced potatoes, curd, and chutneys.', price: 70, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-aloo-tikki', categoryId: 'chaat', name: 'Aloo Tikki Chaat', description: 'Crisp tawa aloo tikki drowned in chilled yogurt and tangy chutneys.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-corn-capsicum', categoryId: 'chaat', name: 'Corn Capsicum Chaat', description: 'Zesty warm sweet corn and crisp bell pepper masala chaat.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-delhi-basket', categoryId: 'chaat', name: 'Delhi Basket Chaat', description: 'Edible crispy potato basket overflowing with dahi, chutneys, and spices.', price: 80, serving: 'Plate', dietary: 'Veg', note: 'Garden Favorite' },
      { id: 'ch-soji-panipuri', categoryId: 'chaat', name: 'Soji Panipuri', description: 'Extra-crunchy semolina puris paired with tangy chilled pani.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-mumbai-bhel', categoryId: 'chaat', name: 'Mumbai Special Sukhi Bhel', description: 'Dry tossed puffed rice with peanuts, tangy chutneys, onion, and sev.', price: 100, serving: 'Plate', dietary: 'Veg' },
      { id: 'ch-raj-kachori', categoryId: 'chaat', name: 'Raj Kachori', description: 'Royal giant crisp kachori stuffed with chilled dahi, sprouts, and chutneys.', price: 120, serving: 'Plate', dietary: 'Veg', note: 'Signature' },
    ],
  },
  {
    id: 'soups',
    groupId: 'food',
    title: 'Special Soup',
    shortTitle: 'Special Soup',
    subtitle: 'Wholesome, slow-simmered garden evening soups served piping hot.',
    atmosphereNote: 'Simmered Warm · Evening Comfort',
    gifUrl: '/assets/gifs/soups.gif',
    items: [
      { id: 'sp-mix-veg', categoryId: 'soups', name: 'Mix Veg Soup', description: 'Comforting clear-style garden vegetable broth with subtle pepper.', price: 120, serving: 'Bowl', dietary: 'Veg' },
      { id: 'sp-garlic', categoryId: 'soups', name: 'Garlic Soup', description: 'Aromatic roasted garlic soup infused with gentle herbs and warmth.', price: 140, serving: 'Bowl', dietary: 'Veg' },
      { id: 'sp-bajra', categoryId: 'soups', name: 'Bajra Soup', description: 'Nourishing traditional millet soup tempered with warm spices.', price: 150, serving: 'Bowl', dietary: 'Veg', note: 'Regional Special' },
      { id: 'sp-sargva', categoryId: 'soups', name: 'Sargva Soup', description: 'Wholesome, velvety drumstick (moringa) soup rich in earthy flavor.', price: 150, serving: 'Bowl', dietary: 'Veg' },
      { id: 'sp-broccoli-almond', categoryId: 'soups', name: 'Broccoli Almond Soup', description: 'Creamy roasted almond and garden broccoli velouté.', price: 170, serving: 'Bowl', dietary: 'Veg', note: 'Chef Pick' },
    ],
  },
  {
    id: 'wraps',
    groupId: 'food',
    title: 'Wraps',
    shortTitle: 'Wraps',
    subtitle: 'Warm char-grilled wraps stuffed with spiced paneer, veggies, momos, and sauces.',
    atmosphereNote: 'Grilled & Rolled Fresh · Easy Garden Bite',
    gifUrl: '/assets/gifs/wraps.gif',
    items: [
      { id: 'wr-veg-delight', categoryId: 'wraps', name: 'Veg Delight Wrap', description: 'Crisp garden vegetables and creamy dressing rolled in a warm wrap.', price: 100, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-paneer-tikka', categoryId: 'wraps', name: 'Paneer Tikka Wrap', description: 'Smoky tandoori paneer tikka with mint mayo and crisp onions.', price: 130, serving: '1 Wrap', dietary: 'Veg', note: 'Bestseller' },
      { id: 'wr-cheese', categoryId: 'wraps', name: 'Cheese Wrap', description: 'Melted gooey cheese folded with seasoned vegetables and herbs.', price: 150, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-italian-veg', categoryId: 'wraps', name: 'Italian Veg Wrap', description: 'Herbed Italian veggies, tangy marinara, and cheese grilled warm.', price: 150, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-grilled-veggie', categoryId: 'wraps', name: 'Grilled Veggie Wrap', description: 'Char-grilled peppers, zucchini, corn, and creamy sauce.', price: 160, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-momo', categoryId: 'wraps', name: 'Momo Wrap', description: 'Tossed crispy momos and spicy chili sauce wrapped to perfection.', price: 180, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-kabab', categoryId: 'wraps', name: 'Kabab Wrap', description: 'Savory grilled veg kababs paired with mint chutney and onions.', price: 190, serving: '1 Wrap', dietary: 'Veg' },
      { id: 'wr-immys-spe', categoryId: 'wraps', name: "Immy's Special Wrap", description: 'Our signature loaded garden wrap with double filling and house sauces.', price: 200, serving: '1 Wrap', dietary: 'Veg', note: 'Signature' },
    ],
  },
  {
    id: 'momos',
    groupId: 'food',
    title: 'Momos',
    shortTitle: 'Momos',
    subtitle: 'Steaming hot handcrafted dumplings served with fiery house chili-garlic dip.',
    atmosphereNote: 'Steamed & Saucy · Served Piping Hot',
    gifUrl: '/assets/gifs/momos.gif',
    items: [
      { id: 'mm-veg', categoryId: 'momos', name: 'Veg Momos', description: 'Delicate steamed dumplings stuffed with finely chopped spiced veggies.', price: 100, serving: 'Plate', dietary: 'Veg' },
      { id: 'mm-paneer', categoryId: 'momos', name: 'Paneer Momos', description: 'Plump momos filled with seasoned crumbled cottage cheese and herbs.', price: 120, serving: 'Plate', dietary: 'Veg' },
      { id: 'mm-cheese', categoryId: 'momos', name: 'Cheese Momos', description: 'Warm melty cheese and veggie stuffed momos served with red dip.', price: 130, serving: 'Plate', dietary: 'Veg', note: 'Popular' },
      { id: 'mm-immys-gravy', categoryId: 'momos', name: "Immy's Special Gravy Momos", description: 'Soft momos tossed generously in rich, creamy spiced house gravy.', price: 150, serving: 'Plate', dietary: 'Veg', note: 'Signature' },
    ],
  },
  {
    id: 'maggi',
    groupId: 'food',
    title: 'Maggi',
    shortTitle: 'Maggi',
    subtitle: 'Everyone’s favorite open-air evening comfort noodles, from classic to cheesy tadka.',
    atmosphereNote: 'Evening Comfort · Piping Hot Bowl',
    gifUrl: '/assets/gifs/maggi.gif',
    items: [
      { id: 'mg-plain', categoryId: 'maggi', name: 'Plain Maggi', description: 'Classic comforting hot noodles cooked just right.', price: 60, serving: 'Bowl', dietary: 'Veg' },
      { id: 'mg-masala', categoryId: 'maggi', name: 'Masala Maggi', description: 'Extra-flavorful cafe masala Maggi simmered rich and aromatic.', price: 70, serving: 'Bowl', dietary: 'Veg', note: 'Garden Classic' },
      { id: 'mg-veggie', categoryId: 'maggi', name: 'Veggie Maggi', description: 'Loaded with crunchy sweet corn, green peas, onions, and peppers.', price: 80, serving: 'Bowl', dietary: 'Veg' },
      { id: 'mg-chilli-garlic', categoryId: 'maggi', name: 'Chilli Garlic Maggi', description: 'Fiery roasted garlic and red chili tossed noodles.', price: 100, serving: 'Bowl', dietary: 'Veg' },
      { id: 'mg-paneer', categoryId: 'maggi', name: 'Paneer Maggi', description: 'Warm masala Maggi topped with soft spiced cottage cheese cubes.', price: 100, serving: 'Bowl', dietary: 'Veg' },
      { id: 'mg-tadka', categoryId: 'maggi', name: 'Tadka Maggi', description: 'Finished with a sizzling buttery desi spice tadka.', price: 100, serving: 'Bowl', dietary: 'Veg' },
      { id: 'mg-cheese', categoryId: 'maggi', name: 'Cheese Maggi', description: 'Rich, creamy melted cheese folded generously through hot masala Maggi.', price: 120, serving: 'Bowl', dietary: 'Veg', note: 'Bestseller' },
    ],
  },
  {
    id: 'gujarati-snacks',
    groupId: 'food',
    title: 'Gujarati Snacks',
    shortTitle: 'Gujarati Snacks',
    subtitle: 'Authentic, homestyle Gujarati tea-time favorites served warm and fresh.',
    atmosphereNote: 'Homestyle Gujarat Flavors · Pairs with Chai',
    gifUrl: '/assets/gifs/gujarati-snacks.gif',
    items: [
      { id: 'gj-bajri-khakhra', categoryId: 'gujarati-snacks', name: 'Bajri Khakhra', description: 'Crisp roasted pearl millet khakhra, light and nutty.', price: 40, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-hot-khari', categoryId: 'gujarati-snacks', name: 'Hot Khari Biscuits', description: 'Flaky, golden oven-warm puff pastry khari biscuits.', price: 40, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-oats', categoryId: 'gujarati-snacks', name: 'Oats', description: 'Warm savory spiced masala oats bowl for a wholesome bite.', price: 50, serving: 'Bowl', dietary: 'Veg' },
      { id: 'gj-samosa', categoryId: 'gujarati-snacks', name: 'Samosa', description: 'Crisp golden pastry triangles stuffed with spiced potato-pea filling.', price: 50, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-besan-chilla', categoryId: 'gujarati-snacks', name: 'Besan Chilla', description: 'Savory spiced gram-flour pancake cooked crisp on the griddle.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-dhokla', categoryId: 'gujarati-snacks', name: 'Dhokla', description: 'Soft steamed golden dhokla tempered with mustard seeds and curry leaves.', price: 60, serving: 'Plate', dietary: 'Veg', note: 'Classic' },
      { id: 'gj-handvo', categoryId: 'gujarati-snacks', name: 'Handvo', description: 'Traditional crisp sesame-crusted savory lentil and veggie cake.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-muthiya', categoryId: 'gujarati-snacks', name: 'Muthiya', description: 'Steamed and tempered methi-spiced Gujarati muthiya bites.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-indori-poha', categoryId: 'gujarati-snacks', name: 'Special Indori Poha', description: 'Fluffy flattened rice topped with crunchy sev, peanuts, and lemon.', price: 60, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-upma', categoryId: 'gujarati-snacks', name: 'Upma', description: 'Warm roasted semolina tempered with curry leaves and peanuts.', price: 60, serving: 'Bowl', dietary: 'Veg' },
      { id: 'gj-masala-khichiya', categoryId: 'gujarati-snacks', name: 'Masala Khichiya', description: 'Roasted crisp rice papad topped with spiced onion, tomato, and sev.', price: 80, serving: 'Plate', dietary: 'Veg' },
      { id: 'gj-thepla', categoryId: 'gujarati-snacks', name: 'Thepla', description: 'Soft, aromatic fenugreek-spiced Gujarati flatbreads served warm.', price: 80, serving: 'Plate', dietary: 'Veg', note: 'Popular' },
      { id: 'gj-cheese-khichiya', categoryId: 'gujarati-snacks', name: 'Cheese Khichiya', description: 'Crispy masala khichiya finished with a generous snowfall of grated cheese.', price: 100, serving: 'Plate', dietary: 'Veg' },
    ],
  },
  {
    id: 'pizza',
    groupId: 'food',
    title: 'Pizza',
    shortTitle: 'Pizza',
    subtitle: 'Oven-baked cheesy garden pizzas and layered specials — all customizable.',
    atmosphereNote: 'Bubbling Cheese · Customizable',
    gifUrl: '/assets/gifs/pizza.gif',
    items: [
      { id: 'pz-bread', categoryId: 'pizza', name: 'Bread Pizza', description: 'Crisp toasted bread topped with spiced sauce, veggies, and melted cheese.', price: 60, serving: 'Plate', dietary: 'Veg', customizable: true },
      { id: 'pz-topping', categoryId: 'pizza', name: 'Topping Pizza', description: 'Freshly baked base with classic garden vegetable toppings and cheese.', price: 80, serving: 'Regular', dietary: 'Veg', customizable: true },
      { id: 'pz-margherita', categoryId: 'pizza', name: 'Margherita Pizza', description: 'Classic tangy tomato sauce blanketed in bubbling mozzarella cheese.', price: 100, serving: 'Regular', dietary: 'Veg', customizable: true },
      { id: 'pz-italian', categoryId: 'pizza', name: 'Italian Pizza', description: 'Oregano-scented marinara, olives, peppers, and golden melted cheese.', price: 120, serving: 'Regular', dietary: 'Veg', customizable: true },
      { id: 'pz-tandoori-paneer', categoryId: 'pizza', name: 'Tandoori Paneer Pizza', description: 'Smoky tandoori cottage cheese, crisp onions, peppers, and mozzarella.', price: 130, serving: 'Regular', dietary: 'Veg', customizable: true, note: 'Bestseller' },
      { id: 'pz-classic-mania', categoryId: 'pizza', name: 'Classic Mania Pizza', description: 'Loaded with colorful veggies, sweet corn, and rich pizza sauce.', price: 140, serving: 'Regular', dietary: 'Veg', customizable: true },
      { id: 'pz-double-cheese', categoryId: 'pizza', name: 'Double Cheese Pizza', description: 'Extra-indulgent double layer of molten mozzarella and cheddar.', price: 150, serving: 'Regular', dietary: 'Veg', customizable: true },
      { id: 'pz-3-layer', categoryId: 'pizza', name: '3 Layer Special Pizza', description: 'Triple-layered cheesy crust masterpiece packed with savory toppings.', price: 180, serving: 'House Special', dietary: 'Veg', customizable: true, note: 'Crowd Favorite' },
      { id: 'pz-immys-spe', categoryId: 'pizza', name: "Immy's Special Pizza", description: 'Our signature fully loaded garden cafe pizza with chef’s blend.', price: 200, serving: 'Signature', dietary: 'Veg', customizable: true, note: 'Signature' },
    ],
  },

  // =========================================================================
  // FRESH HOT SWEETS, COMBOS & CLUB GAMES (8 items across 2 categories)
  // =========================================================================
  {
    id: 'hot-sweets',
    groupId: 'sweets-club',
    title: 'Fresh Hot Sweets',
    shortTitle: 'Hot Sweets',
    subtitle: 'Warm, indulgent freshly prepared Indian sweets and molten chocolate dessert.',
    atmosphereNote: 'Served Piping Hot · Sweet Garden Finale',
    gifUrl: '/assets/gifs/hot-sweets.gif',
    items: [
      { id: 'sw-gajar-halvo', categoryId: 'hot-sweets', name: 'Hot Gajar Halvo', description: 'Slow-cooked rich carrot halwa roasted in pure ghee and nuts.', price: 80, serving: 'Bowl', dietary: 'Veg' },
      { id: 'sw-mohanthal', categoryId: 'hot-sweets', name: 'Hot Mohanthal', description: 'Traditional warm Gujarati gram-flour fudge scented with cardamom.', price: 80, serving: 'Bowl', dietary: 'Veg' },
      { id: 'sw-gulabjamun-ic', categoryId: 'hot-sweets', name: 'Hot Gulabjamun With Ice Cream', description: 'Warm syrup-soaked gulab jamun paired with chilled creamy vanilla scoop.', price: 100, serving: 'Bowl', dietary: 'Veg', note: 'Bestseller' },
      { id: 'sw-chocolava', categoryId: 'hot-sweets', name: 'Hot Chocolava', description: 'Warm baked chocolate cake with a flowing molten dark ganache center.', price: 150, serving: '1 Cake', dietary: 'Veg', note: 'House Favorite' },
    ],
  },
  {
    id: 'combos-games',
    groupId: 'sweets-club',
    title: 'Combos & Club Games',
    shortTitle: 'Combos & Games',
    subtitle: 'Our value Combo 149 cafe meal and outdoor Toran Club sports & swimming pool sessions.',
    atmosphereNote: 'Open-Air Toran Club · Food & Play',
    gifUrl: '/assets/gifs/combos-games.gif',
    items: [
      { id: 'cb-149', categoryId: 'combos-games', subCategory: 'Combo', name: 'Combo 149', description: 'IMMY’s curated garden value combo crafted for an effortless cafe treat.', price: 149, serving: 'Combo Meal', dietary: 'Veg', note: 'Value Deal' },
      { id: 'gm-swimming-pool', categoryId: 'combos-games', subCategory: 'Game', name: 'Swimming Pool', description: 'Refreshing open-air Toran Club swimming pool session.', price: 250, serving: 'Session', dietary: 'Club Activity' },
      { id: 'gm-pickleball', categoryId: 'combos-games', subCategory: 'Game', name: 'Pickleball', description: 'Open-air Toran Club pickleball court booking for friends & family.', price: 800, serving: 'Court Slot', dietary: 'Club Activity' },
      { id: 'gm-cricket', categoryId: 'combos-games', subCategory: 'Game', name: 'Cricket', description: 'Floodlit outdoor Toran Club box cricket turf booking.', price: 1200, serving: 'Turf Slot', dietary: 'Club Activity', note: 'Group Play' },
    ],
  },
];

export const MENU_ITEMS_BY_ID: Record<string, MenuItem> = Object.fromEntries(
  MENU_CATEGORIES.flatMap((category) => category.items.map((item) => [item.id, item]))
);
