import { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import {
  ArrowUpRight,
  Clock,
  MapPin,
  Phone,
  QrCode,
  Receipt,
  ShieldCheck,
  ShoppingBag,
} from 'lucide-react';
import { CheckoutDrawer } from './components/CheckoutDrawer';
import { MenuShowcase } from './components/MenuShowcase';
import { OrdersPanel } from './components/OrdersPanel';
import { StaffConsoleDrawer } from './components/StaffConsoleDrawer';
import { TableBookingSection } from './components/TableBookingSection';
import { DEFAULT_WEEKLY_HOURS, WeeklyHoursTable } from './components/WeeklyHoursTable';
import { CAFE_INFO, MENU_CATEGORIES, MENU_ITEMS_BY_ID } from './data/menu';
import {
  auth,
  db,
  emailToManagerId,
  normalizeEmail,
} from './firebase';
import { cafeApi } from './lib/api';
import type {
  CafeOpenStatus,
  CafeOperationsSettings,
  CafeOrder,
  CartEntry,
  GatewayCapabilities,
  OrderItem,
  StaffRole,
  WeeklyOpeningHours,
} from './types';

const DEFAULT_OPERATIONS: CafeOperationsSettings = {
  acceptingOrders: true,
  prepTimeMinutes: 15,
  dailySpecialNotice: '',
  unavailableItemIds: ['cof-hot-chocolate'],
  updatedByRole: 'owner',
};

export default function App() {
  const [activeCategoryId, setActiveCategoryId] = useState<string>(
    MENU_CATEGORIES[0]?.id || ''
  );
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const saved = window.localStorage.getItem('immy_favorites');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed)
        ? parsed.filter((id): id is string => typeof id === 'string' && Boolean(MENU_ITEMS_BY_ID[id]))
        : [];
    } catch {
      return [];
    }
  });
  const [orders, setOrders] = useState<CafeOrder[]>([]);
  const [deletedOrders, setDeletedOrders] = useState<CafeOrder[]>([]);
  const [gateways, setGateways] = useState<GatewayCapabilities>({
    razorpayLive: false,
    cashfreeLive: false,
    cashfreeEnv: 'sandbox',
  });
  const [counterQrDataUrl, setCounterQrDataUrl] = useState<string | null>(null);
  const [weeklyHours, setWeeklyHours] = useState<WeeklyOpeningHours>(DEFAULT_WEEKLY_HOURS);
  const [openStatus, setOpenStatus] = useState<CafeOpenStatus | null>(null);

  // Firebase Owner / Manager RBAC state (Owner identity verified server-side only)
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [staffRole, setStaffRole] = useState<StaffRole>('none');
  const [operations, setOperations] = useState<CafeOperationsSettings>(DEFAULT_OPERATIONS);

  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [ordersOpen, setOrdersOpen] = useState(false);
  const [staffConsoleOpen, setStaffConsoleOpen] = useState(false);
  const [bookingsRefreshSignal, setBookingsRefreshSignal] = useState(0);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((message: string) => {
    setToast(message);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  // Listen to public cafe operational settings from Firestore (live sold-out items)
  useEffect(() => {
    const opsRef = doc(db, 'cafeSettings', 'operations');
    const unsubscribe = onSnapshot(
      opsRef,
      (snap) => {
        if (!snap.exists()) return;
        const d = snap.data();
        setOperations({
          acceptingOrders: typeof d.acceptingOrders === 'boolean' ? d.acceptingOrders : true,
          prepTimeMinutes: typeof d.prepTimeMinutes === 'number' ? d.prepTimeMinutes : 15,
          dailySpecialNotice: typeof d.dailySpecialNotice === 'string' ? d.dailySpecialNotice : '',
          unavailableItemIds: Array.isArray(d.unavailableItemIds)
            ? d.unavailableItemIds.filter((id): id is string => typeof id === 'string')
            : [],
          updatedByUid: typeof d.updatedByUid === 'string' ? d.updatedByUid : undefined,
          updatedByRole: d.updatedByRole === 'manager' ? 'manager' : 'owner',
        });
      },
      () => {
        // Fallback smoothly to server operations if Firestore doc not yet initialized
      }
    );
    return () => unsubscribe();
  }, []);

  // Listen to Firebase Auth & resolve Owner vs Active Manager via server-side /api/staff/me
  useEffect(() => {
    let unsubManagerDoc: (() => void) | null = null;
    let active = true;

    const unsubAuth = onAuthStateChanged(auth, (nextUser) => {
      if (unsubManagerDoc) {
        unsubManagerDoc();
        unsubManagerDoc = null;
      }

      setFirebaseUser(nextUser);
      setAuthReady(true);

      if (!nextUser || !nextUser.email || !nextUser.emailVerified) {
        setStaffRole(nextUser ? 'unauthorized' : 'none');
        return;
      }

      const normalized = normalizeEmail(nextUser.email);
      void (async () => {
        try {
          const idToken = await nextUser.getIdToken();
          const roleRes = await cafeApi.getStaffRole(idToken);
          if (!active) return;

          if (roleRes.role === 'owner') {
            setStaffRole('owner');
            return;
          }

          if (roleRes.role === 'manager') {
            setStaffRole('manager');
          } else {
            setStaffRole('unauthorized');
          }

          // Keep manager access reactive in real time if owner pauses or reactivates them
          const mgrRef = doc(db, 'managers', emailToManagerId(normalized));
          unsubManagerDoc = onSnapshot(
            mgrRef,
            (snap) => {
              if (!active) return;
              if (snap.exists() && snap.data().status === 'active') {
                setStaffRole('manager');
              } else {
                setStaffRole('unauthorized');
              }
            },
            () => {
              if (active) setStaffRole('unauthorized');
            }
          );
        } catch {
          if (active) setStaffRole('unauthorized');
        }
      })();
    });

    return () => {
      active = false;
      unsubAuth();
      if (unsubManagerDoc) unsubManagerDoc();
    };
  }, []);

  const refreshLiveOperations = useCallback(async () => {
    try {
      const res = await cafeApi.getOperations();
      if (res.operations) {
        setOperations(res.operations);
      }
    } catch {
      // Ignore refresh errors silently
    }
  }, []);

  const refreshLiveHours = useCallback(async () => {
    try {
      const res = await cafeApi.getHours();
      setWeeklyHours(res.weeklyHours);
      setOpenStatus(res.openStatus);
    } catch {
      // Ignore refresh errors silently
    }
  }, []);

  const refreshGuestOrders = useCallback(async () => {
    try {
      const ordersRes = await cafeApi.getOrders();
      setOrders(ordersRes.orders);
      setDeletedOrders(ordersRes.deletedOrders || []);
      setGateways(ordersRes.gateways);
    } catch {
      // Ignore refresh errors silently
    }
  }, []);

  useEffect(() => {
    let active = true;
    async function bootstrap() {
      try {
        const [ordersRes, qrRes, opsRes, hoursRes] = await Promise.all([
          cafeApi.getOrders(),
          cafeApi.getQuickUpiQr(),
          cafeApi.getOperations().catch(() => null),
          cafeApi.getHours().catch(() => null),
        ]);
        if (!active) return;
        setOrders(ordersRes.orders);
        setDeletedOrders(ordersRes.deletedOrders || []);
        setGateways(ordersRes.gateways);
        setCounterQrDataUrl(qrRes.qrDataUrl);
        if (opsRes?.operations) {
          setOperations(opsRes.operations);
        }
        if (hoursRes) {
          setWeeklyHours(hoursRes.weeklyHours);
          setOpenStatus(hoursRes.openStatus);
        }
      } catch {
        // Keep storefront immediately interactive
      }
    }
    bootstrap();

    const intervalId = window.setInterval(() => {
      void refreshLiveHours();
    }, 60_000);

    return () => {
      active = false;
      window.clearInterval(intervalId);
    };
  }, [refreshLiveHours]);

  const cartQuantities: Record<string, number> = Object.fromEntries(
    cart.map((entry) => [entry.itemId, entry.quantity])
  );
  const totalBagCount = cart.reduce((sum, entry) => sum + entry.quantity, 0);

  const isOpenNow = openStatus ? openStatus.isOpenNow : true;
  const soldOutItemNames = operations.unavailableItemIds
    .map((id) => MENU_ITEMS_BY_ID[id]?.name)
    .filter((name): name is string => Boolean(name));

  function handleAddItem(itemId: string) {
    if (!isOpenNow) {
      showToast(openStatus?.closedReason || 'Ordering is closed outside opening hours');
      return;
    }
    if (!operations.acceptingOrders) {
      showToast('Cafe is temporarily paused for new orders');
      return;
    }
    if (operations.unavailableItemIds.includes(itemId)) {
      showToast('This item is currently sold out');
      return;
    }
    const item = MENU_ITEMS_BY_ID[itemId];
    if (!item) return;
    setCart((prev) => {
      const existing = prev.find((e) => e.itemId === itemId);
      if (existing) {
        return prev.map((e) =>
          e.itemId === itemId ? { ...e, quantity: Math.min(25, e.quantity + 1) } : e
        );
      }
      return [...prev, { itemId, quantity: 1 }];
    });
    showToast(`Added ${item.name} to your bag`);
  }

  function handleDecrementItem(itemId: string) {
    setCart((prev) =>
      prev
        .map((e) => (e.itemId === itemId ? { ...e, quantity: e.quantity - 1 } : e))
        .filter((e) => e.quantity > 0)
    );
  }

  function handleRemoveItem(itemId: string) {
    setCart((prev) => prev.filter((e) => e.itemId !== itemId));
  }

  function handleRemoveSoldOutItems() {
    setCart((prev) => prev.filter((e) => !operations.unavailableItemIds.includes(e.itemId)));
    showToast('Removed sold-out items from your bag');
  }

  function handleClearCart() {
    setCart([]);
  }

  function handleToggleFavorite(itemId: string) {
    setFavoriteIds((prev) => {
      const exists = prev.includes(itemId);
      const next = exists ? prev.filter((id) => id !== itemId) : [...prev, itemId];
      try {
        window.localStorage.setItem('immy_favorites', JSON.stringify(next));
      } catch {
        // Ignore storage errors
      }
      showToast(exists ? 'Removed from favorites' : 'Saved to favorites');
      return next;
    });
  }

  function handleOrderCreatedOrUpdated(order: CafeOrder) {
    setOrders((prev) => {
      const exists = prev.some((o) => o.id === order.id);
      if (exists) {
        return prev.map((o) => (o.id === order.id ? order : o));
      }
      return [order, ...prev];
    });
  }

  function handleOrderDeleted(deletedOrder: CafeOrder) {
    setOrders((prev) => prev.filter((o) => o.id !== deletedOrder.id));
    setDeletedOrders((prev) => [
      deletedOrder,
      ...prev.filter((o) => o.id !== deletedOrder.id),
    ].slice(0, 15));
    showToast(`Order ${deletedOrder.id} deleted — undo anytime in Order History`);
  }

  function handleOrderRestored(restoredOrder: CafeOrder) {
    setDeletedOrders((prev) => prev.filter((o) => o.id !== restoredOrder.id));
    setOrders((prev) => [
      restoredOrder,
      ...prev.filter((o) => o.id !== restoredOrder.id),
    ]);
    showToast(`Order ${restoredOrder.id} restored`);
  }

  function handleRestoreItemsToBag(items: OrderItem[]) {
    setCart((prev) => {
      const next = new Map(prev.map((e) => [e.itemId, e.quantity]));
      for (const item of items) {
        if (
          MENU_ITEMS_BY_ID[item.itemId] &&
          !operations.unavailableItemIds.includes(item.itemId)
        ) {
          next.set(item.itemId, Math.min(25, (next.get(item.itemId) || 0) + item.quantity));
        }
      }
      return Array.from(next.entries()).map(([itemId, quantity]) => ({ itemId, quantity }));
    });
  }

  function handleReorder(items: OrderItem[]) {
    if (!isOpenNow) {
      showToast(openStatus?.closedReason || 'Ordering is closed outside opening hours');
      return;
    }
    if (!operations.acceptingOrders) {
      showToast('Cafe is temporarily paused for new orders');
      return;
    }
    const available = items.filter(
      (item) =>
        Boolean(MENU_ITEMS_BY_ID[item.itemId]) &&
        !operations.unavailableItemIds.includes(item.itemId)
    );
    const skippedSoldOut = items.filter((item) =>
      operations.unavailableItemIds.includes(item.itemId)
    );

    if (available.length === 0) {
      showToast('All items from this previous order are currently sold out');
      return;
    }

    handleRestoreItemsToBag(available);
    setCheckoutOpen(true);
    if (skippedSoldOut.length > 0) {
      showToast(
        `Added available items — skipped sold-out: ${skippedSoldOut.map((i) => i.name).join(', ')}`
      );
    } else {
      showToast('Previous order items added to your bag');
    }
  }

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#1D1815]">
      {/* Strict 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-40 border-b border-[#1D1815]/10 bg-[#FAF8F5]/95 backdrop-blur-sm">
        <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-8 px-6 lg:px-8">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#top"
            className="font-display text-lg font-semibold tracking-tight text-[#1D1815] whitespace-nowrap shrink-0 sm:text-xl"
          >
            {CAFE_INFO.name}
          </a>

          {/* Zone 2: 4 clean single-line navigation links */}
          <nav
            aria-label="Primary navigation"
            className="hidden items-center gap-7 text-sm font-medium text-[#5A5048] md:flex"
          >
            <a
              href="#menu"
              className="transition-colors hover:text-[#1D1815] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Menu
            </a>
            <a
              href="#book-table"
              className="transition-colors hover:text-[#1D1815] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Book Table
            </a>
            <button
              type="button"
              onClick={() => setOrdersOpen(true)}
              className="transition-colors hover:text-[#1D1815] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Orders{orders.length > 0 ? ` (${orders.length})` : ''}
            </button>
            <a
              href="#contact"
              className="transition-colors hover:text-[#1D1815] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setCheckoutOpen(true)}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-[#2A473A] px-4 py-2 text-sm font-medium text-[#FAF8F5] transition-colors duration-150 hover:bg-[#1F372C] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2A473A] whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="h-4 w-4" />
              <span className="tabular-nums">
                Bag{totalBagCount > 0 ? ` · ${totalBagCount}` : ''}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Active Owner / Manager Banner (Shown ONLY when verified Owner or Appointed Manager is signed in — zero email exposed) */}
      {(staffRole === 'owner' || staffRole === 'manager') && (
        <div className="border-b border-[#2A473A]/20 bg-[#2A473A] text-[#FAF8F5]">
          <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-3 px-6 py-2.5 text-xs lg:px-8">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 shrink-0" />
              <span>
                Signed in as{' '}
                <strong>{staffRole === 'owner' ? 'Cafe Owner' : 'Appointed Manager'}</strong>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setStaffConsoleOpen(true)}
              className="rounded-md bg-[#FAF8F5] px-3 py-1 font-semibold text-[#1F372C] transition-colors hover:bg-[#EFEAE2] whitespace-nowrap shrink-0"
            >
              {staffRole === 'owner' ? 'Open Owner Console' : 'Open Manager Console'}
            </button>
          </div>
        </div>
      )}

      {/* Optional Live Cafe Notice set by Owner / Manager */}
      {operations.dailySpecialNotice && (
        <div className="border-b border-[#1D1815]/10 bg-[#EFEAE2]">
          <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 px-6 py-2 text-xs text-[#3B332E] lg:px-8">
            <span>{operations.dailySpecialNotice}</span>
            <span className="font-mono text-[#6A5E55] whitespace-nowrap shrink-0">
              Prep ~{operations.prepTimeMinutes} min
            </span>
          </div>
        </div>
      )}

      <main id="top">
        {/* Section 1: Editorial Split Hero — 100% Open-Air Garden Cafe */}
        <section className="mx-auto max-w-[1200px] px-6 pt-10 pb-12 lg:px-8 lg:pt-14 lg:pb-16">
          <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-10">
            {/* Hero Editorial Copy */}
            <div className="flex flex-col justify-between rounded-2xl border border-[#1D1815]/10 bg-[#F4F0EA] p-7 sm:p-10 lg:col-span-6">
              <div>
                <p className="text-xs font-medium tracking-wide text-[#5A5048]">
                  Open-Air Garden Cafe · Toran Club, Ahmedabad – Palanpur Highway
                </p>
                <h1 className="mt-4 font-display text-[clamp(2.25rem,4vw,3.5rem)] font-medium leading-[1.08] tracking-tight text-[#1D1815]">
                  Open-air garden coffee and warm plates under the trees.
                </h1>
                <p className="mt-5 max-w-lg text-base leading-relaxed text-[#4E453E]">
                  Unwind across lush open-air lawns, warm lantern-lit garden tables, and evening
                  breezes along the Palanpur highway at IMMY's Coffee Cafe. Reserve or order
                  through Zomato, or pay seamlessly at your garden table via UPI with UTR
                  confirmation.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3.5">
                  <a
                    href="#menu"
                    className="inline-flex min-h-[46px] items-center justify-center rounded-lg bg-[#2A473A] px-6 py-3 text-sm font-medium text-[#FAF8F5] transition-colors duration-150 hover:bg-[#1F372C] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2A473A] whitespace-nowrap shrink-0"
                  >
                    Explore Garden Menu
                  </a>
                  <a
                    href="#book-table"
                    className="inline-flex min-h-[46px] items-center justify-center rounded-lg border border-[#2A473A] bg-[#FAF8F5] px-5 py-3 text-sm font-medium text-[#2A473A] transition-colors hover:bg-[#2A473A]/8 whitespace-nowrap shrink-0"
                  >
                    Book a Table
                  </a>
                  <button
                    type="button"
                    onClick={() => setOrdersOpen(true)}
                    className="inline-flex min-h-[46px] items-center gap-2 rounded-lg border border-[#1D1815]/20 bg-[#FAF8F5] px-5 py-3 text-sm font-medium text-[#1D1815] transition-colors hover:border-[#1D1815]/40 whitespace-nowrap shrink-0"
                  >
                    <Receipt className="h-4 w-4 text-[#2A473A]" />
                    Order History{orders.length > 0 ? ` (${orders.length})` : ''}
                  </button>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-[#1D1815]/10 pt-5 text-sm text-[#5A5048]">
                <span>Official table booking & delivery partner:</span>
                <a
                  href={CAFE_INFO.zomatoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-medium text-[#1D1815] underline decoration-[#1D1815]/30 underline-offset-4 transition-colors hover:text-[#2A473A]"
                >
                  Zomato
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>

            {/* Hero Cozy Animated Open-Air Garden Cafe GIF */}
            <div className="relative overflow-hidden rounded-2xl border border-[#1D1815]/10 bg-[#162821] lg:col-span-6">
              <img
                src={CAFE_INFO.heroGifUrl}
                alt="Cozy animated open-air garden cafe at dusk with glowing fairy lights, swaying leaves, table lantern, and steaming coffee"
                loading="eager"
                className="aspect-[16/10] h-full min-h-[300px] w-full object-cover lg:aspect-auto"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#1D1815]/65 via-transparent to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 p-6 text-[#FAF8F5]">
                <p className="text-xs font-medium text-[#FAF8F5]/85">
                  {CAFE_INFO.days} · {CAFE_INFO.hours} · Prep ~{operations.prepTimeMinutes} min
                </p>
                <p className="mt-1 font-display text-lg font-medium">
                  100% Open-Air Garden Lawn & String-Lit Tree Seating
                </p>
              </div>
            </div>
          </div>

          {/* 4-Column Cafe Essentials Strip */}
          <div className="mt-8 grid grid-cols-1 gap-4 rounded-2xl border border-[#1D1815]/10 bg-[#FAF8F5] p-6 sm:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-[#1D1815]/10">
            <div className="lg:pr-6">
              <p className="text-xs font-medium text-[#6A5E55]">Garden Location</p>
              <p className="mt-1 text-sm font-semibold text-[#1D1815]">
                Toran Club, Shop 11/12
              </p>
              <p className="mt-0.5 text-xs text-[#5A5048]">B/H Shell Pump, Palanpur Hwy, 385001</p>
            </div>
            <div className="lg:px-6">
              <p className="text-xs font-medium text-[#6A5E55]">Today&apos;s Hours (IST)</p>
              <a
                href="#opening-hours"
                className="mt-1 inline-block font-mono text-sm font-semibold text-[#1D1815] hover:text-[#2A473A] hover:underline tabular-nums"
              >
                {openStatus?.todayScheduleLabel || CAFE_INFO.hours}
              </a>
              <p
                className={`mt-0.5 text-xs ${
                  !isOpenNow ? 'font-medium text-[#7A3222]' : 'text-[#5A5048]'
                }`}
              >
                {!isOpenNow
                  ? 'Currently closed · View weekly table'
                  : operations.acceptingOrders
                    ? 'Open now · View weekly schedule'
                    : 'Orders temporarily paused'}
              </p>
            </div>
            <div className="lg:px-6">
              <p className="text-xs font-medium text-[#6A5E55]">Direct Phone</p>
              <a
                href={`tel:+91${CAFE_INFO.phone}`}
                className="mt-1 inline-block font-mono text-sm font-semibold text-[#2A473A] hover:underline tabular-nums"
              >
                {CAFE_INFO.formattedPhone}
              </a>
              <p className="mt-0.5 text-xs text-[#5A5048]">Garden tables & takeaway</p>
            </div>
            <div className="lg:pl-6">
              <p className="text-xs font-medium text-[#6A5E55]">Official Online Payment</p>
              <a
                href="#contact"
                className="mt-1 inline-block text-sm font-semibold text-[#1D1815] hover:text-[#2A473A] hover:underline"
              >
                UPI QR Code Only
              </a>
              <p className="mt-0.5 text-xs text-[#5A5048]">UTR confirmed · Razorpay & Cashfree</p>
            </div>
          </div>
        </section>

        {/* Section 2: Full Garden Cafe Menu by Food & Beverage Category with Animated GIFs */}
        <div className="border-y border-[#1D1815]/10 bg-[#F7F4EE]">
          <MenuShowcase
            activeCategoryId={activeCategoryId}
            onSelectCategory={setActiveCategoryId}
            cartQuantities={cartQuantities}
            favoriteIds={favoriteIds}
            unavailableItemIds={operations.unavailableItemIds}
            soldOutItemNames={soldOutItemNames}
            acceptingOrders={operations.acceptingOrders}
            isOpenNow={isOpenNow}
            closedReason={openStatus?.closedReason}
            onAddItem={handleAddItem}
            onDecrementItem={handleDecrementItem}
            onRemoveItem={handleRemoveItem}
            onToggleFavorite={handleToggleFavorite}
          />
        </div>

        {/* Section 3: Direct Garden Table Booking (Limited Tables, Name + Phone, No OTP, Strictly Within Opening Hours) */}
        <div className="border-b border-[#1D1815]/10 bg-[#FAF8F5]">
          <TableBookingSection
            refreshSignal={bookingsRefreshSignal}
            openStatus={openStatus}
            onBookingMutated={(msg) => showToast(msg)}
          />
        </div>

        {/* Section 3.5: Dedicated Weekly Opening Hours Table (Editable Live by Owner & Managers) */}
        <div className="border-b border-[#1D1815]/10 bg-[#F7F4EE]">
          <WeeklyHoursTable weeklyHours={weeklyHours} openStatus={openStatus} />
        </div>

        {/* Section 4: Dedicated Zomato Partner + Contact & Counter UPI QR */}
        <section
          id="reserve"
          className="mx-auto max-w-[1200px] px-6 py-20 lg:px-8 lg:py-24"
        >
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-[#6A5E55]">
              Exclusive Dining & Delivery Partner
            </p>
            <h2 className="mt-2 font-display text-3xl font-medium tracking-tight text-[#1D1815] sm:text-4xl">
              Book Your Garden Table & Order on Zomato
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-[#5A5048]">
              We partner exclusively with Zomato for online table reservations, garden dining
              offers, and fresh food delivery from IMMY's Coffee Cafe at Toran Club.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2">
            {/* Zomato Food Delivery & Menu Card */}
            <a
              href={CAFE_INFO.zomatoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex flex-col justify-between rounded-2xl border border-[#1D1815]/12 bg-[#FAF8F5] p-7 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#2A473A] hover:shadow-md focus-visible:outline-2 focus-visible:outline-[#2A473A]"
            >
              <div>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-xs font-medium text-[#6A5E55]">
                    Online Food Ordering · Live Tracking · Guest Reviews
                  </span>
                  <ArrowUpRight className="h-5 w-5 text-[#2A473A] transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <h3 className="mt-3 font-display text-2xl font-medium text-[#1D1815]">
                  Order Food on Zomato
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[#5A5048]">
                  Have freshly brewed coffees, chilled coolers, and warm cafe plates from IMMY's
                  Coffee Cafe delivered right to your door via Zomato.
                </p>
              </div>
              <div className="mt-6 border-t border-[#1D1815]/10 pt-4 text-sm font-medium text-[#2A473A]">
                Order from IMMY's Coffee Cafe on Zomato
              </div>
            </a>

            {/* Zomato Garden Table Reservations Card */}
            <a
              href={CAFE_INFO.zomatoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex flex-col justify-between rounded-2xl border border-[#1D1815]/12 bg-[#FAF8F5] p-7 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#2A473A] hover:shadow-md focus-visible:outline-2 focus-visible:outline-[#2A473A]"
            >
              <div>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-xs font-medium text-[#6A5E55]">
                    Open-Air Lawn Tables · Evening Bookings · Zomato Gold
                  </span>
                  <ArrowUpRight className="h-5 w-5 text-[#2A473A] transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <h3 className="mt-3 font-display text-2xl font-medium text-[#1D1815]">
                  Reserve a Garden Table on Zomato
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[#5A5048]">
                  Book open-sky evening tables under the fairy lights for friends, families, and
                  highway stopovers directly through Zomato.
                </p>
              </div>
              <div className="mt-6 border-t border-[#1D1815]/10 pt-4 text-sm font-medium text-[#2A473A]">
                Book Garden Table on Zomato
              </div>
            </a>
          </div>

          {/* Contact Information & Direct Counter UPI QR Card */}
          <div
            id="contact"
            className="mt-10 grid grid-cols-1 items-stretch gap-8 rounded-2xl border border-[#1D1815]/12 bg-[#F4F0EA] p-7 sm:p-10 lg:grid-cols-12"
          >
            {/* Visit & Contact Details */}
            <div className="flex flex-col justify-between lg:col-span-7">
              <div>
                <p className="text-xs font-medium tracking-wide text-[#6A5E55]">
                  Visit Our Open-Air Garden Cafe
                </p>
                <h3 className="mt-2 font-display text-3xl font-medium text-[#1D1815]">
                  Find Us at Toran Club
                </h3>
                <p className="mt-3 max-w-lg text-sm leading-relaxed text-[#5A5048]">
                  Set completely outdoors along the Ahmedabad – Palanpur Highway with spacious
                  parking, shaded daytime garden tables, and warm string-lit lawn seating at dusk.
                </p>

                <dl className="mt-7 space-y-5 text-sm">
                  <div className="flex items-start gap-3.5">
                    <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-[#2A473A]" />
                    <div>
                      <dt className="font-semibold text-[#1D1815]">Garden Address</dt>
                      <dd className="mt-0.5 text-[#5A5048]">{CAFE_INFO.address}</dd>
                    </div>
                  </div>
                  <div className="flex items-start gap-3.5">
                    <Phone className="mt-0.5 h-5 w-5 shrink-0 text-[#2A473A]" />
                    <div>
                      <dt className="font-semibold text-[#1D1815]">Phone & Garden Bookings</dt>
                      <dd className="mt-0.5">
                        <a
                          href={`tel:+91${CAFE_INFO.phone}`}
                          className="font-mono font-semibold text-[#2A473A] hover:underline tabular-nums"
                        >
                          {CAFE_INFO.formattedPhone}
                        </a>
                        <span className="ml-2 text-xs text-[#6A5E55]">({CAFE_INFO.phone})</span>
                      </dd>
                    </div>
                  </div>
                  <div className="flex items-start gap-3.5">
                    <Clock className="mt-0.5 h-5 w-5 shrink-0 text-[#2A473A]" />
                    <div>
                      <dt className="font-semibold text-[#1D1815]">Garden Cafe Hours</dt>
                      <dd className="mt-0.5 text-[#5A5048]">
                        {CAFE_INFO.days} · {CAFE_INFO.hours}
                      </dd>
                    </div>
                  </div>
                </dl>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={`tel:+91${CAFE_INFO.phone}`}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#2A473A] px-5 py-2.5 text-sm font-medium text-[#FAF8F5] transition-colors hover:bg-[#1F372C]"
                >
                  <Phone className="h-4 w-4" />
                  Call {CAFE_INFO.phone}
                </a>
                <a
                  href={CAFE_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-[#1D1815]/20 bg-[#FAF8F5] px-5 py-2.5 text-sm font-medium text-[#1D1815] transition-colors hover:border-[#1D1815]/40"
                >
                  Get Highway Directions
                  <ArrowUpRight className="h-4 w-4" />
                </a>
              </div>
            </div>

            {/* Direct Scan-to-Pay UPI QR Box (Strictly QR-Only — UPI ID hidden for security) */}
            <div className="flex flex-col items-center justify-center rounded-2xl border border-[#1D1815]/10 bg-[#FAF8F5] p-6 text-center lg:col-span-5">
              <div className="flex items-center gap-2 text-xs font-medium text-[#2A473A]">
                <QrCode className="h-4 w-4" />
                <span>Official QR-Only UPI Payment</span>
              </div>
              <p className="mt-1 font-display text-lg font-medium text-[#1D1815]">
                Scan to Pay {CAFE_INFO.name}
              </p>

              {counterQrDataUrl ? (
                <div className="mt-4 rounded-xl border border-[#1D1815]/10 bg-white p-3">
                  <img
                    src={counterQrDataUrl}
                    alt={`Official UPI QR code for ${CAFE_INFO.name}`}
                    className="h-44 w-44"
                  />
                </div>
              ) : (
                <div className="mt-4 flex h-44 w-44 items-center justify-center rounded-xl border border-[#1D1815]/10 bg-white text-xs text-[#6A5E55]">
                  Loading UPI QR...
                </div>
              )}

              <p className="mt-4 text-xs font-medium text-[#1D1815]">
                Scan with GPay, PhonePe, Paytm, or FamPay
              </p>

              <div className="mt-2 flex items-center gap-1.5 text-xs text-[#5A5048]">
                <ShieldCheck className="h-4 w-4 text-[#2A473A]" />
                <span>Orders confirm via 12-digit UPI UTR with Razorpay or Cashfree</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Editorial Footer with Owner & Manager Portal Access */}
      <footer className="border-t border-[#1D1815]/10 bg-[#F4F0EA]">
        <div className="mx-auto flex max-w-[1200px] flex-col justify-between gap-6 px-6 py-10 text-sm text-[#5A5048] sm:flex-row sm:items-center lg:px-8">
          <div>
            <p className="font-display text-base font-semibold text-[#1D1815]">
              {CAFE_INFO.name}
            </p>
            <p className="mt-1 text-xs">
              Open-Air Garden Cafe · {CAFE_INFO.address} · Phone:{' '}
              <a href={`tel:+91${CAFE_INFO.phone}`} className="font-mono hover:underline">
                {CAFE_INFO.phone}
              </a>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-xs font-medium">
            <a href="#menu" className="hover:text-[#1D1815]">
              Menu
            </a>
            <a
              href={CAFE_INFO.zomatoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#1D1815]"
            >
              Zomato
            </a>
            <button
              type="button"
              onClick={() => setOrdersOpen(true)}
              className="hover:text-[#1D1815]"
            >
              Order History
            </button>
            <button
              type="button"
              onClick={() => setStaffConsoleOpen(true)}
              className="text-[#2A473A] underline underline-offset-4 hover:text-[#1F372C]"
            >
              {staffRole === 'owner'
                ? 'Owner Console'
                : staffRole === 'manager'
                  ? 'Manager Console'
                  : 'Owner / Manager Access'}
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Compact Bottom Quick Action when bag has items */}
      {totalBagCount > 0 && (
        <div className="fixed inset-x-4 bottom-4 z-30 md:hidden">
          <button
            type="button"
            onClick={() => setCheckoutOpen(true)}
            className="flex w-full min-h-[48px] items-center justify-between rounded-xl bg-[#2A473A] px-5 py-3 text-sm font-medium text-[#FAF8F5] shadow-lg"
          >
            <span className="tabular-nums">
              {totalBagCount} {totalBagCount === 1 ? 'item' : 'items'} in bag
            </span>
            <span>Pay UPI QR & Confirm UTR</span>
          </button>
        </div>
      )}

      {/* Subtle Non-Intrusive Feedback Toast */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-lg bg-[#1D1815] px-4 py-2.5 text-xs font-medium text-[#FAF8F5] shadow-lg"
        >
          {toast}
        </div>
      )}

      {/* Drawers */}
      <CheckoutDrawer
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cart={cart}
        gateways={gateways}
        unavailableItemIds={operations.unavailableItemIds}
        acceptingOrders={operations.acceptingOrders}
        isOpenNow={isOpenNow}
        closedReason={openStatus?.closedReason}
        onAddItem={handleAddItem}
        onDecrementItem={handleDecrementItem}
        onRemoveItem={handleRemoveItem}
        onRemoveSoldOutItems={handleRemoveSoldOutItems}
        onClearCart={handleClearCart}
        onRefreshOperations={refreshLiveOperations}
        onOrderCreatedOrUpdated={handleOrderCreatedOrUpdated}
        onOrderDeleted={handleOrderDeleted}
        onRestoreItemsToBag={handleRestoreItemsToBag}
        onOpenOrderHistory={() => setOrdersOpen(true)}
      />

      <OrdersPanel
        open={ordersOpen}
        onClose={() => setOrdersOpen(false)}
        orders={orders}
        deletedOrders={deletedOrders}
        onOrderUpdated={handleOrderCreatedOrUpdated}
        onOrderDeleted={handleOrderDeleted}
        onOrderRestored={handleOrderRestored}
        onReorder={handleReorder}
      />

      <StaffConsoleDrawer
        open={staffConsoleOpen}
        onClose={() => setStaffConsoleOpen(false)}
        firebaseUser={firebaseUser}
        authReady={authReady}
        staffRole={staffRole}
        operations={operations}
        weeklyHours={weeklyHours}
        openStatus={openStatus}
        onOperationsSaved={(next) => {
          setOperations(next);
        }}
        onHoursSaved={(nextHours, nextStatus) => {
          setWeeklyHours(nextHours);
          setOpenStatus(nextStatus);
        }}
        onStaffOrdersMutated={() => {
          void refreshGuestOrders();
        }}
        onStaffBookingsMutated={() => {
          setBookingsRefreshSignal((n) => n + 1);
        }}
      />
    </div>
  );
}
