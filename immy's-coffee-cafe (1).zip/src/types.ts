export type PaymentGateway = 'razorpay' | 'cashfree';

export type PaymentStatus = 'PENDING' | 'PAID_VERIFIED' | 'FAILED';

export type KitchenStatus = 'received' | 'preparing' | 'ready' | 'completed';

export type DiningMode = 'dine-in' | 'takeaway';

export type StaffRole = 'owner' | 'manager' | 'unauthorized' | 'none';

export interface OrderItem {
  itemId: string;
  name: string;
  price: number;
  quantity: number;
  lineTotal: number;
}

export interface CafeOrder {
  id: string;
  guestId: string;
  customerName: string;
  customerPhone: string;
  diningMode: DiningMode;
  tableOrNotes: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  gateway: PaymentGateway;
  gatewayOrderId: string;
  gatewayPaymentId?: string;
  upiRefUtr?: string;
  paymentStatus: PaymentStatus;
  kitchenStatus: KitchenStatus;
  verificationMode: 'live-razorpay' | 'live-cashfree' | 'upi-utr-confirmed' | 'pending';
  verificationMessage: string;
  createdAt: string;
  verifiedAt?: string;
  updatedByStaffRole?: 'owner' | 'manager';
  deletedAt?: string;
  deletedBy?: string;
}

export interface GatewayCapabilities {
  razorpayLive: boolean;
  cashfreeLive: boolean;
  razorpayKeyId?: string;
  cashfreeEnv: 'sandbox' | 'production';
}

export interface CartEntry {
  itemId: string;
  quantity: number;
}

export interface ManagerRecord {
  id: string;
  email: string;
  name: string;
  role: 'manager';
  status: 'active' | 'revoked';
  shiftNote: string;
  appointedByEmail: string;
  appointedByUid: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface CafeOperationsSettings {
  acceptingOrders: boolean;
  prepTimeMinutes: number;
  dailySpecialNotice: string;
  unavailableItemIds: string[];
  updatedByUid?: string;
  updatedByRole: 'owner' | 'manager';
}

export type StaffNoteCategory = 'reservation' | 'inventory' | 'shift' | 'utr';

export interface StaffShiftNote {
  id: string;
  title: string;
  body: string;
  category: StaffNoteCategory;
  status: 'open' | 'resolved';
  authorUid: string;
  authorEmail: string;
  authorRole: 'owner' | 'manager';
  createdAt?: string;
  updatedAt?: string;
}

export interface StaffOrdersSummary {
  totalOrders: number;
  confirmedCount: number;
  pendingCount: number;
  verifiedRevenue: number;
}

export type TableBookingStatus = 'confirmed' | 'seated' | 'completed' | 'cancelled' | 'no-show';

export interface TableBooking {
  id: string;
  guestId: string;
  guestName: string;
  guestPhone: string;
  bookingDate: string; // YYYY-MM-DD
  timeSlot: string; // e.g. '06:30 PM'
  partySize: number;
  tablesAllocated: number;
  tableNumbers: number[];
  notes: string;
  status: TableBookingStatus;
  createdAt: string;
  updatedByStaffRole?: 'owner' | 'manager';
}

export interface TableSlotAvailability {
  timeSlot: string;
  bookedTables: number;
  remainingTables: number;
  totalTables: number;
  isFull: boolean;
  isPast?: boolean;
}

export interface StaffBookingsSummary {
  totalTables: number;
  totalBookings: number;
  todayCount: number;
  confirmedCount: number;
  seatedCount: number;
  totalUpcomingGuests: number;
}

export type DayOfWeekKey =
  | 'monday'
  | 'tuesday'
  | 'wednesday'
  | 'thursday'
  | 'friday'
  | 'saturday'
  | 'sunday';

export interface DayOpeningHours {
  isOpen: boolean;
  openTime: string; // "HH:MM" 24-hour IST
  closeTime: string; // "HH:MM" 24-hour IST
}

export type WeeklyOpeningHours = Record<DayOfWeekKey, DayOpeningHours>;

export interface CafeOpenStatus {
  isOpenNow: boolean;
  currentDayKey: DayOfWeekKey;
  currentDayLabel: string;
  currentTimeIst: string;
  todayIsoDate: string;
  todayScheduleLabel: string;
  closedReason: string | null;
}


