import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Phone,
  RefreshCw,
  Trash2,
  Users,
} from 'lucide-react';
import { CAFE_INFO } from '../data/menu';
import { cafeApi } from '../lib/api';
import type { CafeOpenStatus, TableBooking, TableSlotAvailability } from '../types';

interface TableBookingSectionProps {
  refreshSignal: number;
  openStatus: CafeOpenStatus | null;
  onBookingMutated?: (message: string) => void;
}

function addDaysToIso(isoDate: string, days: number): string {
  const base = new Date(`${isoDate}T00:00:00Z`);
  if (Number.isNaN(base.getTime())) return isoDate;
  base.setUTCDate(base.getUTCDate() + days);
  return base.toISOString().slice(0, 10);
}

function formatReadableDate(isoDate: string): string {
  const parsed = new Date(`${isoDate}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return isoDate;
  return parsed.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    timeZone: 'UTC',
  });
}

function formatTableNumbers(nums: number[]): string {
  if (!nums || nums.length === 0) return 'Garden Table';
  if (nums.length === 1) return `Garden Table #${nums[0]}`;
  return `Garden Tables #${nums.join(' & #')}`;
}

export function TableBookingSection({
  refreshSignal,
  openStatus,
  onBookingMutated,
}: TableBookingSectionProps) {
  const [todayIso, setTodayIso] = useState<string>(() =>
    new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date())
  );
  const [selectedDate, setSelectedDate] = useState<string>(todayIso);
  const [totalTables, setTotalTables] = useState<number>(8);
  const [slots, setSlots] = useState<TableSlotAvailability[]>([]);
  const [dayLabel, setDayLabel] = useState<string>('');
  const [isDayClosed, setIsDayClosed] = useState<boolean>(false);
  const [scheduleLabel, setScheduleLabel] = useState<string>('');
  const [selectedSlot, setSelectedSlot] = useState<string>('');
  const [partySize, setPartySize] = useState<number>(2);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [notes, setNotes] = useState('');

  const [myBookings, setMyBookings] = useState<TableBooking[]>([]);
  const [loadingAvailability, setLoadingAvailability] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [confirmCancelId, setConfirmCancelId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<TableBooking | null>(null);

  const tablesNeeded = Math.ceil(partySize / 4);
  const maxDateIso = addDaysToIso(todayIso, 14);
  const tomorrowIso = addDaysToIso(todayIso, 1);

  const isOpenNow = openStatus ? openStatus.isOpenNow : true;

  const loadAvailability = useCallback(async (dateToLoad: string) => {
    setLoadingAvailability(true);
    try {
      const res = await cafeApi.getTableAvailability(dateToLoad);
      setTodayIso(res.today);
      setTotalTables(res.totalTables);
      setDayLabel(res.dayLabel);
      setIsDayClosed(res.isDayClosed);
      setScheduleLabel(res.scheduleLabel);
      setSlots(res.slots);
      setSelectedSlot((prev) => {
        const prevSlot = res.slots.find((s) => s.timeSlot === prev);
        if (prevSlot && !prevSlot.isFull && !prevSlot.isPast) return prev;
        const firstOpen = res.slots.find((s) => !s.isFull && !s.isPast);
        return firstOpen ? firstOpen.timeSlot : '';
      });
    } catch {
      // Keep UI interactive even on transient fetch error
    } finally {
      setLoadingAvailability(false);
    }
  }, []);

  const loadMyBookings = useCallback(async () => {
    try {
      const res = await cafeApi.getMyBookings();
      setMyBookings(res.bookings);
      setTotalTables(res.totalTables);
    } catch {
      // Ignore silently on initial load
    }
  }, []);

  useEffect(() => {
    void loadAvailability(selectedDate);
  }, [selectedDate, refreshSignal, loadAvailability]);

  useEffect(() => {
    void loadMyBookings();
  }, [refreshSignal, loadMyBookings]);

  const activeSlotInfo = slots.find((s) => s.timeSlot === selectedSlot) || null;
  const cleanedPhone = guestPhone.replace(/\D/g, '').slice(0, 10);

  async function handleSubmitBooking(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setConfirmedBooking(null);

    if (!isOpenNow) {
      setError(
        openStatus?.closedReason ||
          "Table booking is disabled outside IMMY's Coffee Cafe opening hours."
      );
      return;
    }
    if (isDayClosed) {
      setError(`IMMY's Coffee Cafe is closed on ${dayLabel}s. Please select another date.`);
      return;
    }

    const cleanName = guestName.trim();
    if (cleanName.length < 2) {
      setError('Please enter your full name.');
      return;
    }
    if (cleanedPhone.length !== 10) {
      setError('Enter a valid 10-digit mobile number (no OTP verification required).');
      return;
    }
    if (!selectedSlot) {
      setError('Please select an available time slot within opening hours.');
      return;
    }
    if (activeSlotInfo?.isPast) {
      setError('This time slot has already passed today. Please pick an upcoming slot.');
      return;
    }
    if (activeSlotInfo && activeSlotInfo.remainingTables < tablesNeeded) {
      setError(
        `Only ${activeSlotInfo.remainingTables} table(s) available at ${selectedSlot}. Choose another time slot or smaller party size.`
      );
      return;
    }

    setSubmitting(true);
    try {
      const res = await cafeApi.createTableBooking({
        guestName: cleanName,
        guestPhone: cleanedPhone,
        bookingDate: selectedDate,
        timeSlot: selectedSlot,
        partySize,
        notes: notes.trim(),
      });
      setConfirmedBooking(res.booking);
      setMyBookings((prev) => [res.booking, ...prev.filter((b) => b.id !== res.booking.id)]);
      setSlots(res.availability.slots);
      setTotalTables(res.availability.totalTables);
      setNotes('');
      onBookingMutated?.(
        `Garden table booked (${res.booking.id}) for ${res.booking.timeSlot}`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to book table right now.');
      void loadAvailability(selectedDate);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleCancelBooking(bookingId: string) {
    setCancellingId(bookingId);
    setError(null);
    try {
      const res = await cafeApi.cancelMyBooking(bookingId);
      setMyBookings((prev) => prev.map((b) => (b.id === bookingId ? res.booking : b)));
      if (res.availability.date === selectedDate) {
        setSlots(res.availability.slots);
        setTotalTables(res.availability.totalTables);
      } else {
        void loadAvailability(selectedDate);
      }
      if (confirmedBooking?.id === bookingId) {
        setConfirmedBooking(null);
      }
      setConfirmCancelId(null);
      onBookingMutated?.(`Table booking ${bookingId} cancelled and table released`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not cancel booking.');
    } finally {
      setCancellingId(null);
    }
  }

  return (
    <section
      id="book-table"
      className="mx-auto max-w-[1200px] px-6 py-20 lg:px-8 lg:py-24"
    >
      {/* Editorial Section Header */}
      <div className="flex flex-col gap-4 border-b border-[#1D1815]/10 pb-8 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <p className="text-xs font-medium tracking-wide text-[#6A5E55]">
            Limited Open-Air Seating · {totalTables} Garden Tables per Slot · No OTP Required
          </p>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight text-[#1D1815] sm:text-4xl">
            Reserve Your Garden Table
          </h2>
        </div>
        <p className="max-w-md text-sm leading-relaxed text-[#5A5048]">
          Our open-air Toran Club lawn has limited tables. Pick your date and time slot below and
          confirm instantly with just your name and phone number.
        </p>
      </div>

      <div className="mt-10 grid grid-cols-1 items-start gap-8 lg:grid-cols-12">
        {/* Left Column: Direct Table Reservation Form */}
        <form
          onSubmit={handleSubmitBooking}
          className="space-y-6 rounded-2xl border border-[#1D1815]/12 bg-[#FAF8F5] p-6 sm:p-8 lg:col-span-7"
        >
          {!isOpenNow && (
            <div
              role="alert"
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#9A4B38]/35 bg-[#9A4B38]/10 px-4 py-3.5 text-sm text-[#7A3222]"
            >
              <span>
                {openStatus?.closedReason ||
                  "Table booking is disabled outside IMMY's Coffee Cafe opening hours."}
              </span>
              <a
                href="#opening-hours"
                className="text-xs font-semibold underline underline-offset-4 whitespace-nowrap shrink-0"
              >
                Check Weekly Hours
              </a>
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
            >
              {error}
            </div>
          )}

          {confirmedBooking && (
            <div className="rounded-xl border border-[#2A473A]/25 bg-[#2A473A]/8 p-5">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#2A473A]" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-[#1D1815]">
                    Garden Table Reserved · {confirmedBooking.id}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-[#4A413B]">
                    {formatTableNumbers(confirmedBooking.tableNumbers)} held for{' '}
                    <strong>{confirmedBooking.guestName}</strong> ({confirmedBooking.partySize}{' '}
                    {confirmedBooking.partySize === 1 ? 'guest' : 'guests'}) on{' '}
                    <span className="font-mono">
                      {formatReadableDate(confirmedBooking.bookingDate)}
                    </span>{' '}
                    at <span className="font-mono font-semibold">{confirmedBooking.timeSlot}</span>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Step 1: Date & Guests */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <span className="flex items-center gap-1.5 text-xs font-medium text-[#5A5048]">
                <Calendar className="h-3.5 w-3.5 text-[#2A473A]" />
                1. Choose Date
              </span>
              <div className="mt-2 flex items-center gap-1.5 rounded-lg bg-[#EFEAE2] p-1">
                <button
                  type="button"
                  onClick={() => setSelectedDate(todayIso)}
                  className={`min-h-[36px] flex-1 rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedDate === todayIso
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  Today
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedDate(tomorrowIso)}
                  className={`min-h-[36px] flex-1 rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedDate === tomorrowIso
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  Tomorrow
                </button>
              </div>
              <input
                type="date"
                aria-label="Select booking date"
                min={todayIso}
                max={maxDateIso}
                value={selectedDate}
                onChange={(e) => {
                  if (e.target.value) setSelectedDate(e.target.value);
                }}
                className="mt-2 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3 py-2 font-mono text-xs text-[#1D1815] outline-none focus:border-[#2A473A]"
              />
            </div>

            <div>
              <span className="flex items-center gap-1.5 text-xs font-medium text-[#5A5048]">
                <Users className="h-3.5 w-3.5 text-[#2A473A]" />
                2. Number of Guests
              </span>
              <div className="mt-2 grid grid-cols-4 gap-1.5">
                {[1, 2, 3, 4, 5, 6, 8, 10].map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setPartySize(size)}
                    className={`min-h-[38px] rounded-lg border font-mono text-xs font-medium tabular-nums transition-colors ${
                      partySize === size
                        ? 'border-[#2A473A] bg-[#2A473A] text-[#FAF8F5]'
                        : 'border-[#1D1815]/15 bg-white text-[#1D1815] hover:border-[#1D1815]/35'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-[#6A5E55]">
                Reserves{' '}
                <span className="font-mono font-semibold text-[#1D1815] tabular-nums">
                  {tablesNeeded}
                </span>{' '}
                garden {tablesNeeded === 1 ? 'table' : 'tables'} (4 guests per table)
              </p>
            </div>
          </div>

          {/* Step 2: Live Time Slot Availability (Strictly inside selected day's opening hours) */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-xs font-medium text-[#5A5048]">
                <Clock className="h-3.5 w-3.5 text-[#2A473A]" />
                3. Select Time Slot ({formatReadableDate(selectedDate)}
                {scheduleLabel ? ` · ${scheduleLabel} IST` : ''})
              </span>
              <button
                type="button"
                onClick={() => void loadAvailability(selectedDate)}
                disabled={loadingAvailability}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#2A473A] hover:underline disabled:opacity-50"
              >
                <RefreshCw
                  className={`h-3 w-3 ${loadingAvailability ? 'animate-spin' : ''}`}
                />
                Refresh Slots
              </button>
            </div>

            {isDayClosed ? (
              <div className="mt-2.5 rounded-xl border border-[#9A4B38]/30 bg-[#9A4B38]/8 px-4 py-3.5 text-xs text-[#7A3222]">
                IMMY's Coffee Cafe is closed on {dayLabel || 'this day'}s. No table booking slots
                are available — please choose an open day.
              </div>
            ) : slots.length === 0 ? (
              <div className="mt-2.5 rounded-xl border border-[#1D1815]/12 bg-[#EFEAE2]/60 px-4 py-3.5 text-xs text-[#5A5048]">
                No booking slots available within opening hours for this date.
              </div>
            ) : (
              <div className="mt-2.5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {slots.map((slot) => {
                  const isPast = Boolean(slot.isPast);
                  const cannotFit = !isOpenNow || isPast || slot.remainingTables < tablesNeeded;
                  const isSelected = selectedSlot === slot.timeSlot && !cannotFit;
                  const isLow = !cannotFit && slot.remainingTables <= 2;
                  return (
                    <button
                      key={slot.timeSlot}
                      type="button"
                      disabled={cannotFit}
                      onClick={() => setSelectedSlot(slot.timeSlot)}
                      className={`flex flex-col items-start rounded-xl border px-3.5 py-2.5 text-left transition-colors ${
                        cannotFit
                          ? 'cursor-not-allowed border-[#1D1815]/10 bg-[#EFEAE2]/70 text-[#8A7E75]'
                          : isSelected
                            ? 'border-[#2A473A] bg-[#2A473A] text-[#FAF8F5]'
                            : 'border-[#1D1815]/15 bg-white text-[#1D1815] hover:border-[#2A473A]'
                      }`}
                    >
                      <span className="font-mono text-sm font-semibold tabular-nums whitespace-nowrap">
                        {slot.timeSlot}
                      </span>
                      <span
                        className={`mt-0.5 text-xs tabular-nums ${
                          cannotFit
                            ? 'text-[#7A3222]'
                            : isSelected
                              ? 'text-[#FAF8F5]/85'
                              : isLow
                                ? 'font-medium text-[#9A5B25]'
                                : 'text-[#6A5E55]'
                        }`}
                      >
                        {!isOpenNow
                          ? 'Cafe Closed'
                          : isPast
                            ? 'Past'
                            : slot.isFull
                              ? 'Full'
                              : slot.remainingTables < tablesNeeded
                                ? `Only ${slot.remainingTables} left`
                                : `${slot.remainingTables} of ${slot.totalTables} left`}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Step 3: Name + Phone Number (Strictly No OTP) */}
          <div className="grid grid-cols-1 gap-4 border-t border-[#1D1815]/10 pt-5 sm:grid-cols-2">
            <div>
              <label
                htmlFor="booking-guest-name"
                className="block text-xs font-medium text-[#1D1815]"
              >
                Your Name
              </label>
              <input
                id="booking-guest-name"
                type="text"
                required
                minLength={2}
                maxLength={60}
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="e.g. Aarav Patel"
                className="mt-1.5 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3.5 py-2.5 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="booking-guest-phone"
                  className="block text-xs font-medium text-[#1D1815]"
                >
                  Mobile Number (No OTP)
                </label>
                <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                  {cleanedPhone.length}/10
                </span>
              </div>
              <input
                id="booking-guest-phone"
                type="tel"
                inputMode="numeric"
                required
                maxLength={10}
                value={cleanedPhone}
                onChange={(e) => setGuestPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="10-digit mobile number"
                className="mt-1.5 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3.5 py-2.5 font-mono text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
              />
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="booking-notes"
                className="block text-xs font-medium text-[#5A5048]"
              >
                Garden Seating Request (Optional)
              </label>
              <input
                id="booking-notes"
                type="text"
                maxLength={160}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Corner lawn table under fairy lights, birthday gathering"
                className="mt-1.5 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3.5 py-2.5 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={
              !isOpenNow ||
              isDayClosed ||
              submitting ||
              !selectedSlot ||
              Boolean(activeSlotInfo?.isPast) ||
              (activeSlotInfo ? activeSlotInfo.remainingTables < tablesNeeded : false)
            }
            className="w-full min-h-[46px] rounded-lg bg-[#2A473A] px-6 py-3 text-sm font-medium text-[#FAF8F5] transition-colors duration-150 hover:bg-[#1F372C] disabled:cursor-not-allowed disabled:opacity-55 whitespace-nowrap"
          >
            {!isOpenNow
              ? 'Table Booking Closed · Outside Opening Hours'
              : isDayClosed
                ? `Closed on ${dayLabel || 'Selected Day'}s`
                : submitting
                  ? 'Reserving Your Garden Table...'
                  : selectedSlot
                    ? `Confirm Garden Table · ${selectedSlot}`
                    : 'Select an Available Time Slot'}
          </button>
        </form>

        {/* Right Column: Guest's Own Table Reservations & Cafe Seating Info */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-2xl border border-[#1D1815]/12 bg-[#F4F0EA] p-6 sm:p-7">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-display text-xl font-medium text-[#1D1815]">
                Your Table Bookings
              </h3>
              <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                {myBookings.filter((b) => b.status === 'confirmed' || b.status === 'seated').length}{' '}
                active
              </span>
            </div>
            <p className="mt-1 text-xs leading-relaxed text-[#5A5048]">
              Confirmed instantly without login or OTP. Cancel anytime if your plans change so
              another guest can enjoy the garden table.
            </p>

            {myBookings.length === 0 ? (
              <div className="mt-5 rounded-xl border border-[#1D1815]/10 bg-[#FAF8F5] p-5 text-sm text-[#5A5048]">
                <p className="font-medium text-[#1D1815]">No tables booked yet</p>
                <p className="mt-1 text-xs leading-relaxed text-[#6A5E55]">
                  Choose a time slot on the left to lock in your open-air table under the trees at
                  Toran Club.
                </p>
              </div>
            ) : (
              <div className="mt-5 space-y-3">
                {myBookings.slice(0, 6).map((booking) => {
                  const isActive =
                    booking.status === 'confirmed' || booking.status === 'seated';
                  return (
                    <div
                      key={booking.id}
                      className={`rounded-xl border p-4 ${
                        isActive
                          ? 'border-[#1D1815]/12 bg-[#FAF8F5]'
                          : 'border-dashed border-[#1D1815]/15 bg-[#FAF8F5]/60 opacity-75'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#6A5E55]">
                        <span className="font-mono font-semibold text-[#1D1815]">
                          {booking.id}
                        </span>
                        <span
                          className={`font-medium capitalize ${
                            booking.status === 'confirmed' || booking.status === 'seated'
                              ? 'text-[#2A473A]'
                              : booking.status === 'cancelled' || booking.status === 'no-show'
                                ? 'text-[#7A3222]'
                                : 'text-[#5A5048]'
                          }`}
                        >
                          {booking.status}
                        </span>
                      </div>

                      <p className="mt-1.5 text-sm font-semibold text-[#1D1815]">
                        {formatReadableDate(booking.bookingDate)} · {booking.timeSlot}
                      </p>
                      <p className="mt-0.5 text-xs text-[#5A5048]">
                        {booking.guestName} · <span className="font-mono">{booking.guestPhone}</span>{' '}
                        · {booking.partySize} {booking.partySize === 1 ? 'guest' : 'guests'} ·{' '}
                        {formatTableNumbers(booking.tableNumbers)}
                      </p>

                      {booking.notes && (
                        <p className="mt-1 text-xs text-[#6A5E55]">Note: {booking.notes}</p>
                      )}

                      {booking.status === 'confirmed' && (
                        <div className="mt-3 border-t border-[#1D1815]/8 pt-2.5">
                          {confirmCancelId === booking.id ? (
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-medium text-[#7A3222]">
                                Release this table?
                              </span>
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  disabled={cancellingId === booking.id}
                                  onClick={() => handleCancelBooking(booking.id)}
                                  className="rounded-md bg-[#7A3222] px-2.5 py-1 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] disabled:opacity-50"
                                >
                                  {cancellingId === booking.id ? 'Cancelling...' : 'Yes, Cancel'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmCancelId(null)}
                                  className="rounded-md border border-[#1D1815]/15 px-2.5 py-1 text-xs font-medium text-[#5A5048]"
                                >
                                  Keep
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmCancelId(booking.id)}
                              className="inline-flex items-center gap-1 text-xs font-medium text-[#7A3222] hover:underline"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              Cancel Table Booking
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-6 border-t border-[#1D1815]/10 pt-5 text-xs text-[#5A5048]">
              <p className="font-semibold text-[#1D1815]">Large Group or Same-Hour Table?</p>
              <p className="mt-1 leading-relaxed">
                For groups of 12+ guests or immediate highway stopovers, call the garden counter
                directly:
              </p>
              <a
                href={`tel:+91${CAFE_INFO.phone}`}
                className="mt-2 inline-flex items-center gap-1.5 font-mono text-sm font-semibold text-[#2A473A] hover:underline tabular-nums"
              >
                <Phone className="h-3.5 w-3.5" />
                {CAFE_INFO.formattedPhone}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
