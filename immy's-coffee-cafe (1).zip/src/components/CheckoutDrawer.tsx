import { useState, type FormEvent } from 'react';
import {
  CheckCircle2,
  Minus,
  Plus,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Trash2,
  X,
} from 'lucide-react';
import { MENU_ITEMS_BY_ID } from '../data/menu';
import { cafeApi } from '../lib/api';
import type {
  CafeOrder,
  CartEntry,
  DiningMode,
  GatewayCapabilities,
  OrderItem,
  PaymentGateway,
} from '../types';

interface CheckoutDrawerProps {
  open: boolean;
  onClose: () => void;
  cart: CartEntry[];
  gateways: GatewayCapabilities;
  unavailableItemIds: string[];
  acceptingOrders: boolean;
  isOpenNow: boolean;
  closedReason?: string | null;
  onAddItem: (itemId: string) => void;
  onDecrementItem: (itemId: string) => void;
  onRemoveItem: (itemId: string) => void;
  onRemoveSoldOutItems: () => void;
  onClearCart: () => void;
  onRefreshOperations: () => Promise<void>;
  onOrderCreatedOrUpdated: (order: CafeOrder) => void;
  onOrderDeleted: (deletedOrder: CafeOrder) => void;
  onRestoreItemsToBag: (items: OrderItem[]) => void;
  onOpenOrderHistory: () => void;
}

export function CheckoutDrawer({
  open,
  onClose,
  cart,
  gateways,
  unavailableItemIds,
  acceptingOrders,
  isOpenNow,
  closedReason,
  onAddItem,
  onDecrementItem,
  onRemoveItem,
  onRemoveSoldOutItems,
  onClearCart,
  onRefreshOperations,
  onOrderCreatedOrUpdated,
  onOrderDeleted,
  onRestoreItemsToBag,
  onOpenOrderHistory,
}: CheckoutDrawerProps) {
  const [diningMode, setDiningMode] = useState<DiningMode>('dine-in');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [selectedGateway, setSelectedGateway] = useState<PaymentGateway>('razorpay');
  const [activeOrder, setActiveOrder] = useState<CafeOrder | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [utrInput, setUtrInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [checkingLive, setCheckingLive] = useState(false);
  const [cancellingOrder, setCancellingOrder] = useState(false);
  const [confirmUndoActive, setConfirmUndoActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  if (!open) return null;

  const detailedItems = cart
    .map((entry) => {
      const item = MENU_ITEMS_BY_ID[entry.itemId];
      if (!item) return null;
      return {
        ...item,
        quantity: entry.quantity,
        lineTotal: item.price * entry.quantity,
        isSoldOut: unavailableItemIds.includes(item.id),
      };
    })
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null);

  const soldOutItemsInBag = detailedItems.filter((item) => item.isSoldOut);
  const hasSoldOutInBag = soldOutItemsInBag.length > 0;
  const checkoutBlocked = !isOpenNow || !acceptingOrders || hasSoldOutInBag;

  const subtotal = detailedItems.reduce((sum, item) => sum + item.lineTotal, 0);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;

  const cleanedUtrDigits = utrInput.replace(/\D/g, '').slice(0, 12);

  async function handleCreateOrder() {
    setError(null);
    setStatusNotice(null);
    if (cart.length === 0) return;

    if (!isOpenNow) {
      setError(
        closedReason || "Ordering is currently closed outside IMMY's Coffee Cafe opening hours."
      );
      return;
    }

    if (!acceptingOrders) {
      setError("IMMY's Coffee Cafe is temporarily paused for new orders.");
      return;
    }

    if (hasSoldOutInBag) {
      setError(
        `Remove sold-out item(s) before ordering: ${soldOutItemsInBag.map((i) => i.name).join(', ')}.`
      );
      return;
    }

    setLoading(true);
    try {
      const res = await cafeApi.createPaymentOrder({
        items: cart,
        gateway: selectedGateway,
        diningMode,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        tableOrNotes: notes.trim(),
      });
      setActiveOrder(res.order);
      setQrDataUrl(res.qrDataUrl);
      onOrderCreatedOrUpdated(res.order);
      onClearCart();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create order.');
      void onRefreshOperations();
    } finally {
      setLoading(false);
    }
  }

  async function handleConfirmWithUtr(e: FormEvent) {
    e.preventDefault();
    if (!activeOrder) return;
    setError(null);
    setStatusNotice(null);

    if (cleanedUtrDigits.length !== 12) {
      setError('Enter the complete 12-digit UPI UTR number from your payment app to confirm.');
      return;
    }

    setVerifying(true);
    try {
      const res = await cafeApi.confirmWithUtr({
        orderId: activeOrder.id,
        gateway: selectedGateway,
        upiRefUtr: cleanedUtrDigits,
      });
      setActiveOrder(res.order);
      onOrderCreatedOrUpdated(res.order);
      setStatusNotice('Transaction confirmed with UTR and saved to Order History.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not confirm UTR.');
    } finally {
      setVerifying(false);
    }
  }

  async function handleCheckGatewayStatus() {
    if (!activeOrder) return;
    setError(null);
    setCheckingLive(true);
    try {
      const res = await cafeApi.checkPaymentStatus(activeOrder.id);
      setActiveOrder(res.order);
      onOrderCreatedOrUpdated(res.order);
      setStatusNotice(
        res.order.paymentStatus === 'PAID_VERIFIED'
          ? 'Payment confirmed as completed.'
          : 'Awaiting UTR confirmation. Enter your 12-digit UPI UTR below once payment is done.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to check payment status.');
    } finally {
      setCheckingLive(false);
    }
  }

  async function handleUndoActiveOrder(restoreToBag: boolean) {
    if (!activeOrder) return;
    setError(null);
    setStatusNotice(null);
    setCancellingOrder(true);
    try {
      const target = activeOrder;
      const res = await cafeApi.deleteOrder(target.id);
      onOrderDeleted(res.deletedOrder);
      if (restoreToBag) {
        onRestoreItemsToBag(target.items);
      }
      setActiveOrder(null);
      setQrDataUrl(null);
      setUtrInput('');
      setConfirmUndoActive(false);
      setStatusNotice(
        restoreToBag
          ? `Order ${target.id} cancelled and items returned to your bag. You can also restore it anytime from Order History.`
          : `Order ${target.id} deleted. You can undo this anytime from Order History.`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not cancel this order.');
    } finally {
      setCancellingOrder(false);
    }
  }

  const activeGatewayIsLive =
    selectedGateway === 'razorpay' ? gateways.razorpayLive : gateways.cashfreeLive;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-drawer-title"
      className="fixed inset-0 z-50 flex justify-end bg-[#1D1815]/55 backdrop-blur-xs"
    >
      <div className="flex h-full w-full max-w-lg flex-col bg-[#FAF8F5] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1D1815]/10 px-6 py-5">
          <div>
            <h2
              id="checkout-drawer-title"
              className="font-display text-xl font-medium text-[#1D1815]"
            >
              {activeOrder ? `UTR Confirmation · ${activeOrder.id}` : 'Your Cafe Bag'}
            </h2>
            <p className="mt-0.5 text-xs text-[#6A5E55]">
              {activeOrder
                ? 'Scan the official UPI QR code and confirm with your 12-digit UTR number'
                : `${detailedItems.reduce((sum, i) => sum + i.quantity, 0)} items selected`}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (activeOrder?.paymentStatus === 'PAID_VERIFIED') {
                setActiveOrder(null);
                setQrDataUrl(null);
                setUtrInput('');
              }
              onClose();
            }}
            aria-label="Close bag drawer"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-[#6A5E55] hover:bg-[#1D1815]/5 hover:text-[#1D1815]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {error && (
            <div
              role="alert"
              className="mb-4 rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
            >
              {error}
            </div>
          )}

          {statusNotice && (
            <div className="mb-4 rounded-lg border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-3 text-sm text-[#1F372C]">
              {statusNotice}
            </div>
          )}

          {!activeOrder ? (
            detailedItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <ShoppingBag className="h-10 w-10 text-[#9A8F86]" strokeWidth={1.5} />
                <p className="mt-4 font-display text-lg font-medium text-[#1D1815]">
                  Your order bag is empty
                </p>
                <p className="mt-1 max-w-xs text-sm text-[#6A5E55]">
                  Pick a category in the menu to add fresh coffees, grilled sandwiches, or desserts.
                </p>
                <button
                  type="button"
                  onClick={onClose}
                  className="mt-6 min-h-[42px] rounded-lg bg-[#2A473A] px-5 py-2 text-sm font-medium text-[#FAF8F5] hover:bg-[#1F372C]"
                >
                  Browse Menu
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {!isOpenNow && (
                  <div
                    role="alert"
                    className="rounded-xl border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                  >
                    {closedReason ||
                      "IMMY's Coffee Cafe is currently closed. Ordering opens during scheduled hours."}
                  </div>
                )}

                {isOpenNow && !acceptingOrders && (
                  <div
                    role="alert"
                    className="rounded-xl border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                  >
                    IMMY's Coffee Cafe is temporarily paused for new orders. Please check back in a
                    few minutes.
                  </div>
                )}

                {hasSoldOutInBag && (
                  <div
                    role="alert"
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#9A4B38]/35 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                  >
                    <div>
                      <p className="font-semibold">
                        {soldOutItemsInBag.length}{' '}
                        {soldOutItemsInBag.length === 1 ? 'item is' : 'items are'} now sold out
                      </p>
                      <p className="mt-0.5 text-xs">
                        Remove {soldOutItemsInBag.map((i) => i.name).join(', ')} to place your
                        order.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setError(null);
                        onRemoveSoldOutItems();
                      }}
                      className="min-h-[36px] rounded-lg bg-[#7A3222] px-3 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] whitespace-nowrap shrink-0"
                    >
                      Remove Sold-Out
                    </button>
                  </div>
                )}

                {/* Item list */}
                <div className="divide-y divide-[#1D1815]/10">
                  {detailedItems.map((item) => (
                    <div
                      key={item.id}
                      className={`flex items-center justify-between gap-4 py-3.5 ${
                        item.isSoldOut
                          ? '-mx-2 rounded-lg bg-[#9A4B38]/8 px-2'
                          : ''
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p
                            className={`truncate text-sm font-semibold ${
                              item.isSoldOut ? 'text-[#7A3222] line-through' : 'text-[#1D1815]'
                            }`}
                          >
                            {item.name}
                          </p>
                          {item.isSoldOut && (
                            <span className="text-xs font-semibold text-[#7A3222]">
                              · Sold Out
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 font-mono text-xs text-[#6A5E55] tabular-nums">
                          ₹{item.price} × {item.quantity} = ₹{item.lineTotal}
                        </p>
                      </div>
                      {item.isSoldOut ? (
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.id)}
                          className="inline-flex min-h-[36px] items-center gap-1 rounded-lg border border-[#9A4B38]/35 bg-white px-3 py-1.5 text-xs font-medium text-[#7A3222] hover:bg-[#9A4B38]/10 whitespace-nowrap shrink-0"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Remove
                        </button>
                      ) : (
                        <div className="inline-flex items-center rounded-lg border border-[#1D1815]/15 bg-white">
                          <button
                            type="button"
                            onClick={() => onDecrementItem(item.id)}
                            aria-label={`Decrease ${item.name}`}
                            className="flex h-9 w-9 items-center justify-center text-[#1D1815] hover:bg-[#F4F0EA]"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-7 text-center font-mono text-xs font-semibold tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onAddItem(item.id)}
                            disabled={!isOpenNow || !acceptingOrders}
                            aria-label={`Increase ${item.name}`}
                            className="flex h-9 w-9 items-center justify-center text-[#1D1815] hover:bg-[#F4F0EA] disabled:opacity-40"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Order preferences & optional guest details (No login required) */}
                <div className="space-y-4 border-t border-[#1D1815]/10 pt-5">
                  <div>
                    <span className="block text-xs font-medium text-[#6A5E55]">Order Type</span>
                    <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-[#EFEAE2] p-1">
                      <button
                        type="button"
                        onClick={() => setDiningMode('dine-in')}
                        className={`min-h-[38px] rounded-md text-xs font-medium transition-colors ${
                          diningMode === 'dine-in'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048] hover:text-[#1D1815]'
                        }`}
                      >
                        Garden Table Seating
                      </button>
                      <button
                        type="button"
                        onClick={() => setDiningMode('takeaway')}
                        className={`min-h-[38px] rounded-md text-xs font-medium transition-colors ${
                          diningMode === 'takeaway'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048] hover:text-[#1D1815]'
                        }`}
                      >
                        Highway Takeaway
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="block text-xs font-medium text-[#6A5E55]">
                      Payment Verification Gateway
                    </span>
                    <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-[#EFEAE2] p-1">
                      <button
                        type="button"
                        onClick={() => setSelectedGateway('razorpay')}
                        className={`min-h-[38px] rounded-md text-xs font-medium transition-colors ${
                          selectedGateway === 'razorpay'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048] hover:text-[#1D1815]'
                        }`}
                      >
                        Razorpay UTR Check
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedGateway('cashfree')}
                        className={`min-h-[38px] rounded-md text-xs font-medium transition-colors ${
                          selectedGateway === 'cashfree'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048] hover:text-[#1D1815]'
                        }`}
                      >
                        Cashfree UTR Check
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="immy-customer-name"
                        className="block text-xs font-medium text-[#6A5E55]"
                      >
                        Name (Optional)
                      </label>
                      <input
                        id="immy-customer-name"
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="For order callout"
                        className="mt-1 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="immy-customer-phone"
                        className="block text-xs font-medium text-[#6A5E55]"
                      >
                        Contact No. (Optional)
                      </label>
                      <input
                        id="immy-customer-phone"
                        type="tel"
                        inputMode="numeric"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                        placeholder="10-digit number"
                        className="mt-1 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3 py-2 font-mono text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="immy-order-notes"
                      className="block text-xs font-medium text-[#6A5E55]"
                    >
                      Table Number or Barista Note
                    </label>
                    <input
                      id="immy-order-notes"
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. Table 4, less sugar, extra hot"
                      className="mt-1.5 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3.5 py-2.5 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                    />
                  </div>
                </div>

                {/* Bill summary */}
                <div className="space-y-2 border-t border-[#1D1815]/10 pt-4 text-sm">
                  <div className="flex justify-between text-[#5A5048]">
                    <span>Items Subtotal</span>
                    <span className="font-mono tabular-nums">₹{subtotal}</span>
                  </div>
                  <div className="flex justify-between text-[#5A5048]">
                    <span>Cafe GST (5%)</span>
                    <span className="font-mono tabular-nums">₹{tax}</span>
                  </div>
                  <div className="flex justify-between border-t border-[#1D1815]/10 pt-2.5 text-base font-semibold text-[#1D1815]">
                    <span>Total Payable</span>
                    <span className="font-mono tabular-nums">₹{total}</span>
                  </div>
                </div>
              </div>
            )
          ) : (
            /* Active UPI QR + 12-Digit UTR Confirmation View */
            <div className="space-y-6">
              {activeOrder.paymentStatus === 'PAID_VERIFIED' ? (
                <div className="rounded-2xl border border-[#2A473A]/25 bg-[#2A473A]/8 p-6 text-center">
                  <CheckCircle2 className="mx-auto h-11 w-11 text-[#2A473A]" />
                  <h3 className="mt-3 font-display text-2xl font-medium text-[#1D1815]">
                    UTR Transaction Confirmed
                  </h3>
                  <p className="mt-1.5 text-sm text-[#4A413B]">
                    {activeOrder.verificationMessage}
                  </p>
                  <div className="mt-5 space-y-1.5 border-t border-[#2A473A]/15 pt-4 text-left text-xs text-[#4A413B]">
                    <div className="flex justify-between">
                      <span>Order ID</span>
                      <span className="font-mono font-semibold text-[#1D1815]">
                        {activeOrder.id}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Amount Paid</span>
                      <span className="font-mono font-semibold text-[#1D1815] tabular-nums">
                        ₹{activeOrder.total}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Confirmed UTR</span>
                      <span className="font-mono font-semibold text-[#1D1815]">
                        {activeOrder.upiRefUtr}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Gateway Check</span>
                      <span className="font-medium capitalize text-[#1D1815]">
                        {activeOrder.gateway}
                      </span>
                    </div>
                  </div>
                  <div className="mt-6 flex flex-col gap-2.5 sm:flex-row">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveOrder(null);
                        setQrDataUrl(null);
                        setUtrInput('');
                        setConfirmUndoActive(false);
                        onClose();
                        onOpenOrderHistory();
                      }}
                      className="flex-1 min-h-[42px] rounded-lg bg-[#2A473A] px-4 py-2 text-sm font-medium text-[#FAF8F5] hover:bg-[#1F372C]"
                    >
                      View Order History
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveOrder(null);
                        setQrDataUrl(null);
                        setUtrInput('');
                        setConfirmUndoActive(false);
                        onClose();
                      }}
                      className="flex-1 min-h-[42px] rounded-lg border border-[#1D1815]/20 px-4 py-2 text-sm font-medium text-[#1D1815] hover:bg-[#1D1815]/5"
                    >
                      Done
                    </button>
                  </div>

                  {/* Allow customer to undo / delete even after confirmation */}
                  <div className="mt-4 border-t border-[#2A473A]/15 pt-4">
                    {!confirmUndoActive ? (
                      <button
                        type="button"
                        onClick={() => setConfirmUndoActive(true)}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#7A3222] hover:underline"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Undo / Delete this Order
                      </button>
                    ) : (
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <span className="text-xs text-[#7A3222]">Delete order {activeOrder.id}?</span>
                        <button
                          type="button"
                          disabled={cancellingOrder}
                          onClick={() => handleUndoActiveOrder(false)}
                          className="rounded-md bg-[#7A3222] px-3 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] disabled:opacity-50"
                        >
                          {cancellingOrder ? 'Deleting...' : 'Confirm Delete'}
                        </button>
                        <button
                          type="button"
                          disabled={cancellingOrder}
                          onClick={() => setConfirmUndoActive(false)}
                          className="rounded-md border border-[#1D1815]/20 px-3 py-1.5 text-xs font-medium text-[#1D1815] hover:bg-[#1D1815]/5"
                        >
                          Keep Order
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  {/* Step 1: Strictly QR-Code-Only UPI Payment Card */}
                  <div className="rounded-2xl border border-[#1D1815]/12 bg-white p-5 text-center">
                    <p className="text-xs font-medium text-[#6A5E55]">
                      Step 1 · Scan Official Cafe UPI QR with GPay, PhonePe, Paytm or FamPay
                    </p>
                    <p className="mt-1 font-mono text-2xl font-semibold text-[#1D1815] tabular-nums">
                      ₹{activeOrder.total}
                    </p>

                    {qrDataUrl && (
                      <div className="mx-auto mt-4 w-fit rounded-xl border border-[#1D1815]/10 bg-[#FAF8F5] p-3">
                        <img
                          src={qrDataUrl}
                          alt={`Official UPI QR code to pay ₹${activeOrder.total} to IMMY's Coffee Cafe`}
                          className="h-52 w-52"
                        />
                      </div>
                    )}

                    <p className="mt-3 text-xs font-medium text-[#2A473A]">
                      Official QR-Only Online Payment · IMMY's Coffee Cafe
                    </p>
                    <p className="mt-1 text-xs text-[#6A5E55]">
                      For merchant security, online UPI payments are accepted exclusively by
                      scanning this official QR code.
                    </p>
                  </div>

                  {/* Step 2: Mandatory 12-Digit UTR Confirmation + Razorpay / Cashfree Check */}
                  <div className="rounded-2xl border border-[#1D1815]/12 bg-[#F4F0EA] p-5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4 text-[#2A473A]" />
                        <h3 className="text-sm font-semibold text-[#1D1815]">
                          Step 2 · Confirm Transaction with UTR
                        </h3>
                      </div>
                      <button
                        type="button"
                        onClick={handleCheckGatewayStatus}
                        disabled={checkingLive}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#2A473A] hover:underline disabled:opacity-50"
                      >
                        <RefreshCw className={`h-3.5 w-3.5 ${checkingLive ? 'animate-spin' : ''}`} />
                        Check Status
                      </button>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-2 rounded-lg bg-[#E7E1D7] p-1">
                      <button
                        type="button"
                        onClick={() => setSelectedGateway('razorpay')}
                        className={`min-h-[36px] rounded-md text-xs font-medium transition-colors ${
                          selectedGateway === 'razorpay'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048]'
                        }`}
                      >
                        Razorpay
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedGateway('cashfree')}
                        className={`min-h-[36px] rounded-md text-xs font-medium transition-colors ${
                          selectedGateway === 'cashfree'
                            ? 'bg-white text-[#1D1815] shadow-xs'
                            : 'text-[#5A5048]'
                        }`}
                      >
                        Cashfree
                      </button>
                    </div>

                    <p className="mt-3 text-xs leading-relaxed text-[#5A5048]">
                      {activeGatewayIsLive
                        ? `Live ${selectedGateway === 'razorpay' ? 'Razorpay' : 'Cashfree'} verification is active (${activeOrder.gatewayOrderId}). Enter your 12-digit UPI UTR below after scanning and paying.`
                        : `After scanning the official QR to pay ₹${activeOrder.total}, copy the 12-digit UTR / UPI Reference Number from your payment receipt and submit below to confirm your order.`}
                    </p>

                    <form onSubmit={handleConfirmWithUtr} className="mt-3.5 space-y-3">
                      <div>
                        <div className="flex items-center justify-between">
                          <label
                            htmlFor="immy-utr-input"
                            className="block text-xs font-medium text-[#1D1815]"
                          >
                            12-Digit UPI UTR Number
                          </label>
                          <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                            {cleanedUtrDigits.length}/12 digits
                          </span>
                        </div>
                        <input
                          id="immy-utr-input"
                          type="text"
                          inputMode="numeric"
                          maxLength={12}
                          required
                          value={cleanedUtrDigits}
                          onChange={(e) => setUtrInput(e.target.value)}
                          placeholder="e.g. 432619820415"
                          className="mt-1 w-full rounded-lg border border-[#1D1815]/20 bg-white px-3.5 py-2.5 font-mono text-sm tracking-wider text-[#1D1815] outline-none focus:border-[#2A473A]"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={verifying || cleanedUtrDigits.length !== 12}
                        className="w-full min-h-[44px] rounded-lg bg-[#2A473A] px-4 py-2 text-sm font-medium text-[#FAF8F5] transition-colors hover:bg-[#1F372C] disabled:opacity-55"
                      >
                        {verifying
                          ? `Confirming UTR via ${selectedGateway === 'razorpay' ? 'Razorpay' : 'Cashfree'}...`
                          : `Confirm Payment with UTR (${
                              selectedGateway === 'razorpay' ? 'Razorpay' : 'Cashfree'
                            })`}
                      </button>
                    </form>
                  </div>

                  {/* Step 3: Undo / Cancel Pending Order & Edit Bag */}
                  <div className="rounded-xl border border-[#1D1815]/10 bg-white px-4 py-3.5">
                    {!confirmUndoActive ? (
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs text-[#5A5048]">
                          Changed your mind or want to edit items?
                        </span>
                        <button
                          type="button"
                          onClick={() => setConfirmUndoActive(true)}
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#7A3222] hover:underline"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                          Undo / Cancel Order
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-medium text-[#7A3222]">
                          Cancel {activeOrder.id} and return items to bag?
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            disabled={cancellingOrder}
                            onClick={() => handleUndoActiveOrder(true)}
                            className="rounded-md bg-[#7A3222] px-3 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] disabled:opacity-50"
                          >
                            {cancellingOrder ? 'Cancelling...' : 'Undo & Edit Bag'}
                          </button>
                          <button
                            type="button"
                            disabled={cancellingOrder}
                            onClick={() => setConfirmUndoActive(false)}
                            className="rounded-md border border-[#1D1815]/15 px-3 py-1.5 text-xs font-medium text-[#1D1815] hover:bg-[#F4F0EA]"
                          >
                            Keep
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer CTA for Bag Review */}
        {!activeOrder && detailedItems.length > 0 && (
          <div className="border-t border-[#1D1815]/10 bg-[#FAF8F5] px-6 py-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClearCart}
                aria-label="Clear bag"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-[#1D1815]/15 text-[#6A5E55] hover:border-[#9A4B38]/40 hover:text-[#9A4B38]"
              >
                <Trash2 className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={handleCreateOrder}
                disabled={loading || checkoutBlocked}
                className="flex-1 min-h-[44px] rounded-lg bg-[#2A473A] px-5 py-2.5 text-sm font-medium text-[#FAF8F5] transition-colors hover:bg-[#1F372C] disabled:cursor-not-allowed disabled:opacity-55"
              >
                {!isOpenNow
                  ? 'Cafe Closed · Outside Opening Hours'
                  : !acceptingOrders
                    ? 'Orders Temporarily Paused'
                    : hasSoldOutInBag
                      ? 'Remove Sold-Out Items to Order'
                      : loading
                        ? 'Generating UPI QR...'
                        : `Pay via UPI QR & UTR · ₹${total}`}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
