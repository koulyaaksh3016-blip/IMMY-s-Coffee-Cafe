import { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Trash2,
  Undo2,
  X,
} from 'lucide-react';
import { cafeApi } from '../lib/api';
import type { CafeOrder, OrderItem, PaymentGateway } from '../types';

interface OrdersPanelProps {
  open: boolean;
  onClose: () => void;
  orders: CafeOrder[];
  deletedOrders: CafeOrder[];
  onOrderUpdated: (order: CafeOrder) => void;
  onOrderDeleted: (deletedOrder: CafeOrder) => void;
  onOrderRestored: (restoredOrder: CafeOrder) => void;
  onReorder: (items: OrderItem[]) => void;
}

export function OrdersPanel({
  open,
  onClose,
  orders,
  deletedOrders,
  onOrderUpdated,
  onOrderDeleted,
  onOrderRestored,
  onReorder,
}: OrdersPanelProps) {
  const [checkingOrderId, setCheckingOrderId] = useState<string | null>(null);
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);
  const [restoringOrderId, setRestoringOrderId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [lastDeletedOrder, setLastDeletedOrder] = useState<CafeOrder | null>(null);
  const [panelError, setPanelError] = useState<string | null>(null);
  const [utrInputs, setUtrInputs] = useState<Record<string, string>>({});
  const [gatewayChoice, setGatewayChoice] = useState<Record<string, PaymentGateway>>({});
  const [orderMessage, setOrderMessage] = useState<Record<string, string>>({});
  const [orderError, setOrderError] = useState<Record<string, string>>({});

  if (!open) return null;

  async function handleRefreshStatus(order: CafeOrder) {
    setCheckingOrderId(order.id);
    setOrderError((prev) => ({ ...prev, [order.id]: '' }));
    try {
      const res = await cafeApi.checkPaymentStatus(order.id);
      onOrderUpdated(res.order);
      setOrderMessage((prev) => ({
        ...prev,
        [order.id]:
          res.order.paymentStatus === 'PAID_VERIFIED'
            ? 'Payment confirmed.'
            : 'Pending UTR confirmation — enter your 12-digit UPI UTR below.',
      }));
    } catch (err) {
      setOrderError((prev) => ({
        ...prev,
        [order.id]: err instanceof Error ? err.message : 'Could not check status.',
      }));
    } finally {
      setCheckingOrderId(null);
    }
  }

  async function handleConfirmPendingOrder(order: CafeOrder) {
    const cleaned = (utrInputs[order.id] || '').replace(/\D/g, '').slice(0, 12);
    const chosenGateway = gatewayChoice[order.id] || order.gateway;
    setOrderError((prev) => ({ ...prev, [order.id]: '' }));
    setOrderMessage((prev) => ({ ...prev, [order.id]: '' }));

    if (cleaned.length !== 12) {
      setOrderError((prev) => ({
        ...prev,
        [order.id]: 'Please enter a valid 12-digit UPI UTR number.',
      }));
      return;
    }

    setCheckingOrderId(order.id);
    try {
      const res = await cafeApi.confirmWithUtr({
        orderId: order.id,
        gateway: chosenGateway,
        upiRefUtr: cleaned,
      });
      onOrderUpdated(res.order);
      setOrderMessage((prev) => ({
        ...prev,
        [order.id]: res.order.verificationMessage,
      }));
    } catch (err) {
      setOrderError((prev) => ({
        ...prev,
        [order.id]: err instanceof Error ? err.message : 'UTR confirmation failed.',
      }));
    } finally {
      setCheckingOrderId(null);
    }
  }

  async function handleDeleteOrder(order: CafeOrder) {
    setPanelError(null);
    setDeletingOrderId(order.id);
    try {
      const res = await cafeApi.deleteOrder(order.id);
      setConfirmDeleteId(null);
      setLastDeletedOrder(res.deletedOrder);
      onOrderDeleted(res.deletedOrder);
    } catch (err) {
      setPanelError(err instanceof Error ? err.message : 'Unable to delete order.');
    } finally {
      setDeletingOrderId(null);
    }
  }

  async function handleRestoreOrder(orderId: string) {
    setPanelError(null);
    setRestoringOrderId(orderId);
    try {
      const res = await cafeApi.restoreOrder(orderId);
      if (lastDeletedOrder?.id === orderId) {
        setLastDeletedOrder(null);
      }
      onOrderRestored(res.order);
    } catch (err) {
      setPanelError(err instanceof Error ? err.message : 'Unable to restore order.');
    } finally {
      setRestoringOrderId(null);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="orders-panel-title"
      className="fixed inset-0 z-50 flex justify-end bg-[#1D1815]/55 backdrop-blur-xs"
    >
      <div className="flex h-full w-full max-w-xl flex-col bg-[#FAF8F5] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#1D1815]/10 px-6 py-5">
          <div>
            <h2
              id="orders-panel-title"
              className="font-display text-xl font-medium text-[#1D1815]"
            >
              Order History & UTR Receipts
            </h2>
            <p className="mt-0.5 font-mono text-xs text-[#6A5E55]">
              {orders.length} active {orders.length === 1 ? 'order' : 'orders'}
              {deletedOrders.length > 0 ? ` · ${deletedOrders.length} recently deleted` : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close order history panel"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-[#6A5E55] hover:bg-[#1D1815]/5 hover:text-[#1D1815]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {panelError && (
            <div
              role="alert"
              className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
            >
              {panelError}
            </div>
          )}

          {/* Instant Undo Banner after deleting an order */}
          {lastDeletedOrder && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-3 text-sm text-[#1F372C]">
              <span>
                Deleted order <span className="font-mono font-semibold">{lastDeletedOrder.id}</span>{' '}
                (₹{lastDeletedOrder.total}).
              </span>
              <button
                type="button"
                disabled={restoringOrderId === lastDeletedOrder.id}
                onClick={() => handleRestoreOrder(lastDeletedOrder.id)}
                className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg bg-[#2A473A] px-3 py-1 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-55 whitespace-nowrap shrink-0"
              >
                <Undo2 className="h-3.5 w-3.5" />
                {restoringOrderId === lastDeletedOrder.id ? 'Restoring...' : 'Undo Delete'}
              </button>
            </div>
          )}

          {orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingBag className="h-10 w-10 text-[#9A8F86]" strokeWidth={1.5} />
              <p className="mt-4 font-display text-lg font-medium text-[#1D1815]">
                No active orders right now
              </p>
              <p className="mt-1 max-w-xs text-sm text-[#6A5E55]">
                Add items from our cafe menu, pay via UPI QR, and confirm with your 12-digit UTR to
                see your receipts here.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => {
                const isPaid = order.paymentStatus === 'PAID_VERIFIED';
                const isConfirmingDelete = confirmDeleteId === order.id;
                const currentGateway = gatewayChoice[order.id] || order.gateway;
                const currentUtr = (utrInputs[order.id] || '').replace(/\D/g, '').slice(0, 12);
                const formattedDate = new Date(order.createdAt).toLocaleString('en-IN', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={order.id}
                    className="rounded-xl border border-[#1D1815]/12 bg-white p-5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2 border-b border-[#1D1815]/8 pb-3">
                      <div>
                        <div className="flex items-center gap-2 text-xs text-[#6A5E55]">
                          <span className="font-mono font-semibold text-[#1D1815]">
                            {order.id}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{formattedDate}</span>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize">{order.diningMode}</span>
                        </div>
                        <div className="mt-1.5 flex items-center gap-1.5 text-xs font-medium">
                          {isPaid ? (
                            <>
                              <CheckCircle2 className="h-4 w-4 text-[#2A473A]" />
                              <span className="text-[#2A473A]">
                                UTR Confirmed ({order.gateway})
                              </span>
                            </>
                          ) : (
                            <>
                              <Clock className="h-4 w-4 text-[#9A5B25]" />
                              <span className="text-[#9A5B25]">
                                Awaiting 12-Digit UTR Confirmation
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                      <span className="font-mono text-base font-semibold text-[#1D1815] tabular-nums">
                        ₹{order.total}
                      </span>
                    </div>

                    <ul className="mt-3 space-y-1.5 text-sm text-[#3B332E]">
                      {order.items.map((item) => (
                        <li key={item.itemId} className="flex justify-between gap-3">
                          <span>
                            {item.quantity} × {item.name}
                          </span>
                          <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                            ₹{item.lineTotal}
                          </span>
                        </li>
                      ))}
                    </ul>

                    {order.tableOrNotes && (
                      <p className="mt-2.5 text-xs text-[#6A5E55]">Note: {order.tableOrNotes}</p>
                    )}

                    {order.upiRefUtr && (
                      <p className="mt-1.5 font-mono text-xs text-[#2A473A]">
                        Confirmed UTR: {order.upiRefUtr}
                      </p>
                    )}

                    {!isPaid && (
                      <div className="mt-3.5 space-y-2.5 border-t border-[#1D1815]/8 pt-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              setGatewayChoice((prev) => ({ ...prev, [order.id]: 'razorpay' }))
                            }
                            className={`rounded-md px-2.5 py-1 text-xs font-medium ${
                              currentGateway === 'razorpay'
                                ? 'bg-[#2A473A] text-[#FAF8F5]'
                                : 'bg-[#EFEAE2] text-[#5A5048]'
                            }`}
                          >
                            Razorpay
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setGatewayChoice((prev) => ({ ...prev, [order.id]: 'cashfree' }))
                            }
                            className={`rounded-md px-2.5 py-1 text-xs font-medium ${
                              currentGateway === 'cashfree'
                                ? 'bg-[#2A473A] text-[#FAF8F5]'
                                : 'bg-[#EFEAE2] text-[#5A5048]'
                            }`}
                          >
                            Cashfree
                          </button>
                        </div>

                        <div className="flex flex-col gap-2 sm:flex-row">
                          <input
                            type="text"
                            inputMode="numeric"
                            maxLength={12}
                            value={currentUtr}
                            onChange={(e) =>
                              setUtrInputs((prev) => ({
                                ...prev,
                                [order.id]: e.target.value.replace(/\D/g, '').slice(0, 12),
                              }))
                            }
                            placeholder="Enter 12-digit UPI UTR"
                            className="flex-1 rounded-lg border border-[#1D1815]/15 px-3 py-2 font-mono text-xs text-[#1D1815] outline-none focus:border-[#2A473A]"
                          />
                          <button
                            type="button"
                            disabled={checkingOrderId === order.id || currentUtr.length !== 12}
                            onClick={() => handleConfirmPendingOrder(order)}
                            className="inline-flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg bg-[#2A473A] px-3.5 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-50 whitespace-nowrap shrink-0"
                          >
                            <ShieldCheck className="h-3.5 w-3.5" />
                            Confirm UTR
                          </button>
                        </div>
                      </div>
                    )}

                    {orderError[order.id] && (
                      <p className="mt-2 text-xs text-[#7A3222]">{orderError[order.id]}</p>
                    )}
                    {orderMessage[order.id] && (
                      <p className="mt-2 text-xs text-[#2A473A]">{orderMessage[order.id]}</p>
                    )}

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#1D1815]/8 pt-3">
                      <button
                        type="button"
                        onClick={() => handleRefreshStatus(order)}
                        disabled={checkingOrderId === order.id}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#5A5048] hover:text-[#1D1815]"
                      >
                        <RefreshCw
                          className={`h-3.5 w-3.5 ${
                            checkingOrderId === order.id ? 'animate-spin' : ''
                          }`}
                        />
                        Check Status
                      </button>

                      <div className="flex flex-wrap items-center gap-2">
                        {isConfirmingDelete ? (
                          <>
                            <button
                              type="button"
                              disabled={deletingOrderId === order.id}
                              onClick={() => handleDeleteOrder(order)}
                              className="inline-flex min-h-[34px] items-center gap-1 rounded-lg bg-[#7A3222] px-3 py-1 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] disabled:opacity-50"
                            >
                              {deletingOrderId === order.id ? 'Deleting...' : 'Confirm Delete'}
                            </button>
                            <button
                              type="button"
                              disabled={deletingOrderId === order.id}
                              onClick={() => setConfirmDeleteId(null)}
                              className="inline-flex min-h-[34px] items-center rounded-lg border border-[#1D1815]/15 px-3 py-1 text-xs font-medium text-[#5A5048] hover:text-[#1D1815]"
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(order.id)}
                              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-[#9A4B38]/30 px-3 py-1.5 text-xs font-medium text-[#7A3222] hover:bg-[#9A4B38]/8"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              Delete Order
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onReorder(order.items);
                                onClose();
                              }}
                              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-[#2A473A]/30 px-3 py-1.5 text-xs font-medium text-[#2A473A] hover:bg-[#2A473A]/8"
                            >
                              <RotateCcw className="h-3.5 w-3.5" />
                              Reorder
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Recently Deleted Orders Section — One-Click Undo */}
          {deletedOrders.length > 0 && (
            <div className="border-t border-[#1D1815]/12 pt-5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold tracking-wide text-[#6A5E55] uppercase">
                  Recently Deleted ({deletedOrders.length})
                </h3>
                <span className="text-xs text-[#6A5E55]">Restore any order anytime</span>
              </div>
              <div className="mt-3 space-y-3">
                {deletedOrders.map((order) => (
                  <div
                    key={order.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-dashed border-[#1D1815]/20 bg-[#F4F0EA]/70 p-4"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#5A5048]">
                        <span className="font-mono font-semibold text-[#1D1815]">{order.id}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">₹{order.total}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {order.items.reduce((sum, i) => sum + i.quantity, 0)} items
                        </span>
                      </div>
                      <p className="mt-1 truncate text-xs text-[#6A5E55]">
                        {order.items.map((i) => `${i.quantity}× ${i.name}`).join(', ')}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={restoringOrderId === order.id}
                      onClick={() => handleRestoreOrder(order.id)}
                      className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-[#2A473A] bg-white px-3 py-1.5 text-xs font-medium text-[#2A473A] hover:bg-[#2A473A] hover:text-[#FAF8F5] disabled:opacity-50 whitespace-nowrap shrink-0"
                    >
                      <Undo2 className="h-3.5 w-3.5" />
                      {restoringOrderId === order.id ? 'Restoring...' : 'Undo / Restore'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
