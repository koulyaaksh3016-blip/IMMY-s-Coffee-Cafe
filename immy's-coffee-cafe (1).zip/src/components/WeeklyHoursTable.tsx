import { Clock } from 'lucide-react';
import type { CafeOpenStatus, DayOfWeekKey, WeeklyOpeningHours } from '../types';

export const DAY_ORDER: DayOfWeekKey[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
];

export const DAY_LABELS: Record<DayOfWeekKey, string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
  sunday: 'Sunday',
};

export const DEFAULT_WEEKLY_HOURS: WeeklyOpeningHours = {
  monday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  tuesday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  wednesday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  thursday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  friday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  saturday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  sunday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
};

export function formatTime24To12(hhmm: string): string {
  if (!/^\d{2}:\d{2}$/.test(hhmm)) return hhmm;
  const [hStr, mStr] = hhmm.split(':');
  const h24 = Number(hStr);
  const mins = Number(mStr);
  if (!Number.isInteger(h24) || !Number.isInteger(mins)) return hhmm;
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${String(h12).padStart(2, '0')}:${String(mins).padStart(2, '0')} ${suffix}`;
}

interface WeeklyHoursTableProps {
  weeklyHours: WeeklyOpeningHours;
  openStatus: CafeOpenStatus | null;
}

export function WeeklyHoursTable({ weeklyHours, openStatus }: WeeklyHoursTableProps) {
  const todayKey = openStatus?.currentDayKey;

  return (
    <section
      id="opening-hours"
      aria-labelledby="weekly-hours-heading"
      className="mx-auto max-w-[1200px] px-6 py-16 lg:px-8 lg:py-20"
    >
      <div className="flex flex-col gap-4 border-b border-[#1D1815]/10 pb-7 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <p className="flex items-center gap-1.5 text-xs font-medium tracking-wide text-[#6A5E55]">
            <Clock className="h-3.5 w-3.5 text-[#2A473A]" />
            Weekly Garden Schedule · Indian Standard Time (IST)
          </p>
          <h2
            id="weekly-hours-heading"
            className="mt-2 font-display text-3xl font-medium tracking-tight text-[#1D1815] sm:text-4xl"
          >
            Weekly Opening Hours
          </h2>
        </div>

        {openStatus && (
          <div className="text-sm text-[#4E453E] md:text-right">
            <p
              className={`font-semibold ${
                openStatus.isOpenNow ? 'text-[#2A473A]' : 'text-[#7A3222]'
              }`}
            >
              {openStatus.isOpenNow
                ? `Open Now · ${openStatus.currentDayLabel} (${openStatus.todayScheduleLabel})`
                : `Currently Closed · ${openStatus.currentDayLabel} (${openStatus.todayScheduleLabel})`}
            </p>
            <p className="mt-0.5 font-mono text-xs text-[#6A5E55] tabular-nums">
              Cafe Time: {openStatus.currentTimeIst} IST · Ordering & table booking active only
              during opening hours
            </p>
          </div>
        )}
      </div>

      <div className="mt-8 overflow-hidden rounded-2xl border border-[#1D1815]/12 bg-[#FAF8F5]">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[520px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-[#1D1815]/10 bg-[#F4F0EA] text-xs font-semibold tracking-wide text-[#5A5048]">
                <th scope="col" className="px-6 py-3.5">
                  Day
                </th>
                <th scope="col" className="px-6 py-3.5">
                  Opening Hours (IST)
                </th>
                <th scope="col" className="px-6 py-3.5">
                  Table Booking & Ordering Window
                </th>
                <th scope="col" className="px-6 py-3.5 text-right">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1D1815]/10">
              {DAY_ORDER.map((dayKey) => {
                const schedule = weeklyHours[dayKey] || DEFAULT_WEEKLY_HOURS[dayKey];
                const isToday = todayKey === dayKey;
                const rangeText = schedule.isOpen
                  ? `${formatTime24To12(schedule.openTime)} – ${formatTime24To12(schedule.closeTime)}`
                  : 'Closed';

                let statusLabel = schedule.isOpen ? 'Open' : 'Closed';
                let statusTone = schedule.isOpen ? 'text-[#2A473A]' : 'text-[#7A3222]';
                if (isToday && openStatus) {
                  if (!schedule.isOpen) {
                    statusLabel = 'Closed Today';
                    statusTone = 'text-[#7A3222]';
                  } else if (openStatus.isOpenNow) {
                    statusLabel = 'Open Now';
                    statusTone = 'text-[#2A473A]';
                  } else {
                    statusLabel = 'Closed Now';
                    statusTone = 'text-[#7A3222]';
                  }
                }

                return (
                  <tr
                    key={dayKey}
                    className={
                      isToday
                        ? 'bg-[#2A473A]/6'
                        : 'transition-colors hover:bg-[#F4F0EA]/60'
                    }
                  >
                    <td className="px-6 py-4 font-medium text-[#1D1815]">
                      <div className="flex items-center gap-2">
                        <span className={isToday ? 'font-semibold text-[#2A473A]' : ''}>
                          {DAY_LABELS[dayKey]}
                        </span>
                        {isToday && (
                          <span className="font-mono text-xs font-semibold text-[#2A473A]">
                            · Today
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 font-mono text-sm font-medium text-[#1D1815] tabular-nums">
                      {rangeText}
                    </td>
                    <td className="px-6 py-4 text-xs text-[#5A5048]">
                      {schedule.isOpen
                        ? 'Garden tables & UPI QR orders within opening hours'
                        : 'No orders or garden table bookings accepted'}
                    </td>
                    <td className={`px-6 py-4 text-right text-xs font-semibold ${statusTone}`}>
                      {statusLabel}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
