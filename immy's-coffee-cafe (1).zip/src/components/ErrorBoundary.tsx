import { Component, type ErrorInfo, type ReactNode } from 'react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = {
    hasError: false,
    message: '',
  };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    let readable = error.message || 'An unexpected error occurred.';
    try {
      const parsed = JSON.parse(readable) as { error?: string };
      if (parsed && typeof parsed.error === 'string') {
        readable = parsed.error;
      }
    } catch {
      // Keep original message
    }
    return { hasError: true, message: readable };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('Application ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-[#FAF8F5] p-6 text-[#1D1815]">
          <div className="max-w-md rounded-2xl border border-[#1D1815]/15 bg-white p-8 text-center shadow-sm">
            <h1 className="font-display text-2xl font-medium">Something went wrong</h1>
            <p className="mt-2 text-sm text-[#5A5048]">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-6 min-h-[42px] rounded-lg bg-[#2A473A] px-5 py-2 text-sm font-medium text-[#FAF8F5] hover:bg-[#1F372C]"
            >
              Reload Cafe App
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
