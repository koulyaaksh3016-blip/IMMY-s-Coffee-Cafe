import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  Calendar,
  CheckCircle2,
  ClipboardList,
  Clock,
  Lock,
  LogOut,
  Phone,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Trash2,
  Undo2,
  UserCheck,
  UserMinus,
  Users,
  X,
} from 'lucide-react';
import { signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  type Timestamp,
} from 'firebase/firestore';
import { MENU_CATEGORIES } from '../data/menu';
import {
  auth,
  db,
  emailToManagerId,
  googleProvider,
  handleFirestoreError,
  normalizeEmail,
  OperationType,
} from '../firebase';
import { cafeApi } from '../lib/api';
import { DAY_LABELS, DAY_ORDER, DEFAULT_WEEKLY_HOURS } from './WeeklyHoursTable';
import type {
  CafeOpenStatus,
  CafeOperationsSettings,
  CafeOrder,
  DayOfWeekKey,
  KitchenStatus,
  ManagerRecord,
  PaymentGateway,
  StaffBookingsSummary,
  StaffNoteCategory,
  StaffOrdersSummary,
  StaffRole,
  StaffShiftNote,
  TableBooking,
  TableBookingStatus,
  WeeklyOpeningHours,
} from '../types';

interface StaffConsoleDrawerProps {
  open: boolean;
  onClose: () => void;
  firebaseUser: User | null;
  authReady: boolean;
  staffRole: StaffRole;
  operations: CafeOperationsSettings;
  weeklyHours: WeeklyOpeningHours;
  openStatus: CafeOpenStatus | null;
  onOperationsSaved: (next: CafeOperationsSettings) => void;
  onHoursSaved: (nextHours: WeeklyOpeningHours, nextStatus: CafeOpenStatus) => void;
  onStaffOrdersMutated?: () => void;
  onStaffBookingsMutated?: () => void;
}

type ConsoleTab = 'orders' | 'bookings' | 'operations' | 'notes' | 'managers';

const EMAIL_PATTERN = /^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/;

function formatTimestamp(ts: unknown): string {
  if (!ts) return '';
  if (typeof ts === 'string') {
    return new Date(ts).toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  const maybeTs = ts as Timestamp;
  if (typeof maybeTs?.toDate === 'function') {
    return maybeTs.toDate().toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  return '';
}

export function StaffConsoleDrawer({
  open,
  onClose,
  firebaseUser,
  authReady,
  staffRole,
  operations,
  weeklyHours,
  openStatus,
  onOperationsSaved,
  onHoursSaved,
  onStaffOrdersMutated,
  onStaffBookingsMutated,
}: StaffConsoleDrawerProps) {
  const [activeTab, setActiveTab] = useState<ConsoleTab>('orders');
  const [authError, setAuthError] = useState<string | null>(null);
  const [signingIn, setSigningIn] = useState(false);

  // Orders & UTRs state (from Express backend verified via Firebase ID token)
  const [staffOrders, setStaffOrders] = useState<CafeOrder[]>([]);
  const [deletedStaffOrders, setDeletedStaffOrders] = useState<CafeOrder[]>([]);
  const [confirmDeleteOrderId, setConfirmDeleteOrderId] = useState<string | null>(null);
  const [lastDeletedStaffOrder, setLastDeletedStaffOrder] = useState<CafeOrder | null>(null);
  const [summary, setSummary] = useState<StaffOrdersSummary>({
    totalOrders: 0,
    confirmedCount: 0,
    pendingCount: 0,
    verifiedRevenue: 0,
  });
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [ordersError, setOrdersError] = useState<string | null>(null);
  const [utrDrafts, setUtrDrafts] = useState<Record<string, string>>({});
  const [gatewayDrafts, setGatewayDrafts] = useState<Record<string, PaymentGateway>>({});
  const [busyOrderId, setBusyOrderId] = useState<string | null>(null);

  // Table Bookings state (Owner + Active Manager)
  const [staffBookings, setStaffBookings] = useState<TableBooking[]>([]);
  const [bookingsSummary, setBookingsSummary] = useState<StaffBookingsSummary>({
    totalTables: 8,
    totalBookings: 0,
    todayCount: 0,
    confirmedCount: 0,
    seatedCount: 0,
    totalUpcomingGuests: 0,
  });
  const [bookingsTodayIso, setBookingsTodayIso] = useState<string>('');
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [bookingsError, setBookingsError] = useState<string | null>(null);
  const [bookingsFeedback, setBookingsFeedback] = useState<string | null>(null);
  const [bookingStatusFilter, setBookingStatusFilter] = useState<'all' | TableBookingStatus>('all');
  const [bookingDateScope, setBookingDateScope] = useState<'all' | 'today'>('all');
  const [busyBookingId, setBusyBookingId] = useState<string | null>(null);
  const [confirmDeleteBookingId, setConfirmDeleteBookingId] = useState<string | null>(null);
  const [totalTablesDraft, setTotalTablesDraft] = useState<number>(8);
  const [savingTableConfig, setSavingTableConfig] = useState(false);

  // Operations settings local form state
  const [acceptingOrders, setAcceptingOrders] = useState(operations.acceptingOrders);
  const [prepTimeMinutes, setPrepTimeMinutes] = useState(operations.prepTimeMinutes);
  const [dailySpecialNotice, setDailySpecialNotice] = useState(operations.dailySpecialNotice);
  const [unavailableItemIds, setUnavailableItemIds] = useState<string[]>(
    operations.unavailableItemIds
  );
  const [stockSearch, setStockSearch] = useState('');
  const [showSoldOutOnly, setShowSoldOutOnly] = useState(false);
  const [savingOps, setSavingOps] = useState(false);
  const [busyStockItemId, setBusyStockItemId] = useState<string | null>(null);
  const [opsFeedback, setOpsFeedback] = useState<string | null>(null);
  const [opsError, setOpsError] = useState<string | null>(null);

  // Weekly Opening Hours editor state (Owner + Active Manager)
  const [hoursDraft, setHoursDraft] = useState<WeeklyOpeningHours>(weeklyHours || DEFAULT_WEEKLY_HOURS);
  const [savingHours, setSavingHours] = useState(false);
  const [hoursFeedback, setHoursFeedback] = useState<string | null>(null);
  const [hoursError, setHoursError] = useState<string | null>(null);

  // Staff Shift Notes state (Firestore /staffNotes)
  const [notes, setNotes] = useState<StaffShiftNote[]>([]);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');
  const [noteCategory, setNoteCategory] = useState<StaffNoteCategory>('reservation');
  const [savingNote, setSavingNote] = useState(false);
  const [noteError, setNoteError] = useState<string | null>(null);

  // Managers state (Owner-only Firestore /managers)
  const [managers, setManagers] = useState<ManagerRecord[]>([]);
  const [managerEmail, setManagerEmail] = useState('');
  const [managerName, setManagerName] = useState('');
  const [managerShiftNote, setManagerShiftNote] = useState('');
  const [savingManager, setSavingManager] = useState(false);
  const [managerFeedback, setManagerFeedback] = useState<string | null>(null);
  const [managerError, setManagerError] = useState<string | null>(null);

  useEffect(() => {
    setAcceptingOrders(operations.acceptingOrders);
    setPrepTimeMinutes(operations.prepTimeMinutes);
    setDailySpecialNotice(operations.dailySpecialNotice);
    setUnavailableItemIds(operations.unavailableItemIds);
  }, [operations]);

  useEffect(() => {
    setHoursDraft(weeklyHours);
  }, [weeklyHours]);

  // Reset tab if manager opens console while managers tab was selected
  useEffect(() => {
    if (staffRole === 'manager' && activeTab === 'managers') {
      setActiveTab('orders');
    }
  }, [staffRole, activeTab]);

  const fetchStaffOrders = useCallback(async () => {
    if (!firebaseUser || (staffRole !== 'owner' && staffRole !== 'manager')) return;
    setLoadingOrders(true);
    setOrdersError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.getStaffOrders(idToken);
      setStaffOrders(res.orders);
      setDeletedStaffOrders(res.deletedOrders || []);
      setSummary(res.summary);
    } catch (err) {
      setOrdersError(err instanceof Error ? err.message : 'Unable to load cafe orders.');
    } finally {
      setLoadingOrders(false);
    }
  }, [firebaseUser, staffRole]);

  const fetchStaffBookings = useCallback(async () => {
    if (!firebaseUser || (staffRole !== 'owner' && staffRole !== 'manager')) return;
    setLoadingBookings(true);
    setBookingsError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.getStaffBookings(idToken);
      setStaffBookings(res.bookings);
      setBookingsSummary(res.summary);
      setBookingsTodayIso(res.today);
      setTotalTablesDraft(res.summary.totalTables);
    } catch (err) {
      setBookingsError(err instanceof Error ? err.message : 'Unable to load table bookings.');
    } finally {
      setLoadingBookings(false);
    }
  }, [firebaseUser, staffRole]);

  useEffect(() => {
    if (!open || !authReady) return;
    if (staffRole === 'owner' || staffRole === 'manager') {
      void fetchStaffOrders();
      void fetchStaffBookings();
    }
  }, [open, authReady, staffRole, fetchStaffOrders, fetchStaffBookings]);

  // Firestore listener for Owner-only /managers roster
  useEffect(() => {
    if (!open || !authReady || staffRole !== 'owner') {
      setManagers([]);
      return;
    }
    const q = query(collection(db, 'managers'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: ManagerRecord[] = snapshot.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            email: String(d.email || ''),
            name: String(d.name || ''),
            role: 'manager',
            status: d.status === 'revoked' ? 'revoked' : 'active',
            shiftNote: String(d.shiftNote || ''),
            appointedByEmail: String(d.appointedByEmail || ''),
            appointedByUid: String(d.appointedByUid || ''),
            createdAt: formatTimestamp(d.createdAt),
            updatedAt: formatTimestamp(d.updatedAt),
          };
        });
        setManagers(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'managers');
      }
    );
    return () => unsubscribe();
  }, [open, authReady, staffRole]);

  // Firestore listener for /staffNotes (Owner + Active Manager)
  useEffect(() => {
    if (!open || !authReady || (staffRole !== 'owner' && staffRole !== 'manager')) {
      setNotes([]);
      return;
    }
    const q = query(collection(db, 'staffNotes'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: StaffShiftNote[] = snapshot.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            title: String(d.title || ''),
            body: String(d.body || ''),
            category: (d.category as StaffNoteCategory) || 'shift',
            status: d.status === 'resolved' ? 'resolved' : 'open',
            authorUid: String(d.authorUid || ''),
            authorEmail: String(d.authorEmail || ''),
            authorRole: d.authorRole === 'owner' ? 'owner' : 'manager',
            createdAt: formatTimestamp(d.createdAt),
            updatedAt: formatTimestamp(d.updatedAt),
          };
        });
        setNotes(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'staffNotes');
      }
    );
    return () => unsubscribe();
  }, [open, authReady, staffRole]);

  if (!open) return null;

  async function handleGoogleSignIn() {
    setAuthError(null);
    setSigningIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Google sign-in was cancelled.');
    } finally {
      setSigningIn(false);
    }
  }

  async function handleSignOut() {
    setAuthError(null);
    await signOut(auth);
  }

  async function handleUpdateKitchenStatus(orderId: string, kitchenStatus: KitchenStatus) {
    if (!firebaseUser) return;
    setBusyOrderId(orderId);
    setOrdersError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.updateKitchenStatus(idToken, orderId, kitchenStatus);
      setStaffOrders((prev) => prev.map((o) => (o.id === orderId ? res.order : o)));
    } catch (err) {
      setOrdersError(err instanceof Error ? err.message : 'Could not update kitchen status.');
    } finally {
      setBusyOrderId(null);
    }
  }

  async function handleStaffConfirmUtr(order: CafeOrder) {
    if (!firebaseUser) return;
    const cleaned = (utrDrafts[order.id] || '').replace(/\D/g, '').slice(0, 12);
    if (cleaned.length !== 12) {
      setOrdersError('Enter a valid 12-digit UPI UTR number to confirm this order.');
      return;
    }
    setBusyOrderId(order.id);
    setOrdersError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const gateway = gatewayDrafts[order.id] || order.gateway;
      const res = await cafeApi.staffConfirmUtr(idToken, order.id, gateway, cleaned);
      setStaffOrders((prev) => prev.map((o) => (o.id === order.id ? res.order : o)));
      setUtrDrafts((prev) => ({ ...prev, [order.id]: '' }));
      void fetchStaffOrders();
    } catch (err) {
      setOrdersError(err instanceof Error ? err.message : 'Could not confirm UTR.');
    } finally {
      setBusyOrderId(null);
    }
  }

  async function handleStaffDeleteOrder(order: CafeOrder) {
    if (!firebaseUser) return;
    setBusyOrderId(order.id);
    setOrdersError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.staffDeleteOrder(idToken, order.id);
      setConfirmDeleteOrderId(null);
      setLastDeletedStaffOrder(res.deletedOrder);
      await fetchStaffOrders();
      onStaffOrdersMutated?.();
    } catch (err) {
      setOrdersError(err instanceof Error ? err.message : 'Could not delete order.');
    } finally {
      setBusyOrderId(null);
    }
  }

  async function handleStaffRestoreOrder(orderId: string) {
    if (!firebaseUser) return;
    setBusyOrderId(orderId);
    setOrdersError(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      await cafeApi.staffRestoreOrder(idToken, orderId);
      if (lastDeletedStaffOrder?.id === orderId) {
        setLastDeletedStaffOrder(null);
      }
      await fetchStaffOrders();
      onStaffOrdersMutated?.();
    } catch (err) {
      setOrdersError(err instanceof Error ? err.message : 'Could not restore order.');
    } finally {
      setBusyOrderId(null);
    }
  }

  async function persistOperations(
    nextValues: {
      acceptingOrders: boolean;
      prepTimeMinutes: number;
      dailySpecialNotice: string;
      unavailableItemIds: string[];
    },
    successMessage: string,
    stockItemId?: string
  ) {
    if (!firebaseUser || (staffRole !== 'owner' && staffRole !== 'manager')) return;
    const boundedPrep = Math.min(120, Math.max(5, Math.round(Number(nextValues.prepTimeMinutes) || 15)));
    const boundedNotice = nextValues.dailySpecialNotice.trim().slice(0, 180);
    const boundedUnavailable = Array.from(new Set(nextValues.unavailableItemIds)).slice(0, 200);

    const nextOps: CafeOperationsSettings = {
      acceptingOrders: nextValues.acceptingOrders,
      prepTimeMinutes: boundedPrep,
      dailySpecialNotice: boundedNotice,
      unavailableItemIds: boundedUnavailable,
      updatedByUid: firebaseUser.uid,
      updatedByRole: staffRole,
    };

    // Immediately update UI state so the storefront blocks sold-out items right away
    setAcceptingOrders(nextOps.acceptingOrders);
    setPrepTimeMinutes(nextOps.prepTimeMinutes);
    setDailySpecialNotice(nextOps.dailySpecialNotice);
    setUnavailableItemIds(nextOps.unavailableItemIds);
    onOperationsSaved(nextOps);

    setOpsError(null);
    setOpsFeedback(null);
    if (stockItemId) {
      setBusyStockItemId(stockItemId);
    } else {
      setSavingOps(true);
    }

    const path = 'cafeSettings/operations';
    try {
      const idToken = await firebaseUser.getIdToken();
      await Promise.all([
        setDoc(doc(db, 'cafeSettings', 'operations'), {
          acceptingOrders: nextOps.acceptingOrders,
          prepTimeMinutes: nextOps.prepTimeMinutes,
          dailySpecialNotice: nextOps.dailySpecialNotice,
          unavailableItemIds: nextOps.unavailableItemIds,
          updatedByUid: firebaseUser.uid,
          updatedByRole: staffRole,
          updatedAt: serverTimestamp(),
        }),
        cafeApi.syncStaffOperations(idToken, {
          acceptingOrders: nextOps.acceptingOrders,
          prepTimeMinutes: nextOps.prepTimeMinutes,
          dailySpecialNotice: nextOps.dailySpecialNotice,
          unavailableItemIds: nextOps.unavailableItemIds,
        }),
      ]);
      setOpsFeedback(successMessage);
    } catch (error) {
      console.error('Failed to persist cafe operations:', error);
      // Revert local state to last known synced operations
      setAcceptingOrders(operations.acceptingOrders);
      setPrepTimeMinutes(operations.prepTimeMinutes);
      setDailySpecialNotice(operations.dailySpecialNotice);
      setUnavailableItemIds(operations.unavailableItemIds);
      onOperationsSaved(operations);
      setOpsError(
        error instanceof Error
          ? `Could not publish change (${path}): ${error.message}`
          : 'Could not publish cafe settings. Check your permissions and try again.'
      );
    } finally {
      setSavingOps(false);
      setBusyStockItemId(null);
    }
  }

  function toggleUnavailableItem(itemId: string, itemName: string) {
    const currentlySoldOut = unavailableItemIds.includes(itemId);
    const nextUnavailable = currentlySoldOut
      ? unavailableItemIds.filter((id) => id !== itemId)
      : [...unavailableItemIds, itemId].slice(0, 200);

    void persistOperations(
      {
        acceptingOrders,
        prepTimeMinutes,
        dailySpecialNotice,
        unavailableItemIds: nextUnavailable,
      },
      currentlySoldOut
        ? `${itemName} marked Available and live on menu.`
        : `${itemName} marked Sold Out — blocked from ordering immediately.`,
      itemId
    );
  }

  function handleToggleAcceptingOrders(checked: boolean) {
    void persistOperations(
      {
        acceptingOrders: checked,
        prepTimeMinutes,
        dailySpecialNotice,
        unavailableItemIds,
      },
      checked
        ? 'Cafe is now accepting new orders.'
        : 'Cafe ordering paused immediately across storefront and server.'
    );
  }

  function handleMarkAllAvailable() {
    if (unavailableItemIds.length === 0) return;
    void persistOperations(
      {
        acceptingOrders,
        prepTimeMinutes,
        dailySpecialNotice,
        unavailableItemIds: [],
      },
      'All menu items marked Available.'
    );
  }

  async function handleSaveOperations(e: FormEvent) {
    e.preventDefault();
    await persistOperations(
      {
        acceptingOrders,
        prepTimeMinutes,
        dailySpecialNotice,
        unavailableItemIds,
      },
      'Prep time & live notice saved and published to storefront.'
    );
  }

  function handleUpdateDayHours(
    dayKey: DayOfWeekKey,
    patch: Partial<{ isOpen: boolean; openTime: string; closeTime: string }>
  ) {
    setHoursDraft((prev) => ({
      ...prev,
      [dayKey]: {
        ...prev[dayKey],
        ...patch,
      },
    }));
  }

  function handleApplyMondayToAll() {
    const mon = hoursDraft.monday;
    const next = {} as WeeklyOpeningHours;
    for (const day of DAY_ORDER) {
      next[day] = { ...mon };
    }
    setHoursDraft(next);
    setHoursFeedback('Copied Monday hours across all 7 days — click Save Weekly Hours to publish.');
    setHoursError(null);
  }

  async function handleSaveWeeklyHours(e: FormEvent) {
    e.preventDefault();
    if (!firebaseUser || (staffRole !== 'owner' && staffRole !== 'manager')) return;
    setSavingHours(true);
    setHoursError(null);
    setHoursFeedback(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.updateStaffHours(idToken, hoursDraft);
      setHoursDraft(res.weeklyHours);
      onHoursSaved(res.weeklyHours, res.openStatus);
      onStaffBookingsMutated?.();
      setHoursFeedback(
        'Weekly opening hours saved. Storefront ordering & table booking slots updated immediately.'
      );
    } catch (err) {
      setHoursError(err instanceof Error ? err.message : 'Unable to save weekly opening hours.');
    } finally {
      setSavingHours(false);
    }
  }

  async function handleUpdateBookingStatus(bookingId: string, status: TableBookingStatus) {
    if (!firebaseUser) return;
    setBusyBookingId(bookingId);
    setBookingsError(null);
    setBookingsFeedback(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      await cafeApi.updateStaffBookingStatus(idToken, bookingId, status);
      await fetchStaffBookings();
      onStaffBookingsMutated?.();
      setBookingsFeedback(`Booking ${bookingId} updated to ${status}.`);
    } catch (err) {
      setBookingsError(err instanceof Error ? err.message : 'Could not update booking status.');
    } finally {
      setBusyBookingId(null);
    }
  }

  async function handleDeleteBooking(bookingId: string) {
    if (!firebaseUser) return;
    setBusyBookingId(bookingId);
    setBookingsError(null);
    setBookingsFeedback(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      await cafeApi.deleteStaffBooking(idToken, bookingId);
      setConfirmDeleteBookingId(null);
      await fetchStaffBookings();
      onStaffBookingsMutated?.();
      setBookingsFeedback(`Booking ${bookingId} removed.`);
    } catch (err) {
      setBookingsError(err instanceof Error ? err.message : 'Could not delete booking.');
    } finally {
      setBusyBookingId(null);
    }
  }

  async function handleSaveTableConfig(e: FormEvent) {
    e.preventDefault();
    if (!firebaseUser) return;
    setSavingTableConfig(true);
    setBookingsError(null);
    setBookingsFeedback(null);
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await cafeApi.updateTableConfig(idToken, totalTablesDraft);
      setBookingsSummary((prev) => ({ ...prev, totalTables: res.totalTables }));
      onStaffBookingsMutated?.();
      setBookingsFeedback(`Garden capacity updated to ${res.totalTables} tables per time slot.`);
    } catch (err) {
      setBookingsError(err instanceof Error ? err.message : 'Could not update table limit.');
    } finally {
      setSavingTableConfig(false);
    }
  }

  async function handleCreateStaffNote(e: FormEvent) {
    e.preventDefault();
    if (!firebaseUser || (staffRole !== 'owner' && staffRole !== 'manager')) return;
    const cleanTitle = noteTitle.trim().slice(0, 120);
    const cleanBody = noteBody.trim().slice(0, 500);
    if (!cleanTitle || !cleanBody) {
      setNoteError('Enter both a title and note details.');
      return;
    }

    setSavingNote(true);
    setNoteError(null);
    const noteId = `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const path = `staffNotes/${noteId}`;
    try {
      await setDoc(doc(db, 'staffNotes', noteId), {
        title: cleanTitle,
        body: cleanBody,
        category: noteCategory,
        status: 'open',
        authorUid: firebaseUser.uid,
        authorEmail: normalizeEmail(firebaseUser.email || ''),
        authorRole: staffRole,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setNoteTitle('');
      setNoteBody('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    } finally {
      setSavingNote(false);
    }
  }

  async function handleToggleNoteStatus(note: StaffShiftNote) {
    if (staffRole !== 'owner' && staffRole !== 'manager') return;
    if (note.status === 'resolved' && staffRole !== 'owner') return;
    const nextStatus = note.status === 'open' ? 'resolved' : 'open';
    const path = `staffNotes/${note.id}`;
    try {
      await updateDoc(doc(db, 'staffNotes', note.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  async function handleDeleteNote(noteId: string) {
    if (staffRole !== 'owner') return;
    const path = `staffNotes/${noteId}`;
    try {
      await deleteDoc(doc(db, 'staffNotes', noteId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  async function handleAppointManager(e: FormEvent) {
    e.preventDefault();
    if (!firebaseUser || staffRole !== 'owner') return;
    setManagerError(null);
    setManagerFeedback(null);

    const normalized = normalizeEmail(managerEmail);
    const cleanName = managerName.trim().slice(0, 80);
    const cleanShift = managerShiftNote.trim().slice(0, 180);

    const currentOwnerEmail = normalizeEmail(firebaseUser.email || '');
    if (!EMAIL_PATTERN.test(normalized) || normalized.length > 120) {
      setManagerError('Enter a valid manager email address.');
      return;
    }
    if (normalized === currentOwnerEmail) {
      setManagerError('Your owner account already has full cafe owner access.');
      return;
    }
    if (!cleanName) {
      setManagerError('Enter the manager’s name.');
      return;
    }

    const docId = emailToManagerId(normalized);
    const existingManager = managers.find((m) => m.id === docId);
    const path = `managers/${docId}`;
    setSavingManager(true);
    try {
      if (existingManager) {
        await updateDoc(doc(db, 'managers', docId), {
          name: cleanName,
          shiftNote: cleanShift,
          status: 'active',
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(doc(db, 'managers', docId), {
          email: normalized,
          name: cleanName,
          role: 'manager',
          status: 'active',
          shiftNote: cleanShift,
          appointedByEmail: currentOwnerEmail,
          appointedByUid: firebaseUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      setManagerEmail('');
      setManagerName('');
      setManagerShiftNote('');
      setManagerFeedback(
        existingManager
          ? `Updated & reactivated manager access for ${cleanName} (${normalized}).`
          : `${cleanName} (${normalized}) appointed as active manager.`
      );
    } catch (error) {
      handleFirestoreError(
        error,
        existingManager ? OperationType.UPDATE : OperationType.CREATE,
        path
      );
    } finally {
      setSavingManager(false);
    }
  }

  async function handleToggleManagerStatus(mgr: ManagerRecord) {
    if (staffRole !== 'owner') return;
    const nextStatus = mgr.status === 'active' ? 'revoked' : 'active';
    const path = `managers/${mgr.id}`;
    try {
      await updateDoc(doc(db, 'managers', mgr.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      setManagerFeedback(
        nextStatus === 'active'
          ? `Reactivated manager access for ${mgr.email}.`
          : `Paused manager access for ${mgr.email}.`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  async function handleRemoveManager(mgr: ManagerRecord) {
    if (staffRole !== 'owner') return;
    const path = `managers/${mgr.id}`;
    try {
      await deleteDoc(doc(db, 'managers', mgr.id));
      setManagerFeedback(`Removed ${mgr.email} from managers.`);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  const isAuthorizedStaff = staffRole === 'owner' || staffRole === 'manager';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="staff-console-title"
      className="fixed inset-0 z-50 flex justify-end bg-[#1D1815]/60 backdrop-blur-xs"
    >
      <div className="flex h-full w-full max-w-3xl flex-col bg-[#FAF8F5] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1D1815]/10 px-6 py-5">
          <div>
            <h2
              id="staff-console-title"
              className="font-display text-xl font-medium text-[#1D1815]"
            >
              {staffRole === 'owner'
                ? 'Owner Console'
                : staffRole === 'manager'
                  ? 'Manager Console'
                  : 'Owner & Manager Access'}
            </h2>
            <p className="mt-0.5 text-xs text-[#6A5E55]">
              {staffRole === 'owner' && 'Verified Cafe Owner · Full Access'}
              {staffRole === 'manager' && 'Appointed Manager · Near-Owner Access'}
              {!isAuthorizedStaff && 'Restricted to Verified Cafe Owner and Appointed Managers'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {firebaseUser && (
              <button
                type="button"
                onClick={handleSignOut}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-[#1D1815]/15 px-3 py-1.5 text-xs font-medium text-[#5A5048] hover:border-[#1D1815]/30 hover:text-[#1D1815]"
              >
                <LogOut className="h-3.5 w-3.5" />
                Sign Out
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close staff console"
              className="flex h-10 w-10 items-center justify-center rounded-lg text-[#6A5E55] hover:bg-[#1D1815]/5 hover:text-[#1D1815]"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Gate 1: Not signed in */}
        {!firebaseUser && (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#EFEAE2] text-[#2A473A]">
              <Lock className="h-6 w-6" />
            </div>
            <h3 className="mt-5 font-display text-2xl font-medium text-[#1D1815]">
              Authorized Cafe Staff Only
            </h3>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-[#5A5048]">
              Sign in with Google to enter IMMY's Coffee Cafe management console. Only the verified
              cafe owner or managers explicitly appointed by the owner are permitted.
            </p>
            {authError && (
              <div
                role="alert"
                className="mt-4 max-w-md rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
              >
                {authError}
              </div>
            )}
            <button
              type="button"
              disabled={signingIn || !authReady}
              onClick={handleGoogleSignIn}
              className="mt-6 inline-flex min-h-[46px] items-center justify-center gap-2 rounded-lg bg-[#2A473A] px-6 py-2.5 text-sm font-medium text-[#FAF8F5] transition-colors hover:bg-[#1F372C] disabled:opacity-60"
            >
              <ShieldCheck className="h-4 w-4" />
              {signingIn ? 'Verifying Google account...' : 'Sign In with Google'}
            </button>
          </div>
        )}

        {/* Gate 2: Signed in, but NOT Owner and NOT Active Appointed Manager */}
        {firebaseUser && staffRole === 'unauthorized' && (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#9A4B38]/12 text-[#7A3222]">
              <ShieldAlert className="h-6 w-6" />
            </div>
            <h3 className="mt-5 font-display text-2xl font-medium text-[#1D1815]">
              Access Denied
            </h3>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-[#5A5048]">
              The signed-in Google account is not authorized for IMMY's Coffee Cafe operations. Only
              the verified cafe owner or an active manager appointed by the owner can enter.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={handleSignOut}
                className="min-h-[42px] rounded-lg bg-[#2A473A] px-5 py-2 text-sm font-medium text-[#FAF8F5] hover:bg-[#1F372C]"
              >
                Sign Out & Switch Account
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[42px] rounded-lg border border-[#1D1815]/20 px-5 py-2 text-sm font-medium text-[#1D1815] hover:bg-[#1D1815]/5"
              >
                Return to Storefront
              </button>
            </div>
          </div>
        )}

        {/* Gate 3: Verified Owner or Active Manager */}
        {firebaseUser && isAuthorizedStaff && (
          <>
            {/* Navigation Tabs */}
            <div className="border-b border-[#1D1815]/10 px-6 py-3">
              <div className="flex flex-wrap gap-1 rounded-lg bg-[#EFEAE2] p-1">
                <button
                  type="button"
                  onClick={() => setActiveTab('orders')}
                  className={`inline-flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors ${
                    activeTab === 'orders'
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  <ClipboardList className="h-3.5 w-3.5" />
                  Orders
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('bookings')}
                  className={`inline-flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors ${
                    activeTab === 'bookings'
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  <Calendar className="h-3.5 w-3.5" />
                  Tables ({bookingsSummary.confirmedCount + bookingsSummary.seatedCount})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('operations')}
                  className={`inline-flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors ${
                    activeTab === 'operations'
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  <Sliders className="h-3.5 w-3.5" />
                  Cafe & Menu
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('notes')}
                  className={`inline-flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors ${
                    activeTab === 'notes'
                      ? 'bg-white text-[#1D1815] shadow-xs'
                      : 'text-[#5A5048] hover:text-[#1D1815]'
                  }`}
                >
                  <Clock className="h-3.5 w-3.5" />
                  Shift Notes
                </button>
                {staffRole === 'owner' && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('managers')}
                    className={`inline-flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors ${
                      activeTab === 'managers'
                        ? 'bg-white text-[#1D1815] shadow-xs'
                        : 'text-[#5A5048] hover:text-[#1D1815]'
                    }`}
                  >
                    <Users className="h-3.5 w-3.5" />
                    Managers ({managers.filter((m) => m.status === 'active').length})
                  </button>
                )}
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto px-6 py-5">
              {/* TAB 1: LIVE ORDERS & UTR LEDGER */}
              {activeTab === 'orders' && (
                <div className="space-y-5">
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                      <p className="text-xs text-[#6A5E55]">Total Orders</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-[#1D1815] tabular-nums">
                        {summary.totalOrders}
                      </p>
                    </div>
                    <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                      <p className="text-xs text-[#6A5E55]">UTR Confirmed</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-[#2A473A] tabular-nums">
                        {summary.confirmedCount}
                      </p>
                    </div>
                    <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                      <p className="text-xs text-[#6A5E55]">Pending UTR</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-[#9A5B25] tabular-nums">
                        {summary.pendingCount}
                      </p>
                    </div>
                    <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                      <p className="text-xs text-[#6A5E55]">Verified Revenue</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-[#1D1815] tabular-nums">
                        ₹{summary.verifiedRevenue}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-[#1D1815]">
                      All Incoming Cafe Orders
                    </h3>
                    <button
                      type="button"
                      onClick={() => void fetchStaffOrders()}
                      disabled={loadingOrders}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-[#2A473A] hover:underline"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 ${loadingOrders ? 'animate-spin' : ''}`} />
                      Refresh Ledger
                    </button>
                  </div>

                  {ordersError && (
                    <div
                      role="alert"
                      className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                    >
                      {ordersError}
                    </div>
                  )}

                  {lastDeletedStaffOrder && (
                    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-3 text-sm text-[#1F372C]">
                      <span>
                        Deleted order{' '}
                        <span className="font-mono font-semibold">{lastDeletedStaffOrder.id}</span>{' '}
                        (₹{lastDeletedStaffOrder.total}).
                      </span>
                      <button
                        type="button"
                        disabled={busyOrderId === lastDeletedStaffOrder.id}
                        onClick={() => handleStaffRestoreOrder(lastDeletedStaffOrder.id)}
                        className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg bg-[#2A473A] px-3 py-1 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-55 whitespace-nowrap shrink-0"
                      >
                        <Undo2 className="h-3.5 w-3.5" />
                        {busyOrderId === lastDeletedStaffOrder.id ? 'Restoring...' : 'Undo Delete'}
                      </button>
                    </div>
                  )}

                  {staffOrders.length === 0 ? (
                    <div className="rounded-xl border border-[#1D1815]/10 bg-white p-10 text-center text-sm text-[#6A5E55]">
                      No active cafe orders right now. New customer orders will appear here live.
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {staffOrders.map((order) => {
                        const isPaid = order.paymentStatus === 'PAID_VERIFIED';
                        const draftUtr = (utrDrafts[order.id] || '').replace(/\D/g, '').slice(0, 12);
                        const draftGw = gatewayDrafts[order.id] || order.gateway;
                        return (
                          <div
                            key={order.id}
                            className="rounded-xl border border-[#1D1815]/12 bg-white p-5"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#1D1815]/8 pb-3">
                              <div>
                                <div className="flex flex-wrap items-center gap-2 text-xs text-[#6A5E55]">
                                  <span className="font-mono font-semibold text-[#1D1815]">
                                    {order.id}
                                  </span>
                                  <span aria-hidden="true">·</span>
                                  <span>{order.customerName}</span>
                                  {order.customerPhone && (
                                    <>
                                      <span aria-hidden="true">·</span>
                                      <span className="font-mono">{order.customerPhone}</span>
                                    </>
                                  )}
                                  <span aria-hidden="true">·</span>
                                  <span className="capitalize">{order.diningMode}</span>
                                </div>
                                <div className="mt-1.5 flex items-center gap-1.5 text-xs font-medium">
                                  {isPaid ? (
                                    <>
                                      <CheckCircle2 className="h-4 w-4 text-[#2A473A]" />
                                      <span className="text-[#2A473A]">
                                        UTR {order.upiRefUtr} Confirmed ({order.gateway})
                                      </span>
                                    </>
                                  ) : (
                                    <>
                                      <Clock className="h-4 w-4 text-[#9A5B25]" />
                                      <span className="text-[#9A5B25]">Pending UTR Confirmation</span>
                                    </>
                                  )}
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-mono text-base font-semibold text-[#1D1815] tabular-nums">
                                  ₹{order.total}
                                </p>
                                <p className="text-xs text-[#6A5E55]">
                                  {formatTimestamp(order.createdAt)}
                                </p>
                              </div>
                            </div>

                            <ul className="mt-3 space-y-1 text-sm text-[#3B332E]">
                              {order.items.map((item) => (
                                <li key={item.itemId} className="flex justify-between gap-2">
                                  <span>
                                    {item.quantity} × {item.name}
                                  </span>
                                  <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                                    ₹{item.lineTotal}
                                  </span>
                                </li>
                              ))}
                            </ul>

                            {order.tableOrNotes && (
                              <p className="mt-2 text-xs text-[#5A5048]">
                                Note: {order.tableOrNotes}
                              </p>
                            )}

                            {/* Kitchen Status Control & Owner/Manager Delete Action */}
                            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#1D1815]/8 pt-3">
                              <span className="text-xs font-medium text-[#6A5E55]">
                                Kitchen Stage
                              </span>
                              <div className="flex flex-wrap items-center gap-1.5">
                                {(['received', 'preparing', 'ready', 'completed'] as KitchenStatus[]).map(
                                  (stage) => (
                                    <button
                                      key={stage}
                                      type="button"
                                      disabled={busyOrderId === order.id}
                                      onClick={() => handleUpdateKitchenStatus(order.id, stage)}
                                      className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors ${
                                        order.kitchenStatus === stage
                                          ? 'bg-[#2A473A] text-[#FAF8F5]'
                                          : 'bg-[#F4F0EA] text-[#5A5048] hover:text-[#1D1815]'
                                      }`}
                                    >
                                      {stage}
                                    </button>
                                  )
                                )}
                              </div>
                            </div>

                            {/* Counter UTR Confirmation for pending orders */}
                            {!isPaid && (
                              <div className="mt-3 flex flex-col gap-2 border-t border-[#1D1815]/8 pt-3 sm:flex-row">
                                <select
                                  value={draftGw}
                                  onChange={(e) =>
                                    setGatewayDrafts((prev) => ({
                                      ...prev,
                                      [order.id]: e.target.value as PaymentGateway,
                                    }))
                                  }
                                  aria-label="Gateway choice"
                                  className="rounded-lg border border-[#1D1815]/15 bg-white px-2.5 py-2 text-xs text-[#1D1815]"
                                >
                                  <option value="razorpay">Razorpay</option>
                                  <option value="cashfree">Cashfree</option>
                                </select>
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  maxLength={12}
                                  value={draftUtr}
                                  onChange={(e) =>
                                    setUtrDrafts((prev) => ({
                                      ...prev,
                                      [order.id]: e.target.value.replace(/\D/g, '').slice(0, 12),
                                    }))
                                  }
                                  placeholder="Enter 12-digit UTR to confirm"
                                  className="flex-1 rounded-lg border border-[#1D1815]/15 px-3 py-2 font-mono text-xs text-[#1D1815] outline-none focus:border-[#2A473A]"
                                />
                                <button
                                  type="button"
                                  disabled={busyOrderId === order.id || draftUtr.length !== 12}
                                  onClick={() => handleStaffConfirmUtr(order)}
                                  className="min-h-[36px] rounded-lg bg-[#2A473A] px-3.5 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-50 whitespace-nowrap shrink-0"
                                >
                                  Confirm UTR
                                </button>
                              </div>
                            )}

                            {/* Owner / Manager Delete Order Control */}
                            <div className="mt-3 flex flex-wrap items-center justify-end gap-2 border-t border-[#1D1815]/8 pt-3">
                              {confirmDeleteOrderId === order.id ? (
                                <>
                                  <span className="mr-auto text-xs font-medium text-[#7A3222]">
                                    Delete order {order.id} from active ledger?
                                  </span>
                                  <button
                                    type="button"
                                    disabled={busyOrderId === order.id}
                                    onClick={() => handleStaffDeleteOrder(order)}
                                    className="rounded-md bg-[#7A3222] px-3 py-1.5 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518] disabled:opacity-50"
                                  >
                                    {busyOrderId === order.id ? 'Deleting...' : 'Confirm Delete'}
                                  </button>
                                  <button
                                    type="button"
                                    disabled={busyOrderId === order.id}
                                    onClick={() => setConfirmDeleteOrderId(null)}
                                    className="rounded-md border border-[#1D1815]/15 px-3 py-1.5 text-xs font-medium text-[#5A5048] hover:text-[#1D1815]"
                                  >
                                    Cancel
                                  </button>
                                </>
                              ) : (
                                <button
                                  type="button"
                                  disabled={busyOrderId === order.id}
                                  onClick={() => setConfirmDeleteOrderId(order.id)}
                                  className="inline-flex items-center gap-1.5 rounded-md border border-[#9A4B38]/30 px-3 py-1.5 text-xs font-medium text-[#7A3222] hover:bg-[#9A4B38]/8"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  Delete Order
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Recently Deleted Orders Archive — Owner & Manager One-Click Undo */}
                  {deletedStaffOrders.length > 0 && (
                    <div className="border-t border-[#1D1815]/12 pt-5">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-semibold tracking-wide text-[#6A5E55] uppercase">
                          Recently Deleted Orders ({deletedStaffOrders.length})
                        </h4>
                        <span className="text-xs text-[#6A5E55]">
                          Undo to restore into active ledger
                        </span>
                      </div>
                      <div className="mt-3 space-y-2.5">
                        {deletedStaffOrders.map((order) => (
                          <div
                            key={order.id}
                            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-dashed border-[#1D1815]/20 bg-[#F4F0EA]/70 p-4"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2 text-xs text-[#5A5048]">
                                <span className="font-mono font-semibold text-[#1D1815]">
                                  {order.id}
                                </span>
                                <span aria-hidden="true">·</span>
                                <span>{order.customerName}</span>
                                <span aria-hidden="true">·</span>
                                <span className="font-mono tabular-nums">₹{order.total}</span>
                                {order.deletedBy && (
                                  <>
                                    <span aria-hidden="true">·</span>
                                    <span>Deleted by {order.deletedBy}</span>
                                  </>
                                )}
                              </div>
                              <p className="mt-1 truncate text-xs text-[#6A5E55]">
                                {order.items.map((i) => `${i.quantity}× ${i.name}`).join(', ')}
                              </p>
                            </div>
                            <button
                              type="button"
                              disabled={busyOrderId === order.id}
                              onClick={() => handleStaffRestoreOrder(order.id)}
                              className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-[#2A473A] bg-white px-3 py-1 text-xs font-medium text-[#2A473A] hover:bg-[#2A473A] hover:text-[#FAF8F5] disabled:opacity-50 whitespace-nowrap shrink-0"
                            >
                              <Undo2 className="h-3.5 w-3.5" />
                              {busyOrderId === order.id ? 'Restoring...' : 'Undo / Restore'}
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: GARDEN TABLE BOOKINGS (Owner + Manager) */}
              {activeTab === 'bookings' && (() => {
                const filteredBookings = staffBookings.filter((b) => {
                  if (bookingStatusFilter !== 'all' && b.status !== bookingStatusFilter) {
                    return false;
                  }
                  if (bookingDateScope === 'today' && bookingsTodayIso && b.bookingDate !== bookingsTodayIso) {
                    return false;
                  }
                  return true;
                });

                return (
                  <div className="space-y-5">
                    {/* Summary KPI strip */}
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                        <p className="text-xs text-[#6A5E55]">Today Active</p>
                        <p className="mt-1 font-mono text-xl font-semibold text-[#1D1815] tabular-nums">
                          {bookingsSummary.todayCount}
                        </p>
                      </div>
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                        <p className="text-xs text-[#6A5E55]">Confirmed</p>
                        <p className="mt-1 font-mono text-xl font-semibold text-[#2A473A] tabular-nums">
                          {bookingsSummary.confirmedCount}
                        </p>
                      </div>
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                        <p className="text-xs text-[#6A5E55]">Seated Now</p>
                        <p className="mt-1 font-mono text-xl font-semibold text-[#9A5B25] tabular-nums">
                          {bookingsSummary.seatedCount}
                        </p>
                      </div>
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-4">
                        <p className="text-xs text-[#6A5E55]">Upcoming Guests</p>
                        <p className="mt-1 font-mono text-xl font-semibold text-[#1D1815] tabular-nums">
                          {bookingsSummary.totalUpcomingGuests}
                        </p>
                      </div>
                    </div>

                    {/* Limited Garden Table Capacity Control */}
                    <form
                      onSubmit={handleSaveTableConfig}
                      className="flex flex-wrap items-end justify-between gap-4 rounded-xl border border-[#1D1815]/12 bg-white p-4"
                    >
                      <div className="min-w-0 flex-1">
                        <label
                          htmlFor="staff-total-tables"
                          className="block text-sm font-semibold text-[#1D1815]"
                        >
                          Limited Garden Tables Capacity (Per Time Slot)
                        </label>
                        <p className="mt-0.5 text-xs text-[#6A5E55]">
                          Controls how many open-air tables guests can reserve in each time slot
                          (1–40 tables).
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          id="staff-total-tables"
                          type="number"
                          min={1}
                          max={40}
                          value={totalTablesDraft}
                          onChange={(e) => setTotalTablesDraft(Number(e.target.value))}
                          className="w-20 rounded-lg border border-[#1D1815]/15 bg-[#FAF8F5] px-3 py-2 font-mono text-sm text-[#1D1815] tabular-nums"
                        />
                        <button
                          type="submit"
                          disabled={savingTableConfig}
                          className="min-h-[38px] rounded-lg bg-[#2A473A] px-4 py-2 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-55 whitespace-nowrap shrink-0"
                        >
                          {savingTableConfig ? 'Saving...' : 'Update Limit'}
                        </button>
                      </div>
                    </form>

                    {/* Filters & Refresh */}
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <div className="inline-flex rounded-lg bg-[#EFEAE2] p-0.5 text-xs">
                          <button
                            type="button"
                            onClick={() => setBookingDateScope('all')}
                            className={`rounded-md px-2.5 py-1 font-medium transition-colors ${
                              bookingDateScope === 'all'
                                ? 'bg-white text-[#1D1815] shadow-xs'
                                : 'text-[#5A5048]'
                            }`}
                          >
                            All Dates
                          </button>
                          <button
                            type="button"
                            onClick={() => setBookingDateScope('today')}
                            className={`rounded-md px-2.5 py-1 font-medium transition-colors ${
                              bookingDateScope === 'today'
                                ? 'bg-white text-[#1D1815] shadow-xs'
                                : 'text-[#5A5048]'
                            }`}
                          >
                            Today
                          </button>
                        </div>

                        <select
                          aria-label="Filter booking status"
                          value={bookingStatusFilter}
                          onChange={(e) =>
                            setBookingStatusFilter(e.target.value as 'all' | TableBookingStatus)
                          }
                          className="rounded-lg border border-[#1D1815]/15 bg-white px-2.5 py-1.5 text-xs font-medium text-[#1D1815]"
                        >
                          <option value="all">All Statuses</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="seated">Seated</option>
                          <option value="completed">Completed</option>
                          <option value="no-show">No-Show</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>

                      <button
                        type="button"
                        onClick={() => void fetchStaffBookings()}
                        disabled={loadingBookings}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#2A473A] hover:underline"
                      >
                        <RefreshCw
                          className={`h-3.5 w-3.5 ${loadingBookings ? 'animate-spin' : ''}`}
                        />
                        Refresh Bookings
                      </button>
                    </div>

                    {bookingsError && (
                      <div
                        role="alert"
                        className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                      >
                        {bookingsError}
                      </div>
                    )}

                    {bookingsFeedback && (
                      <div className="rounded-lg border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-3 text-sm text-[#1F372C]">
                        {bookingsFeedback}
                      </div>
                    )}

                    {filteredBookings.length === 0 ? (
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-10 text-center text-sm text-[#6A5E55]">
                        No table bookings match this filter yet. New guest reservations will appear
                        here immediately.
                      </div>
                    ) : (
                      <div className="space-y-3.5">
                        {filteredBookings.map((booking) => (
                          <div
                            key={booking.id}
                            className="rounded-xl border border-[#1D1815]/12 bg-white p-5"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#1D1815]/8 pb-3">
                              <div>
                                <div className="flex flex-wrap items-center gap-2 text-xs text-[#6A5E55]">
                                  <span className="font-mono font-semibold text-[#1D1815]">
                                    {booking.id}
                                  </span>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-mono font-semibold text-[#2A473A]">
                                    {booking.bookingDate} · {booking.timeSlot}
                                  </span>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-medium text-[#1D1815]">
                                    {booking.tableNumbers.length === 1
                                      ? `Table #${booking.tableNumbers[0]}`
                                      : `Tables #${booking.tableNumbers.join(', #')}`}
                                  </span>
                                </div>

                                <div className="mt-1.5 flex flex-wrap items-center gap-3">
                                  <p className="text-base font-semibold text-[#1D1815]">
                                    {booking.guestName}
                                  </p>
                                  <a
                                    href={`tel:+91${booking.guestPhone}`}
                                    className="inline-flex items-center gap-1 font-mono text-xs font-semibold text-[#2A473A] hover:underline tabular-nums"
                                  >
                                    <Phone className="h-3 w-3" />
                                    {booking.guestPhone}
                                  </a>
                                </div>
                              </div>

                              <div className="text-right">
                                <p className="font-mono text-sm font-semibold text-[#1D1815] tabular-nums">
                                  {booking.partySize}{' '}
                                  {booking.partySize === 1 ? 'Guest' : 'Guests'}
                                </p>
                                <p className="text-xs capitalize text-[#6A5E55]">
                                  Status: <strong>{booking.status}</strong>
                                </p>
                              </div>
                            </div>

                            {booking.notes && (
                              <p className="mt-2.5 text-xs text-[#5A5048]">
                                Request: {booking.notes}
                              </p>
                            )}

                            {/* Status Controls */}
                            <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 border-t border-[#1D1815]/8 pt-3">
                              <div className="flex flex-wrap items-center gap-1.5">
                                {(
                                  [
                                    'confirmed',
                                    'seated',
                                    'completed',
                                    'no-show',
                                    'cancelled',
                                  ] as TableBookingStatus[]
                                ).map((st) => (
                                  <button
                                    key={st}
                                    type="button"
                                    disabled={busyBookingId === booking.id}
                                    onClick={() => handleUpdateBookingStatus(booking.id, st)}
                                    className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors ${
                                      booking.status === st
                                        ? st === 'cancelled' || st === 'no-show'
                                          ? 'bg-[#7A3222] text-[#FAF8F5]'
                                          : 'bg-[#2A473A] text-[#FAF8F5]'
                                        : 'bg-[#F4F0EA] text-[#5A5048] hover:text-[#1D1815]'
                                    }`}
                                  >
                                    {st}
                                  </button>
                                ))}
                              </div>

                              {confirmDeleteBookingId === booking.id ? (
                                <div className="flex items-center gap-1.5">
                                  <button
                                    type="button"
                                    disabled={busyBookingId === booking.id}
                                    onClick={() => handleDeleteBooking(booking.id)}
                                    className="rounded-md bg-[#7A3222] px-2.5 py-1 text-xs font-medium text-[#FAF8F5] hover:bg-[#612518]"
                                  >
                                    Confirm Delete
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setConfirmDeleteBookingId(null)}
                                    className="rounded-md border border-[#1D1815]/15 px-2.5 py-1 text-xs font-medium text-[#5A5048]"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  disabled={busyBookingId === booking.id}
                                  onClick={() => setConfirmDeleteBookingId(booking.id)}
                                  aria-label={`Delete booking ${booking.id}`}
                                  className="inline-flex items-center gap-1 rounded-md border border-[#9A4B38]/30 px-2.5 py-1 text-xs font-medium text-[#7A3222] hover:bg-[#9A4B38]/8"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  Delete
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* TAB 3: CAFE OPERATIONS & MENU AVAILABILITY (Owner + Manager) */}
              {activeTab === 'operations' && (() => {
                const queryStr = stockSearch.trim().toLowerCase();
                const filteredCategories = MENU_CATEGORIES.map((category) => {
                  const categoryMatches = queryStr
                    ? category.title.toLowerCase().includes(queryStr)
                    : false;
                  const matchingItems = category.items.filter((item) => {
                    const isSoldOut = unavailableItemIds.includes(item.id);
                    if (showSoldOutOnly && !isSoldOut) return false;
                    if (!queryStr) return true;
                    return categoryMatches || item.name.toLowerCase().includes(queryStr);
                  });
                  return { ...category, items: matchingItems };
                }).filter((category) => category.items.length > 0);

                return (
                  <div className="space-y-6">
                    {opsError && (
                      <div
                        role="alert"
                        className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
                      >
                        {opsError}
                      </div>
                    )}

                    {opsFeedback && (
                      <div className="rounded-lg border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-3 text-sm text-[#1F372C]">
                        {opsFeedback}
                      </div>
                    )}

                    <form
                      onSubmit={handleSaveOperations}
                      className="grid grid-cols-1 gap-4 rounded-xl border border-[#1D1815]/12 bg-white p-5 sm:grid-cols-2"
                    >
                      <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg bg-[#F4F0EA] p-4">
                        <div>
                          <span className="block text-sm font-semibold text-[#1D1815]">
                            Accepting Orders
                          </span>
                          <span className="text-xs text-[#5A5048]">
                            Saves instantly — pauses checkout & server
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={acceptingOrders}
                          disabled={savingOps}
                          onChange={(e) => handleToggleAcceptingOrders(e.target.checked)}
                          className="h-5 w-5 accent-[#2A473A]"
                        />
                      </label>

                      <div className="rounded-lg bg-[#F4F0EA] p-4">
                        <label
                          htmlFor="ops-prep-time"
                          className="block text-sm font-semibold text-[#1D1815]"
                        >
                          Est. Prep Time (Minutes)
                        </label>
                        <input
                          id="ops-prep-time"
                          type="number"
                          min={5}
                          max={120}
                          value={prepTimeMinutes}
                          onChange={(e) => setPrepTimeMinutes(Number(e.target.value))}
                          className="mt-1.5 w-full rounded-lg border border-[#1D1815]/15 bg-white px-3 py-1.5 font-mono text-sm text-[#1D1815]"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label
                          htmlFor="ops-special-notice"
                          className="block text-sm font-semibold text-[#1D1815]"
                        >
                          Live Storefront Notice / Daily Special (Max 180 chars)
                        </label>
                        <div className="mt-1.5 flex flex-col gap-2 sm:flex-row">
                          <input
                            id="ops-special-notice"
                            type="text"
                            maxLength={180}
                            value={dailySpecialNotice}
                            onChange={(e) => setDailySpecialNotice(e.target.value)}
                            placeholder="e.g. Evening acoustic lawn seating & fresh cold coffee specials"
                            className="flex-1 rounded-lg border border-[#1D1815]/15 bg-white px-3.5 py-2.5 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                          />
                          <button
                            type="submit"
                            disabled={savingOps}
                            className="min-h-[42px] rounded-lg bg-[#2A473A] px-5 py-2 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-60 whitespace-nowrap shrink-0"
                          >
                            {savingOps ? 'Saving...' : 'Save Prep & Notice'}
                          </button>
                        </div>
                      </div>
                    </form>

                    {/* Weekly Opening Hours Table Editor (Owner & Manager) */}
                    <form
                      onSubmit={handleSaveWeeklyHours}
                      className="rounded-xl border border-[#1D1815]/12 bg-white p-5"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="text-sm font-semibold text-[#1D1815]">
                            Weekly Opening Hours (IST)
                          </h3>
                          <p className="mt-1 text-xs text-[#6A5E55]">
                            Edit opening and closing times for each day. Ordering and table booking
                            are automatically disabled outside these hours.
                            {openStatus ? ` Currently ${openStatus.isOpenNow ? 'Open' : 'Closed'} (${openStatus.currentTimeIst} IST).` : ''}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={handleApplyMondayToAll}
                          className="rounded-lg border border-[#1D1815]/15 px-3 py-1.5 text-xs font-medium text-[#4E453E] hover:border-[#2A473A] hover:text-[#1D1815] whitespace-nowrap shrink-0"
                        >
                          Copy Monday to All Days
                        </button>
                      </div>

                      {hoursError && (
                        <div
                          role="alert"
                          className="mt-3 rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-3.5 py-2.5 text-xs text-[#7A3222]"
                        >
                          {hoursError}
                        </div>
                      )}
                      {hoursFeedback && (
                        <div className="mt-3 rounded-lg border border-[#2A473A]/25 bg-[#2A473A]/10 px-3.5 py-2.5 text-xs text-[#1F372C]">
                          {hoursFeedback}
                        </div>
                      )}

                      <div className="mt-4 overflow-x-auto">
                        <table className="w-full min-w-[440px] border-collapse text-left text-xs">
                          <thead>
                            <tr className="border-b border-[#1D1815]/10 text-[#6A5E55]">
                              <th className="py-2 pr-3 font-semibold">Day</th>
                              <th className="py-2 px-2 font-semibold">Open</th>
                              <th className="py-2 px-2 font-semibold">Opens (IST)</th>
                              <th className="py-2 pl-2 font-semibold">Closes (IST)</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#1D1815]/8">
                            {DAY_ORDER.map((dayKey) => {
                              const row = hoursDraft[dayKey] || DEFAULT_WEEKLY_HOURS[dayKey];
                              return (
                                <tr key={dayKey}>
                                  <td className="py-2.5 pr-3 font-medium text-[#1D1815]">
                                    {DAY_LABELS[dayKey]}
                                  </td>
                                  <td className="py-2.5 px-2">
                                    <label className="inline-flex cursor-pointer items-center gap-1.5">
                                      <input
                                        type="checkbox"
                                        checked={row.isOpen}
                                        onChange={(e) =>
                                          handleUpdateDayHours(dayKey, { isOpen: e.target.checked })
                                        }
                                        className="h-4 w-4 accent-[#2A473A]"
                                      />
                                      <span className={row.isOpen ? 'text-[#2A473A]' : 'text-[#7A3222]'}>
                                        {row.isOpen ? 'Open' : 'Closed'}
                                      </span>
                                    </label>
                                  </td>
                                  <td className="py-2.5 px-2">
                                    <input
                                      type="time"
                                      value={row.openTime}
                                      disabled={!row.isOpen}
                                      onChange={(e) =>
                                        handleUpdateDayHours(dayKey, { openTime: e.target.value })
                                      }
                                      className="rounded-md border border-[#1D1815]/15 bg-[#FAF8F5] px-2.5 py-1 font-mono text-xs text-[#1D1815] disabled:opacity-45"
                                    />
                                  </td>
                                  <td className="py-2.5 pl-2">
                                    <input
                                      type="time"
                                      value={row.closeTime}
                                      disabled={!row.isOpen}
                                      onChange={(e) =>
                                        handleUpdateDayHours(dayKey, { closeTime: e.target.value })
                                      }
                                      className="rounded-md border border-[#1D1815]/15 bg-[#FAF8F5] px-2.5 py-1 font-mono text-xs text-[#1D1815] disabled:opacity-45"
                                    />
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      <div className="mt-4 flex justify-end">
                        <button
                          type="submit"
                          disabled={savingHours}
                          className="min-h-[40px] rounded-lg bg-[#2A473A] px-5 py-2 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-60"
                        >
                          {savingHours ? 'Saving Weekly Hours...' : 'Save Weekly Hours'}
                        </button>
                      </div>
                    </form>

                    {/* Menu Item Stock Toggles (Instant Live Auto-Save) */}
                    <div className="rounded-xl border border-[#1D1815]/12 bg-white p-5">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="text-sm font-semibold text-[#1D1815]">
                            Menu Stock Control ({unavailableItemIds.length} marked sold out)
                          </h3>
                          <p className="mt-1 text-xs text-[#6A5E55]">
                            Uncheck any item to immediately mark it Sold Out. Changes publish live
                            and block ordering right away.
                          </p>
                        </div>
                        {unavailableItemIds.length > 0 && (
                          <button
                            type="button"
                            disabled={savingOps}
                            onClick={handleMarkAllAvailable}
                            className="rounded-lg border border-[#2A473A]/30 px-3 py-1.5 text-xs font-medium text-[#2A473A] hover:bg-[#2A473A]/8 disabled:opacity-50 whitespace-nowrap shrink-0"
                          >
                            Mark All Available
                          </button>
                        )}
                      </div>

                      {/* Search & Filter Bar */}
                      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                        <div className="relative flex-1">
                          <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-[#6A5E55]" />
                          <input
                            type="search"
                            value={stockSearch}
                            onChange={(e) => setStockSearch(e.target.value)}
                            placeholder="Search menu items or categories..."
                            className="w-full rounded-lg border border-[#1D1815]/15 bg-[#FAF8F5] py-2 pr-3 pl-9 text-xs text-[#1D1815] outline-none focus:border-[#2A473A]"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowSoldOutOnly((prev) => !prev)}
                          className={`min-h-[36px] rounded-lg border px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                            showSoldOutOnly
                              ? 'border-[#7A3222] bg-[#7A3222] text-[#FAF8F5]'
                              : 'border-[#1D1815]/15 bg-[#FAF8F5] text-[#5A5048] hover:text-[#1D1815]'
                          }`}
                        >
                          Sold Out Only ({unavailableItemIds.length})
                        </button>
                      </div>

                      <div className="mt-4 space-y-5">
                        {filteredCategories.length === 0 ? (
                          <p className="rounded-lg bg-[#F4F0EA] p-4 text-xs text-[#5A5048]">
                            {showSoldOutOnly
                              ? 'No items are currently marked sold out.'
                              : 'No menu items match your search.'}
                          </p>
                        ) : (
                          filteredCategories.map((category) => (
                            <div key={category.id}>
                              <p className="text-xs font-semibold text-[#5A5048]">
                                {category.title}
                              </p>
                              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                                {category.items.map((item) => {
                                  const soldOut = unavailableItemIds.includes(item.id);
                                  const isBusy = busyStockItemId === item.id;
                                  return (
                                    <label
                                      key={item.id}
                                      className={`flex cursor-pointer items-center justify-between gap-2 rounded-lg border px-3 py-2 text-xs transition-colors ${
                                        soldOut
                                          ? 'border-[#9A4B38]/35 bg-[#9A4B38]/8 text-[#7A3222]'
                                          : 'border-[#1D1815]/10 bg-[#FAF8F5] text-[#1D1815]'
                                      } ${isBusy ? 'opacity-70' : ''}`}
                                    >
                                      <span className="truncate font-medium">{item.name}</span>
                                      <span className="flex shrink-0 items-center gap-2">
                                        <span>
                                          {isBusy
                                            ? 'Saving...'
                                            : soldOut
                                              ? 'Sold Out'
                                              : 'Available'}
                                        </span>
                                        <input
                                          type="checkbox"
                                          checked={!soldOut}
                                          disabled={isBusy}
                                          onChange={() =>
                                            toggleUnavailableItem(item.id, item.name)
                                          }
                                          className="h-4 w-4 accent-[#2A473A]"
                                        />
                                      </span>
                                    </label>
                                  );
                                })}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* TAB 3: INTERNAL SHIFT & RESERVATION NOTES (Owner + Manager) */}
              {activeTab === 'notes' && (
                <div className="space-y-6">
                  <form
                    onSubmit={handleCreateStaffNote}
                    className="space-y-3 rounded-xl border border-[#1D1815]/12 bg-white p-5"
                  >
                    <h3 className="text-sm font-semibold text-[#1D1815]">
                      Add Shift, Table Reservation or UTR Note
                    </h3>
                    {noteError && <p className="text-xs text-[#7A3222]">{noteError}</p>}
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                      <input
                        type="text"
                        maxLength={120}
                        required
                        value={noteTitle}
                        onChange={(e) => setNoteTitle(e.target.value)}
                        placeholder="Short title (e.g. Table 6 booked 8 PM)"
                        className="rounded-lg border border-[#1D1815]/15 px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A] sm:col-span-2"
                      />
                      <select
                        value={noteCategory}
                        onChange={(e) => setNoteCategory(e.target.value as StaffNoteCategory)}
                        className="rounded-lg border border-[#1D1815]/15 bg-white px-3 py-2 text-sm text-[#1D1815]"
                      >
                        <option value="reservation">Reservation</option>
                        <option value="shift">Shift Handover</option>
                        <option value="inventory">Inventory</option>
                        <option value="utr">UTR Follow-up</option>
                      </select>
                    </div>
                    <textarea
                      rows={2}
                      maxLength={500}
                      required
                      value={noteBody}
                      onChange={(e) => setNoteBody(e.target.value)}
                      placeholder="Write details for the owner or next shift manager..."
                      className="w-full rounded-lg border border-[#1D1815]/15 px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                    />
                    <button
                      type="submit"
                      disabled={savingNote}
                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-[#2A473A] px-4 py-2 text-xs font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-60"
                    >
                      <Plus className="h-4 w-4" />
                      {savingNote ? 'Saving Note...' : 'Log Staff Note'}
                    </button>
                  </form>

                  <div className="space-y-3">
                    {notes.length === 0 ? (
                      <p className="rounded-xl border border-[#1D1815]/10 bg-white p-8 text-center text-sm text-[#6A5E55]">
                        No shift notes logged yet.
                      </p>
                    ) : (
                      notes.map((note) => (
                        <div
                          key={note.id}
                          className="rounded-xl border border-[#1D1815]/12 bg-white p-4"
                        >
                          <div className="flex flex-wrap items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2 text-xs text-[#6A5E55]">
                                <span className="capitalize">{note.category}</span>
                                <span aria-hidden="true">·</span>
                                <span>{note.authorEmail}</span>
                                <span aria-hidden="true">·</span>
                                <span>{note.createdAt}</span>
                              </div>
                              <h4 className="mt-1 text-sm font-semibold text-[#1D1815]">
                                {note.title}
                              </h4>
                              <p className="mt-1 text-sm text-[#4E453E]">{note.body}</p>
                            </div>

                            <div className="flex items-center gap-2">
                              {note.status === 'open' ? (
                                <button
                                  type="button"
                                  onClick={() => handleToggleNoteStatus(note)}
                                  className="rounded-md border border-[#2A473A]/30 px-2.5 py-1 text-xs font-medium text-[#2A473A] hover:bg-[#2A473A]/8"
                                >
                                  Mark Resolved
                                </button>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-xs font-medium text-[#2A473A]">
                                  <CheckCircle2 className="h-3.5 w-3.5" />
                                  Resolved
                                </span>
                              )}

                              {staffRole === 'owner' && note.status === 'resolved' && (
                                <button
                                  type="button"
                                  onClick={() => handleToggleNoteStatus(note)}
                                  className="text-xs text-[#5A5048] underline"
                                >
                                  Reopen
                                </button>
                              )}

                              {staffRole === 'owner' && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteNote(note.id)}
                                  aria-label={`Delete note ${note.title}`}
                                  className="flex h-8 w-8 items-center justify-center rounded-md text-[#6A5E55] hover:bg-[#9A4B38]/10 hover:text-[#7A3222]"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: OWNER-ONLY MANAGER APPOINTMENT & GOVERNANCE */}
              {activeTab === 'managers' && staffRole === 'owner' && (
                <div className="space-y-6">
                  <form
                    onSubmit={handleAppointManager}
                    className="space-y-4 rounded-xl border border-[#1D1815]/12 bg-white p-5"
                  >
                    <div>
                      <p className="text-xs font-medium text-[#2A473A]">
                        Owner-Exclusive Governance
                      </p>
                      <h3 className="mt-1 font-display text-xl font-medium text-[#1D1815]">
                        Appoint a Cafe Manager by Email
                      </h3>
                      <p className="mt-1 text-xs leading-relaxed text-[#5A5048]">
                        Appointed managers sign in with their Google email and receive near-owner
                        responsibilities (managing live orders, UTR verification, menu stock, cafe
                        prep controls, and shift notes). Only you as the owner can appoint, pause,
                        or remove managers.
                      </p>
                    </div>

                    {managerError && (
                      <div
                        role="alert"
                        className="rounded-lg border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-2.5 text-xs text-[#7A3222]"
                      >
                        {managerError}
                      </div>
                    )}
                    {managerFeedback && (
                      <div className="rounded-lg border border-[#2A473A]/25 bg-[#2A473A]/10 px-4 py-2.5 text-xs text-[#1F372C]">
                        {managerFeedback}
                      </div>
                    )}

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label
                          htmlFor="mgr-email"
                          className="block text-xs font-medium text-[#1D1815]"
                        >
                          Manager Google Email
                        </label>
                        <input
                          id="mgr-email"
                          type="email"
                          required
                          maxLength={120}
                          value={managerEmail}
                          onChange={(e) => setManagerEmail(e.target.value)}
                          placeholder="manager@gmail.com"
                          className="mt-1 w-full rounded-lg border border-[#1D1815]/15 px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="mgr-name"
                          className="block text-xs font-medium text-[#1D1815]"
                        >
                          Manager Name
                        </label>
                        <input
                          id="mgr-name"
                          type="text"
                          required
                          maxLength={80}
                          value={managerName}
                          onChange={(e) => setManagerName(e.target.value)}
                          placeholder="e.g. Rohan Patel"
                          className="mt-1 w-full rounded-lg border border-[#1D1815]/15 px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="mgr-shift"
                        className="block text-xs font-medium text-[#1D1815]"
                      >
                        Shift / Responsibilities Note (Optional)
                      </label>
                      <input
                        id="mgr-shift"
                        type="text"
                        maxLength={180}
                        value={managerShiftNote}
                        onChange={(e) => setManagerShiftNote(e.target.value)}
                        placeholder="e.g. Evening Floor & Espresso Bar Lead (4 PM – 11:30 PM)"
                        className="mt-1 w-full rounded-lg border border-[#1D1815]/15 px-3 py-2 text-sm text-[#1D1815] outline-none focus:border-[#2A473A]"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={savingManager}
                      className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-[#2A473A] px-5 py-2 text-sm font-medium text-[#FAF8F5] hover:bg-[#1F372C] disabled:opacity-60"
                    >
                      <UserCheck className="h-4 w-4" />
                      {savingManager ? 'Appointing Manager...' : 'Appoint Manager'}
                    </button>
                  </form>

                  {/* Appointed Managers Roster */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-semibold text-[#1D1815]">
                      Appointed Managers ({managers.length})
                    </h3>
                    {managers.length === 0 ? (
                      <div className="rounded-xl border border-[#1D1815]/10 bg-white p-8 text-center text-sm text-[#6A5E55]">
                        No managers appointed yet. Use the form above to grant near-owner access to
                        a trusted manager email.
                      </div>
                    ) : (
                      managers.map((mgr) => (
                        <div
                          key={mgr.id}
                          className="flex flex-col justify-between gap-4 rounded-xl border border-[#1D1815]/12 bg-white p-4 sm:flex-row sm:items-center"
                        >
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2 text-xs text-[#6A5E55]">
                              <span
                                className={`font-medium ${
                                  mgr.status === 'active' ? 'text-[#2A473A]' : 'text-[#9A5B25]'
                                }`}
                              >
                                {mgr.status === 'active' ? 'Active Manager' : 'Access Paused'}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono">{mgr.email}</span>
                            </div>
                            <p className="mt-1 text-sm font-semibold text-[#1D1815]">{mgr.name}</p>
                            {mgr.shiftNote && (
                              <p className="mt-0.5 text-xs text-[#5A5048]">{mgr.shiftNote}</p>
                            )}
                          </div>

                          <div className="flex shrink-0 items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleToggleManagerStatus(mgr)}
                              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-[#1D1815]/15 px-3 py-1.5 text-xs font-medium text-[#1D1815] hover:bg-[#F4F0EA]"
                            >
                              {mgr.status === 'active' ? (
                                <>
                                  <UserMinus className="h-3.5 w-3.5" />
                                  Pause
                                </>
                              ) : (
                                <>
                                  <UserCheck className="h-3.5 w-3.5 text-[#2A473A]" />
                                  Reactivate
                                </>
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveManager(mgr)}
                              aria-label={`Remove manager ${mgr.email}`}
                              className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#9A4B38]/25 text-[#7A3222] hover:bg-[#9A4B38]/10"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
