import { Heart, Minus, Plus } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  CAFE_INFO,
  MENU_CATEGORIES,
  MENU_GROUPS,
  type MenuCategory,
  type MenuGroupId,
  type MenuItem,
} from '../data/menu';

interface MenuShowcaseProps {
  activeCategoryId: string;
  onSelectCategory: (categoryId: string) => void;
  cartQuantities: Record<string, number>;
  favoriteIds: string[];
  unavailableItemIds: string[];
  soldOutItemNames: string[];
  acceptingOrders: boolean;
  isOpenNow: boolean;
  closedReason?: string | null;
  onAddItem: (itemId: string) => void;
  onDecrementItem: (itemId: string) => void;
  onRemoveItem?: (itemId: string) => void;
  onToggleFavorite: (itemId: string) => void;
}

function groupBySubCategory(items: MenuItem[]): Array<{ title: string | null; items: MenuItem[] }> {
  const hasSubs = items.some((item) => Boolean(item.subCategory));
  if (!hasSubs) {
    return [{ title: null, items }];
  }
  const map = new Map<string, MenuItem[]>();
  for (const item of items) {
    const key = item.subCategory || 'Selections';
    const list = map.get(key) || [];
    list.push(item);
    map.set(key, list);
  }
  return Array.from(map.entries()).map(([title, list]) => ({ title, items: list }));
}

export function MenuShowcase({
  activeCategoryId,
  onSelectCategory,
  cartQuantities,
  favoriteIds,
  unavailableItemIds,
  soldOutItemNames,
  acceptingOrders,
  isOpenNow,
  closedReason,
  onAddItem,
  onDecrementItem,
  onRemoveItem,
  onToggleFavorite,
}: MenuShowcaseProps) {
  const activeCategory: MenuCategory =
    MENU_CATEGORIES.find((c) => c.id === activeCategoryId) || MENU_CATEGORIES[0];

  const activeGroupId: MenuGroupId = activeCategory.groupId;
  const visibleCategories = MENU_CATEGORIES.filter((c) => c.groupId === activeGroupId);
  const subSections = groupBySubCategory(activeCategory.items);

  function handleSelectGroup(groupId: MenuGroupId) {
    const firstInGroup = MENU_CATEGORIES.find((c) => c.groupId === groupId);
    if (firstInGroup) {
      onSelectCategory(firstInGroup.id);
    }
  }

  return (
    <section
      id="menu"
      className="mx-auto max-w-[1200px] px-6 py-20 lg:px-8 lg:py-24"
    >
      {/* Editorial section header */}
      <div className="flex flex-col gap-4 border-b border-[#1D1815]/10 pb-8 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <p className="text-xs font-medium tracking-wide text-[#6A5E55]">
            Garden Cafe Menu · Min Prep {CAFE_INFO.minPrepTime}
          </p>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight text-[#1D1815] sm:text-4xl">
            Explore Our Menu by Food & Beverage Type
          </h2>
        </div>
        <p className="max-w-md text-sm leading-relaxed text-[#5A5048]">
          Choose a section and category below to browse freshly prepared coffees, coolers, snacks,
          and club activities served outdoors at Toran Club.
        </p>
      </div>

      {/* Live Opening Hours Gate & Live Sold-Out Menu Status */}
      {(!isOpenNow || soldOutItemNames.length > 0) && (
        <div className="mt-6 space-y-3">
          {!isOpenNow && (
            <div
              role="status"
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#9A4B38]/30 bg-[#9A4B38]/10 px-4 py-3 text-sm text-[#7A3222]"
            >
              <span>
                {closedReason ||
                  "Ordering is currently closed outside IMMY's Coffee Cafe opening hours."}
              </span>
              <a
                href="#opening-hours"
                className="text-xs font-semibold underline underline-offset-4 whitespace-nowrap shrink-0"
              >
                View Weekly Hours
              </a>
            </div>
          )}

          {soldOutItemNames.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#1D1815]/12 bg-[#FAF8F5] px-4 py-2.5 text-xs text-[#4E453E]">
              <span>
                <strong className="text-[#7A3222]">Currently Sold Out:</strong>{' '}
                {soldOutItemNames.slice(0, 6).join(', ')}
                {soldOutItemNames.length > 6 ? ` +${soldOutItemNames.length - 6} more` : ''}
              </span>
              <span className="font-mono text-[#6A5E55]">Live kitchen availability</span>
            </div>
          )}
        </div>
      )}

      {/* Section Group Selector (Strictly category-grouped, zero "All Menu" tab) */}
      <div
        role="tablist"
        aria-label="Menu sections"
        className="mt-7 flex flex-wrap items-center gap-2 border-b border-[#1D1815]/10 pb-5"
      >
        {MENU_GROUPS.map((group) => {
          const isGroupActive = group.id === activeGroupId;
          const groupCategoryCount = MENU_CATEGORIES.filter((c) => c.groupId === group.id).length;
          return (
            <button
              key={group.id}
              type="button"
              role="tab"
              aria-selected={isGroupActive}
              onClick={() => handleSelectGroup(group.id)}
              className={`inline-flex min-h-[42px] items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2A473A] whitespace-nowrap shrink-0 ${
                isGroupActive
                  ? 'border-[#2A473A] bg-[#2A473A] text-[#FAF8F5]'
                  : 'border-[#1D1815]/15 bg-[#FAF8F5] text-[#4E453E] hover:border-[#1D1815]/30 hover:text-[#1D1815]'
              }`}
            >
              <span>{group.label}</span>
              <span
                className={`font-mono text-xs tabular-nums ${
                  isGroupActive ? 'text-[#FAF8F5]/80' : 'text-[#6A5E55]'
                }`}
              >
                {groupCategoryCount}
              </span>
            </button>
          );
        })}
      </div>

      {/* Category Picker with Dedicated Cozy Animated GIFs */}
      <div
        role="tablist"
        aria-label="Food and beverage categories"
        className={`mt-6 grid gap-4 ${
          visibleCategories.length <= 2
            ? 'grid-cols-2 max-w-xl'
            : visibleCategories.length <= 4
              ? 'grid-cols-2 sm:grid-cols-4'
              : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6'
        }`}
      >
        {visibleCategories.map((category) => {
          const isActive = category.id === activeCategory.id;
          return (
            <button
              key={category.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => onSelectCategory(category.id)}
              className={`group flex flex-col overflow-hidden rounded-xl border text-left transition-all duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2A473A] ${
                isActive
                  ? 'border-[#2A473A] bg-[#2A473A] text-[#FAF8F5] shadow-md -translate-y-0.5'
                  : 'border-[#1D1815]/10 bg-[#FAF8F5] text-[#1D1815] hover:border-[#1D1815]/25 hover:-translate-y-0.5'
              }`}
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#241B15]">
                <img
                  src={category.gifUrl}
                  alt={`Cozy animated ${category.title} GIF`}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between p-3">
                <span className="truncate text-sm font-semibold leading-snug">
                  {category.shortTitle}
                </span>
                <span
                  className={`mt-1 text-xs tabular-nums ${
                    isActive ? 'text-[#FAF8F5]/80' : 'text-[#6A5E55]'
                  }`}
                >
                  {category.items.length} {category.items.length === 1 ? 'item' : 'items'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Category Showcase */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeCategory.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10 grid grid-cols-1 items-start gap-8 lg:grid-cols-12"
        >
          {/* Featured Animated GIF Column */}
          <div className="lg:sticky lg:top-24 lg:col-span-5">
            <div className="overflow-hidden rounded-2xl border border-[#1D1815]/10 bg-[#FAF8F5]">
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#241B15]">
                <img
                  src={activeCategory.gifUrl}
                  alt={`Animated cozy illustration of ${activeCategory.title}`}
                  loading="eager"
                  className="h-full w-full object-cover"
                />
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#1D1815]/75 via-transparent to-transparent"
                />
                <div className="absolute inset-x-0 bottom-0 p-5 text-[#FAF8F5]">
                  <p className="text-xs font-medium text-[#FAF8F5]/85">
                    {activeCategory.atmosphereNote}
                  </p>
                  <h3 className="mt-1 font-display text-2xl font-medium leading-tight">
                    {activeCategory.title}
                  </h3>
                </div>
              </div>
              <div className="p-5">
                <p className="text-sm leading-relaxed text-[#5A5048]">
                  {activeCategory.subtitle}
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-[#6A5E55]">
                  <span className="tabular-nums">{activeCategory.items.length} menu selections</span>
                  <span aria-hidden="true">·</span>
                  <span>Served outdoors in our Toran Club garden</span>
                </div>
              </div>
            </div>
          </div>

          {/* Dishes List for Active Category */}
          <div className="space-y-6 lg:col-span-7">
            {subSections.map((section) => (
              <div
                key={section.title || activeCategory.id}
                className="overflow-hidden rounded-2xl border border-[#1D1815]/10 bg-[#FAF8F5]"
              >
                {section.title && (
                  <div className="flex items-center justify-between border-b border-[#1D1815]/10 bg-[#F4F0EA] px-5 py-3 sm:px-6">
                    <h4 className="font-display text-base font-medium text-[#1D1815]">
                      {section.title}
                    </h4>
                    <span className="font-mono text-xs text-[#6A5E55] tabular-nums">
                      {section.items.length} {section.items.length === 1 ? 'item' : 'items'}
                    </span>
                  </div>
                )}

                <div className="divide-y divide-[#1D1815]/10">
                  {section.items.map((item) => {
                    const qty = cartQuantities[item.id] || 0;
                    const isFav = favoriteIds.includes(item.id);
                    const isSoldOut = unavailableItemIds.includes(item.id);
                    const canOrder = isOpenNow && acceptingOrders && !isSoldOut;
                    return (
                      <div
                        key={item.id}
                        className={`flex flex-col justify-between gap-4 p-5 transition-colors duration-150 sm:flex-row sm:items-center sm:p-6 ${
                          isSoldOut ? 'opacity-65' : 'hover:bg-[#F4F0EA]/70'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-[#6A5E55]">
                            <span>{item.dietary}</span>
                            <span aria-hidden="true">·</span>
                            <span>{item.serving}</span>
                            {item.customizable && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-[#4E453E]">Customizable</span>
                              </>
                            )}
                            {isSoldOut ? (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="font-medium text-[#7A3222]">Sold Out</span>
                              </>
                            ) : (
                              item.note && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-medium text-[#2A473A]">{item.note}</span>
                                </>
                              )
                            )}
                          </div>
                          <h4 className="mt-1 text-base font-semibold text-[#1D1815]">
                            {item.name}
                          </h4>
                          <p className="mt-1 text-sm leading-relaxed text-[#5A5048]">
                            {item.description}
                          </p>
                        </div>

                        <div className="flex shrink-0 items-center justify-between gap-4 sm:flex-col sm:items-end sm:justify-center">
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() => onToggleFavorite(item.id)}
                              aria-label={
                                isFav
                                  ? `Remove ${item.name} from favorites`
                                  : `Save ${item.name} to favorites`
                              }
                              className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#1D1815]/10 text-[#6A5E55] transition-colors hover:border-[#1D1815]/25 hover:text-[#1D1815] focus-visible:outline-2 focus-visible:outline-[#2A473A]"
                            >
                              <Heart
                                className={`h-4 w-4 ${
                                  isFav ? 'fill-[#9A4B38] text-[#9A4B38]' : ''
                                }`}
                              />
                            </button>
                            <span className="font-mono text-base font-semibold text-[#1D1815] tabular-nums">
                              ₹{item.price}
                            </span>
                          </div>

                          {!canOrder ? (
                            <div className="flex items-center gap-2">
                              <span className="inline-flex min-h-[40px] items-center justify-center rounded-lg border border-[#9A4B38]/25 bg-[#9A4B38]/8 px-3.5 py-2 text-xs font-medium text-[#7A3222] whitespace-nowrap shrink-0">
                                {isSoldOut ? 'Sold Out' : !isOpenNow ? 'Closed' : 'Paused'}
                              </span>
                              {isSoldOut && qty > 0 && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    onRemoveItem ? onRemoveItem(item.id) : onDecrementItem(item.id)
                                  }
                                  className="inline-flex min-h-[40px] items-center justify-center rounded-lg border border-[#1D1815]/15 bg-white px-3 py-2 text-xs font-medium text-[#5A5048] hover:border-[#9A4B38]/40 hover:text-[#7A3222] whitespace-nowrap shrink-0"
                                >
                                  Remove ({qty})
                                </button>
                              )}
                            </div>
                          ) : qty === 0 ? (
                            <button
                              type="button"
                              onClick={() => onAddItem(item.id)}
                              className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg bg-[#2A473A] px-4 py-2 text-sm font-medium text-[#FAF8F5] transition-colors duration-150 hover:bg-[#1F372C] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2A473A] whitespace-nowrap shrink-0"
                            >
                              <Plus className="h-4 w-4" />
                              Add
                            </button>
                          ) : (
                            <div className="inline-flex min-h-[40px] items-center rounded-lg border border-[#2A473A] bg-[#FAF8F5]">
                              <button
                                type="button"
                                onClick={() => onDecrementItem(item.id)}
                                aria-label={`Decrease quantity of ${item.name}`}
                                className="flex h-10 w-10 items-center justify-center text-[#2A473A] transition-colors hover:bg-[#2A473A]/10"
                              >
                                <Minus className="h-4 w-4" />
                              </button>
                              <span className="w-8 text-center font-mono text-sm font-semibold text-[#1D1815] tabular-nums">
                                {qty}
                              </span>
                              <button
                                type="button"
                                onClick={() => onAddItem(item.id)}
                                aria-label={`Increase quantity of ${item.name}`}
                                className="flex h-10 w-10 items-center justify-center text-[#2A473A] transition-colors hover:bg-[#2A473A]/10"
                              >
                                <Plus className="h-4 w-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </section>
  );
}
