import type {
  CafeOpenStatus,
  CafeOperationsSettings,
  CafeOrder,
  CartEntry,
  DayOfWeekKey,
  DiningMode,
  GatewayCapabilities,
  KitchenStatus,
  PaymentGateway,
  StaffBookingsSummary,
  StaffOrdersSummary,
  StaffRole,
  TableBooking,
  TableBookingStatus,
  TableSlotAvailability,
  WeeklyOpeningHours,
} from '../types';

// Keep anonymous guest token in memory alongside HttpOnly cookie for iframe compatibility
let memoryGuestToken: string | null = null;

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'X-Requested-With': 'IMMYsCafe',
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string> | undefined),
  };

  if (memoryGuestToken && !headers.Authorization) {
    headers['X-Guest-Token'] = memoryGuestToken;
  }

  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(typeof data.error === 'string' ? data.error : 'Something went wrong.');
  }
  if (typeof data.guestToken === 'string') {
    memoryGuestToken = data.guestToken;
  }
  return data as T;
}

export const cafeApi = {
  getQuickUpiQr: () =>
    apiFetch<{
      qrDataUrl: string;
      gateways: GatewayCapabilities;
    }>('/api/upi/quick-qr'),

  getHours: () =>
    apiFetch<{
      weeklyHours: WeeklyOpeningHours;
      openStatus: CafeOpenStatus;
    }>('/api/hours'),

  getStaffRole: (idToken: string) =>
    apiFetch<{ role: StaffRole }>('/api/staff/me', {
      headers: { Authorization: `Bearer ${idToken}` },
    }),

  getOrders: () =>
    apiFetch<{
      orders: CafeOrder[];
      deletedOrders: CafeOrder[];
      guestToken: string;
      gateways: GatewayCapabilities;
    }>('/api/orders'),

  deleteOrder: (orderId: string) =>
    apiFetch<{ deletedOrder: CafeOrder; guestToken: string }>(
      `/api/orders/${encodeURIComponent(orderId)}`,
      { method: 'DELETE' }
    ),

  restoreOrder: (orderId: string) =>
    apiFetch<{ order: CafeOrder; guestToken: string }>(
      `/api/orders/${encodeURIComponent(orderId)}/restore`,
      { method: 'POST' }
    ),

  createPaymentOrder: (payload: {
    items: CartEntry[];
    gateway: PaymentGateway;
    diningMode: DiningMode;
    customerName: string;
    customerPhone: string;
    tableOrNotes: string;
  }) =>
    apiFetch<{
      order: CafeOrder;
      qrDataUrl: string;
      guestToken: string;
      paymentSessionId?: string;
      gateways: GatewayCapabilities;
    }>('/api/payments/create-order', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  confirmWithUtr: (payload: {
    orderId: string;
    gateway: PaymentGateway;
    upiRefUtr: string;
  }) =>
    apiFetch<{ order: CafeOrder; verified: boolean }>('/api/payments/verify', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  checkPaymentStatus: (orderId: string) =>
    apiFetch<{
      order: CafeOrder;
      checkedAt: string;
      gateways: GatewayCapabilities;
    }>(`/api/payments/status/${encodeURIComponent(orderId)}`),

  // Staff-protected routes (Owner or Active Manager via Firebase ID Token)
  getStaffOrders: (idToken: string) =>
    apiFetch<{
      role: 'owner' | 'manager';
      orders: CafeOrder[];
      deletedOrders: CafeOrder[];
      summary: StaffOrdersSummary;
    }>('/api/staff/orders', {
      headers: { Authorization: `Bearer ${idToken}` },
    }),

  updateKitchenStatus: (idToken: string, orderId: string, kitchenStatus: KitchenStatus) =>
    apiFetch<{ order: CafeOrder }>(`/api/staff/orders/${encodeURIComponent(orderId)}/kitchen`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${idToken}` },
      body: JSON.stringify({ kitchenStatus }),
    }),

  staffConfirmUtr: (
    idToken: string,
    orderId: string,
    gateway: PaymentGateway,
    upiRefUtr: string
  ) =>
    apiFetch<{ order: CafeOrder }>(
      `/api/staff/orders/${encodeURIComponent(orderId)}/confirm-utr`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${idToken}` },
        body: JSON.stringify({ gateway, upiRefUtr }),
      }
    ),

  staffDeleteOrder: (idToken: string, orderId: string) =>
    apiFetch<{ deletedOrder: CafeOrder }>(
      `/api/staff/orders/${encodeURIComponent(orderId)}`,
      {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${idToken}` },
      }
    ),

  getOperations: () =>
    apiFetch<{ operations: CafeOperationsSettings }>('/api/operations'),

  getTableAvailability: (date?: string) =>
    apiFetch<{
      date: string;
      today: string;
      dayKey: DayOfWeekKey;
      dayLabel: string;
      isDayClosed: boolean;
      scheduleLabel: string;
      openStatus: CafeOpenStatus;
      totalTables: number;
      slots: TableSlotAvailability[];
    }>(date ? `/api/bookings/availability?date=${encodeURIComponent(date)}` : '/api/bookings/availability'),

  getMyBookings: () =>
    apiFetch<{
      bookings: TableBooking[];
      totalTables: number;
      guestToken: string;
    }>('/api/bookings'),

  createTableBooking: (payload: {
    guestName: string;
    guestPhone: string;
    bookingDate: string;
    timeSlot: string;
    partySize: number;
    notes: string;
  }) =>
    apiFetch<{
      booking: TableBooking;
      guestToken: string;
      availability: {
        date: string;
        dayKey: DayOfWeekKey;
        dayLabel: string;
        isDayClosed: boolean;
        scheduleLabel: string;
        totalTables: number;
        slots: TableSlotAvailability[];
      };
    }>('/api/bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  cancelMyBooking: (bookingId: string) =>
    apiFetch<{
      booking: TableBooking;
      guestToken: string;
      availability: {
        date: string;
        dayKey: DayOfWeekKey;
        dayLabel: string;
        isDayClosed: boolean;
        scheduleLabel: string;
        totalTables: number;
        slots: TableSlotAvailability[];
      };
    }>(`/api/bookings/${encodeURIComponent(bookingId)}`, {
      method: 'DELETE',
    }),

  staffRestoreOrder: (idToken: string, orderId: string) =>
    apiFetch<{ order: CafeOrder }>(
      `/api/staff/orders/${encodeURIComponent(orderId)}/restore`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${idToken}` },
      }
    ),

  syncStaffOperations: (
    idToken: string,
    payload: {
      acceptingOrders: boolean;
      prepTimeMinutes: number;
      dailySpecialNotice: string;
      unavailableItemIds: string[];
    }
  ) =>
    apiFetch<{ operations: CafeOperationsSettings }>('/api/staff/operations', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${idToken}` },
      body: JSON.stringify(payload),
    }),

  updateStaffHours: (idToken: string, weeklyHours: WeeklyOpeningHours) =>
    apiFetch<{
      weeklyHours: WeeklyOpeningHours;
      openStatus: CafeOpenStatus;
    }>('/api/staff/hours', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${idToken}` },
      body: JSON.stringify({ weeklyHours }),
    }),

  getStaffBookings: (idToken: string) =>
    apiFetch<{
      role: 'owner' | 'manager';
      today: string;
      bookings: TableBooking[];
      summary: StaffBookingsSummary;
    }>('/api/staff/bookings', {
      headers: { Authorization: `Bearer ${idToken}` },
    }),

  updateStaffBookingStatus: (
    idToken: string,
    bookingId: string,
    status: TableBookingStatus
  ) =>
    apiFetch<{ booking: TableBooking }>(
      `/api/staff/bookings/${encodeURIComponent(bookingId)}/status`,
      {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${idToken}` },
        body: JSON.stringify({ status }),
      }
    ),

  deleteStaffBooking: (idToken: string, bookingId: string) =>
    apiFetch<{ deletedBooking: TableBooking }>(
      `/api/staff/bookings/${encodeURIComponent(bookingId)}`,
      {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${idToken}` },
      }
    ),

  updateTableConfig: (idToken: string, totalTables: number) =>
    apiFetch<{ totalTables: number }>('/api/staff/table-config', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${idToken}` },
      body: JSON.stringify({ totalTables }),
    }),
};
