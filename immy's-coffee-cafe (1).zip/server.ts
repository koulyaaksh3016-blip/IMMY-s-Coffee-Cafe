import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express, { type NextFunction, type Request, type Response } from 'express';
import QRCode from 'qrcode';
import { createServer as createViteServer } from 'vite';
import { CAFE_INFO, MENU_ITEMS_BY_ID } from './src/data/menu.ts';
import type {
  CafeOpenStatus,
  CafeOperationsSettings,
  CafeOrder,
  DayOfWeekKey,
  DayOpeningHours,
  DiningMode,
  KitchenStatus,
  OrderItem,
  PaymentGateway,
  TableBooking,
  TableBookingStatus,
  TableSlotAvailability,
  WeeklyOpeningHours,
} from './src/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(__dirname, 'data');
const STORE_PATH = path.resolve(DATA_DIR, 'cafe-store.json');
const GUEST_COOKIE_NAME = 'immy_guest';
// Strictly server-side secrets/identifiers — NEVER exposed in client UI or API JSON
const OWNER_EMAIL = 'koulyaaksh3016@gmail.com';
const CAFE_UPI_ID = process.env.CAFE_UPI_ID?.trim() || 'yaakshuu@fam';

const firebaseConfigPath = path.resolve(__dirname, 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8')) as {
  projectId: string;
  firestoreDatabaseId: string;
};

const GUEST_SIGNING_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.trim().length >= 16
    ? process.env.SESSION_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

interface StoredCafeOperations extends CafeOperationsSettings {
  updatedAt: string;
}

interface CafeStore {
  orders: CafeOrder[];
  deletedOrders: CafeOrder[];
  usedUtrs: Record<string, string>;
  operations?: StoredCafeOperations;
  weeklyHours: WeeklyOpeningHours;
  tableBookings: TableBooking[];
  tableConfig: {
    totalTables: number;
  };
}

const MAX_DELETED_ARCHIVE = 50;
const DEFAULT_TOTAL_TABLES = 8;

const DAY_ORDER: DayOfWeekKey[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
];

const DAY_LABELS: Record<DayOfWeekKey, string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
  sunday: 'Sunday',
};

const DEFAULT_WEEKLY_HOURS: WeeklyOpeningHours = {
  monday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  tuesday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  wednesday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  thursday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  friday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  saturday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
  sunday: { isOpen: true, openTime: '10:30', closeTime: '23:00' },
};

// Seed 1 visible live sold-out item ("Hot Chocolate" in default first category Tea & Hot Coffee)
// Controlled live by Owner/Manager console — once saved, exact staff choice persists.
const DEFAULT_STORED_OPERATIONS: StoredCafeOperations = {
  acceptingOrders: true,
  prepTimeMinutes: 15,
  dailySpecialNotice: '',
  unavailableItemIds: ['cof-hot-chocolate'],
  updatedByUid: 'seed',
  updatedByRole: 'owner',
  updatedAt: '1970-01-01T00:00:00.000Z',
};

interface StaffAuthedRequest extends Request {
  staffEmail?: string;
  staffUid?: string;
  staffRole?: 'owner' | 'manager';
}

let cachedGoogleCerts: Record<string, string> = {};
let googleCertsExpiry = 0;

function parseTimeToMinutes(hhmm: string): number | null {
  if (typeof hhmm !== 'string' || !/^\d{2}:\d{2}$/.test(hhmm)) return null;
  const [hh, mm] = hhmm.split(':').map(Number);
  if (!Number.isInteger(hh) || !Number.isInteger(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return hh * 60 + mm;
}

function formatMinutesTo12(totalMinutes: number): string {
  const clamped = ((totalMinutes % 1440) + 1440) % 1440;
  const hours24 = Math.floor(clamped / 60);
  const mins = clamped % 60;
  const suffix = hours24 >= 12 ? 'PM' : 'AM';
  const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;
  return `${String(hours12).padStart(2, '0')}:${String(mins).padStart(2, '0')} ${suffix}`;
}

function formatTime24To12(hhmm: string): string {
  const mins = parseTimeToMinutes(hhmm);
  if (mins === null) return hhmm;
  return formatMinutesTo12(mins);
}

function parseSlot12ToMinutes(slotLabel: string): number {
  const match = slotLabel.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return 9999;
  let hh = Number(match[1]);
  const mm = Number(match[2]);
  const period = match[3].toUpperCase();
  if (period === 'PM' && hh !== 12) hh += 12;
  if (period === 'AM' && hh === 12) hh = 0;
  return hh * 60 + mm;
}

function normalizeWeeklyHours(raw: unknown): WeeklyOpeningHours {
  const result = {} as WeeklyOpeningHours;
  const obj = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  for (const day of DAY_ORDER) {
    const entry = obj[day] && typeof obj[day] === 'object'
      ? (obj[day] as Partial<DayOpeningHours>)
      : null;
    const def = DEFAULT_WEEKLY_HOURS[day];
    const isOpen = typeof entry?.isOpen === 'boolean' ? entry.isOpen : def.isOpen;
    const openMins = entry?.openTime ? parseTimeToMinutes(entry.openTime) : null;
    const closeMins = entry?.closeTime ? parseTimeToMinutes(entry.closeTime) : null;
    if (openMins !== null && closeMins !== null && closeMins > openMins + 29) {
      result[day] = { isOpen, openTime: entry!.openTime!, closeTime: entry!.closeTime! };
    } else {
      result[day] = { ...def, isOpen };
    }
  }
  return result;
}

function validateWeeklyHoursPayload(
  raw: unknown
): { weeklyHours?: WeeklyOpeningHours; error?: string } {
  if (!raw || typeof raw !== 'object') {
    return { error: 'Weekly opening hours payload is required.' };
  }
  const obj = raw as Record<string, unknown>;
  const validated = {} as WeeklyOpeningHours;
  for (const day of DAY_ORDER) {
    const entry = obj[day] as Partial<DayOpeningHours> | undefined;
    if (!entry || typeof entry !== 'object') {
      return { error: `Missing schedule for ${DAY_LABELS[day]}.` };
    }
    const isOpen = Boolean(entry.isOpen);
    const openTime = typeof entry.openTime === 'string' ? entry.openTime.trim() : '';
    const closeTime = typeof entry.closeTime === 'string' ? entry.closeTime.trim() : '';
    const openMins = parseTimeToMinutes(openTime);
    const closeMins = parseTimeToMinutes(closeTime);
    if (openMins === null || closeMins === null) {
      return { error: `Invalid time format for ${DAY_LABELS[day]}. Use HH:MM (24-hour).` };
    }
    if (isOpen && closeMins < openMins + 60) {
      return {
        error: `${DAY_LABELS[day]} closing time must be at least 1 hour after opening time.`,
      };
    }
    validated[day] = { isOpen, openTime, closeTime };
  }
  return { weeklyHours: validated };
}

function getCurrentIstInfo(): {
  isoDate: string;
  dayKey: DayOfWeekKey;
  dayLabel: string;
  currentMinutes: number;
  formattedTime: string;
} {
  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const year = dateParts.find((p) => p.type === 'year')?.value || '2026';
  const month = dateParts.find((p) => p.type === 'month')?.value || '01';
  const day = dateParts.find((p) => p.type === 'day')?.value || '01';
  const isoDate = `${year}-${month}-${day}`;

  const timeParts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const rawHour = Number(timeParts.find((p) => p.type === 'hour')?.value || '0');
  const hour = rawHour === 24 ? 0 : rawHour;
  const minute = Number(timeParts.find((p) => p.type === 'minute')?.value || '0');
  const currentMinutes = hour * 60 + minute;

  const weekdayLong = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Kolkata',
    weekday: 'long',
  })
    .format(now)
    .toLowerCase() as DayOfWeekKey;

  const dayKey: DayOfWeekKey = DAY_ORDER.includes(weekdayLong) ? weekdayLong : 'monday';
  return {
    isoDate,
    dayKey,
    dayLabel: DAY_LABELS[dayKey],
    currentMinutes,
    formattedTime: formatMinutesTo12(currentMinutes),
  };
}

function getDayKeyFromIsoDate(dateStr: string): DayOfWeekKey {
  const parsed = new Date(`${dateStr}T12:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return getCurrentIstInfo().dayKey;
  const map: DayOfWeekKey[] = [
    'sunday',
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
  ];
  return map[parsed.getUTCDay()] || 'monday';
}

function formatDayScheduleLabel(schedule: DayOpeningHours): string {
  if (!schedule.isOpen) return 'Closed';
  return `${formatTime24To12(schedule.openTime)} – ${formatTime24To12(schedule.closeTime)}`;
}

function evaluateCafeOpenNow(weeklyHours: WeeklyOpeningHours): CafeOpenStatus {
  const ist = getCurrentIstInfo();
  const todaySchedule = weeklyHours[ist.dayKey] || DEFAULT_WEEKLY_HOURS[ist.dayKey];
  const todayScheduleLabel = formatDayScheduleLabel(todaySchedule);

  if (!todaySchedule.isOpen) {
    return {
      isOpenNow: false,
      currentDayKey: ist.dayKey,
      currentDayLabel: ist.dayLabel,
      currentTimeIst: ist.formattedTime,
      todayIsoDate: ist.isoDate,
      todayScheduleLabel,
      closedReason: `IMMY's Coffee Cafe is closed on ${ist.dayLabel}s. Ordering and table booking resume during opening hours.`,
    };
  }

  const openMins = parseTimeToMinutes(todaySchedule.openTime) ?? 630;
  const closeMins = parseTimeToMinutes(todaySchedule.closeTime) ?? 1380;
  const isOpenNow = ist.currentMinutes >= openMins && ist.currentMinutes < closeMins;

  return {
    isOpenNow,
    currentDayKey: ist.dayKey,
    currentDayLabel: ist.dayLabel,
    currentTimeIst: ist.formattedTime,
    todayIsoDate: ist.isoDate,
    todayScheduleLabel,
    closedReason: isOpenNow
      ? null
      : `Ordering and table booking are only available during today's opening hours (${todayScheduleLabel} IST). Current time: ${ist.formattedTime} IST.`,
  };
}

function generateSlotsForDaySchedule(schedule: DayOpeningHours): Array<{
  timeSlot: string;
  minutes: number;
}> {
  if (!schedule.isOpen) return [];
  const openMins = parseTimeToMinutes(schedule.openTime);
  const closeMins = parseTimeToMinutes(schedule.closeTime);
  if (openMins === null || closeMins === null || closeMins <= openMins + 30) return [];

  const lastSlotMins = closeMins - 30;
  const slots: Array<{ timeSlot: string; minutes: number }> = [];

  // Start at the first clean 30-min boundary >= openTime, stepping every 60 minutes strictly inside [openTime, closeTime - 30m]
  let cursor = openMins;
  while (cursor <= lastSlotMins && slots.length < 16) {
    slots.push({ timeSlot: formatMinutesTo12(cursor), minutes: cursor });
    cursor += 60;
  }
  return slots;
}

function scrubSensitiveStrings(text: string): string {
  return text
    .replaceAll(CAFE_UPI_ID, "IMMY's Coffee Cafe Official QR")
    .replaceAll('yaakshuu@fam', "IMMY's Coffee Cafe Official QR")
    .replaceAll(OWNER_EMAIL, 'Cafe Owner')
    .replaceAll('koulyaaksh3016@gmail.com', 'Cafe Owner');
}

function sanitizeOrderForClient(order: CafeOrder): CafeOrder {
  const raw = order as CafeOrder & {
    upiId?: string;
    upiUri?: string;
    updatedByStaffEmail?: string;
  };
  const {
    upiId: _omitUpiId,
    upiUri: _omitUpiUri,
    updatedByStaffEmail: _omitStaffEmail,
    ...rest
  } = raw;

  return {
    ...rest,
    verificationMessage: scrubSensitiveStrings(rest.verificationMessage || ''),
    deletedBy: rest.deletedBy
      ? rest.deletedBy.startsWith('owner:')
        ? 'owner'
        : rest.deletedBy.startsWith('manager:')
          ? 'manager'
          : scrubSensitiveStrings(rest.deletedBy)
      : undefined,
  };
}

function sanitizeBookingForClient(booking: TableBooking): TableBooking {
  const raw = booking as TableBooking & { updatedByStaffEmail?: string };
  const { updatedByStaffEmail: _omitStaffEmail, ...rest } = raw;
  return rest;
}

function ensureStore(): CafeStore {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STORE_PATH)) {
    const initial: CafeStore = {
      orders: [],
      deletedOrders: [],
      usedUtrs: {},
      weeklyHours: { ...DEFAULT_WEEKLY_HOURS },
      tableBookings: [],
      tableConfig: { totalTables: DEFAULT_TOTAL_TABLES },
    };
    fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), 'utf8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as Partial<CafeStore>;
    const normalizedOrders = Array.isArray(parsed.orders)
      ? parsed.orders.map((order) =>
          sanitizeOrderForClient({
            ...order,
            kitchenStatus: order.kitchenStatus || 'received',
          })
        )
      : [];
    const normalizedDeleted = Array.isArray(parsed.deletedOrders)
      ? parsed.deletedOrders.map((order) =>
          sanitizeOrderForClient({
            ...order,
            kitchenStatus: order.kitchenStatus || 'received',
          })
        )
      : [];
    const normalizedBookings = Array.isArray(parsed.tableBookings)
      ? parsed.tableBookings
          .filter(
            (b): b is TableBooking =>
              Boolean(b && typeof b.id === 'string' && typeof b.bookingDate === 'string')
          )
          .map(sanitizeBookingForClient)
      : [];
    const rawTotalTables = Number(parsed.tableConfig?.totalTables);
    const totalTables =
      Number.isInteger(rawTotalTables) && rawTotalTables >= 1 && rawTotalTables <= 40
        ? rawTotalTables
        : DEFAULT_TOTAL_TABLES;
    return {
      orders: normalizedOrders,
      deletedOrders: normalizedDeleted.slice(0, MAX_DELETED_ARCHIVE),
      usedUtrs: parsed.usedUtrs && typeof parsed.usedUtrs === 'object' ? parsed.usedUtrs : {},
      operations: parsed.operations,
      weeklyHours: normalizeWeeklyHours(parsed.weeklyHours),
      tableBookings: normalizedBookings,
      tableConfig: { totalTables },
    };
  } catch {
    return {
      orders: [],
      deletedOrders: [],
      usedUtrs: {},
      weeklyHours: { ...DEFAULT_WEEKLY_HOURS },
      tableBookings: [],
      tableConfig: { totalTables: DEFAULT_TOTAL_TABLES },
    };
  }
}

let store: CafeStore = ensureStore();

function archiveDeletedOrder(orderIndex: number, deletedBy: string): CafeOrder {
  const [removed] = store.orders.splice(orderIndex, 1);
  if (removed.upiRefUtr && store.usedUtrs[removed.upiRefUtr] === removed.id) {
    delete store.usedUtrs[removed.upiRefUtr];
  }
  const archived: CafeOrder = {
    ...removed,
    deletedAt: new Date().toISOString(),
    deletedBy,
  };
  store.deletedOrders = [
    archived,
    ...store.deletedOrders.filter((o) => o.id !== archived.id),
  ].slice(0, MAX_DELETED_ARCHIVE);
  persistStore();
  return archived;
}

function restoreArchivedOrder(deletedIndex: number): { order?: CafeOrder; conflictError?: string } {
  const target = store.deletedOrders[deletedIndex];
  if (!target) return { conflictError: 'Deleted order not found.' };

  if (
    target.upiRefUtr &&
    store.usedUtrs[target.upiRefUtr] &&
    store.usedUtrs[target.upiRefUtr] !== target.id
  ) {
    return {
      conflictError:
        'Cannot undo this deletion because its 12-digit UTR number is now used by another active order.',
    };
  }

  store.deletedOrders.splice(deletedIndex, 1);
  const restored: CafeOrder = { ...target };
  delete restored.deletedAt;
  delete restored.deletedBy;

  if (restored.upiRefUtr && restored.paymentStatus === 'PAID_VERIFIED') {
    store.usedUtrs[restored.upiRefUtr] = restored.id;
  }

  store.orders = [restored, ...store.orders.filter((o) => o.id !== restored.id)];
  persistStore();
  return { order: restored };
}

function persistStore(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmpPath, STORE_PATH);
}

function sanitizeText(input: unknown, maxLen: number): string {
  if (typeof input !== 'string') return '';
  return input.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, maxLen);
}

function sanitizeOptionalPhone(input: unknown): string {
  if (typeof input !== 'string') return '';
  const digits = input.replace(/\D/g, '');
  if (!digits) return '';
  return digits.slice(-10);
}

function emailToManagerId(email: string): string {
  return email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_');
}

async function getGooglePublicCerts(): Promise<Record<string, string>> {
  const now = Date.now();
  if (now < googleCertsExpiry && Object.keys(cachedGoogleCerts).length > 0) {
    return cachedGoogleCerts;
  }
  const res = await fetch(
    'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com'
  );
  if (!res.ok) {
    throw new Error('Unable to fetch Firebase verification certificates.');
  }
  const cacheControl = res.headers.get('cache-control') || '';
  const match = cacheControl.match(/max-age=(\d+)/);
  const ttlMs = match ? Number(match[1]) * 1000 : 300_000;
  cachedGoogleCerts = (await res.json()) as Record<string, string>;
  googleCertsExpiry = now + Math.max(60_000, ttlMs);
  return cachedGoogleCerts;
}

async function verifyFirebaseIdToken(idToken: string): Promise<{ email: string; uid: string } | null> {
  const parts = idToken.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, signatureB64] = parts;

  try {
    const header = JSON.parse(Buffer.from(headerB64, 'base64url').toString('utf8')) as {
      alg?: string;
      kid?: string;
    };
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as {
      aud?: string;
      iss?: string;
      sub?: string;
      exp?: number;
      iat?: number;
      email?: string;
      email_verified?: boolean;
    };

    if (header.alg !== 'RS256' || !header.kid) return null;
    const nowSec = Math.floor(Date.now() / 1000);
    if (
      payload.aud !== firebaseConfig.projectId ||
      payload.iss !== `https://securetoken.google.com/${firebaseConfig.projectId}` ||
      !payload.sub ||
      typeof payload.exp !== 'number' ||
      payload.exp <= nowSec ||
      payload.email_verified !== true ||
      typeof payload.email !== 'string'
    ) {
      return null;
    }

    const certs = await getGooglePublicCerts();
    const cert = certs[header.kid];
    if (!cert) return null;

    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(`${headerB64}.${payloadB64}`);
    verifier.end();
    const sigBuf = Buffer.from(signatureB64, 'base64url');
    if (!verifier.verify(cert, sigBuf)) return null;

    return { email: payload.email.trim().toLowerCase(), uid: payload.sub };
  } catch {
    return null;
  }
}

async function isActiveManagerViaFirestore(email: string, idToken: string): Promise<boolean> {
  const docId = emailToManagerId(email);
  const url = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(
    firebaseConfig.projectId
  )}/databases/${encodeURIComponent(
    firebaseConfig.firestoreDatabaseId
  )}/documents/managers/${encodeURIComponent(docId)}`;

  try {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${idToken}`,
      },
    });
    if (!res.ok) return false;
    const docData = (await res.json()) as {
      fields?: {
        status?: { stringValue?: string };
        email?: { stringValue?: string };
      };
    };
    return (
      docData.fields?.status?.stringValue === 'active' &&
      docData.fields?.email?.stringValue?.toLowerCase() === email.toLowerCase()
    );
  } catch {
    return false;
  }
}

function normalizeUnavailableIds(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const valid: string[] = [];
  for (const entry of raw) {
    if (typeof entry === 'string' && MENU_ITEMS_BY_ID[entry] && !seen.has(entry)) {
      seen.add(entry);
      valid.push(entry);
      if (valid.length >= 200) break;
    }
  }
  return valid;
}

async function fetchLiveCafeOperations(): Promise<StoredCafeOperations> {
  const localOps = store.operations;
  const url = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(
    firebaseConfig.projectId
  )}/databases/${encodeURIComponent(
    firebaseConfig.firestoreDatabaseId
  )}/documents/cafeSettings/operations`;

  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(2500) });
    if (res.ok) {
      const docData = (await res.json()) as {
        updateTime?: string;
        fields?: {
          acceptingOrders?: { booleanValue?: boolean };
          prepTimeMinutes?: { integerValue?: string; doubleValue?: number };
          dailySpecialNotice?: { stringValue?: string };
          unavailableItemIds?: {
            arrayValue?: { values?: Array<{ stringValue?: string }> };
          };
          updatedByUid?: { stringValue?: string };
          updatedByRole?: { stringValue?: string };
          updatedAt?: { timestampValue?: string };
        };
      };

      const f = docData.fields;
      if (f) {
        const fsUpdatedAt =
          f.updatedAt?.timestampValue || docData.updateTime || new Date().toISOString();
        const rawPrep =
          f.prepTimeMinutes?.integerValue !== undefined
            ? Number(f.prepTimeMinutes.integerValue)
            : Number(f.prepTimeMinutes?.doubleValue ?? 15);
        const fsOps: StoredCafeOperations = {
          acceptingOrders:
            typeof f.acceptingOrders?.booleanValue === 'boolean'
              ? f.acceptingOrders.booleanValue
              : true,
          prepTimeMinutes: Math.min(120, Math.max(5, Math.round(rawPrep || 15))),
          dailySpecialNotice: sanitizeText(f.dailySpecialNotice?.stringValue || '', 180),
          unavailableItemIds: normalizeUnavailableIds(
            (f.unavailableItemIds?.arrayValue?.values || []).map((v) => v.stringValue)
          ),
          updatedByUid: sanitizeText(f.updatedByUid?.stringValue || 'staff', 120),
          updatedByRole: f.updatedByRole?.stringValue === 'manager' ? 'manager' : 'owner',
          updatedAt: fsUpdatedAt,
        };

        const fsTime = Date.parse(fsOps.updatedAt) || 0;
        const localTime = localOps ? Date.parse(localOps.updatedAt) || 0 : 0;

        if (!localOps || fsTime >= localTime) {
          store.operations = fsOps;
          persistStore();
          return fsOps;
        }
        return localOps;
      }
    }
  } catch {
    // Fall back gracefully to persisted server mirror if Firestore is temporarily unreachable
  }

  return localOps || DEFAULT_STORED_OPERATIONS;
}

function getTodayIstIsoDate(): string {
  return getCurrentIstInfo().isoDate;
}

function isValidBookingDate(dateStr: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return false;
  const parsed = new Date(`${dateStr}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return false;
  const todayStr = getTodayIstIsoDate();
  const todayMs = Date.parse(`${todayStr}T00:00:00Z`);
  const targetMs = parsed.getTime();
  const oneDayMs = 24 * 60 * 60 * 1000;
  return targetMs >= todayMs && targetMs <= todayMs + 14 * oneDayMs;
}

function getSlotAvailabilityForDate(dateStr: string): {
  dayKey: DayOfWeekKey;
  dayLabel: string;
  isDayClosed: boolean;
  scheduleLabel: string;
  slots: TableSlotAvailability[];
} {
  const totalTables = store.tableConfig.totalTables;
  const dayKey = getDayKeyFromIsoDate(dateStr);
  const dayLabel = DAY_LABELS[dayKey];
  const schedule = store.weeklyHours[dayKey] || DEFAULT_WEEKLY_HOURS[dayKey];
  const scheduleLabel = formatDayScheduleLabel(schedule);

  if (!schedule.isOpen) {
    return { dayKey, dayLabel, isDayClosed: true, scheduleLabel, slots: [] };
  }

  const ist = getCurrentIstInfo();
  const isToday = dateStr === ist.isoDate;
  const daySlots = generateSlotsForDaySchedule(schedule);

  const slots: TableSlotAvailability[] = daySlots.map(({ timeSlot, minutes }) => {
    const activeInSlot = store.tableBookings.filter(
      (b) =>
        b.bookingDate === dateStr &&
        b.timeSlot === timeSlot &&
        (b.status === 'confirmed' || b.status === 'seated')
    );
    const bookedTables = activeInSlot.reduce((sum, b) => sum + b.tablesAllocated, 0);
    const remainingTables = Math.max(0, totalTables - bookedTables);
    const isPast = isToday && minutes <= ist.currentMinutes;
    return {
      timeSlot,
      bookedTables,
      remainingTables,
      totalTables,
      isFull: remainingTables <= 0,
      isPast,
    };
  });

  return { dayKey, dayLabel, isDayClosed: false, scheduleLabel, slots };
}

function allocateFreeTableNumbers(
  dateStr: string,
  timeSlot: string,
  tablesNeeded: number,
  excludeBookingId?: string
): number[] | null {
  const totalTables = store.tableConfig.totalTables;
  const occupied = new Set<number>();
  let totalOccupiedCount = 0;

  for (const b of store.tableBookings) {
    if (
      b.id !== excludeBookingId &&
      b.bookingDate === dateStr &&
      b.timeSlot === timeSlot &&
      (b.status === 'confirmed' || b.status === 'seated')
    ) {
      totalOccupiedCount += b.tablesAllocated;
      for (const n of b.tableNumbers || []) {
        occupied.add(n);
      }
    }
  }

  if (totalOccupiedCount + tablesNeeded > totalTables) {
    return null;
  }

  const assigned: number[] = [];
  for (let tableNo = 1; tableNo <= totalTables && assigned.length < tablesNeeded; tableNo++) {
    if (!occupied.has(tableNo)) {
      assigned.push(tableNo);
    }
  }
  return assigned.length === tablesNeeded ? assigned : null;
}

async function requireStaffAuth(
  req: StaffAuthedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Staff sign-in required.' });
    return;
  }
  const idToken = authHeader.slice(7).trim();
  const verified = await verifyFirebaseIdToken(idToken);
  if (!verified) {
    res.status(401).json({ error: 'Invalid or expired staff authentication token.' });
    return;
  }

  if (verified.email === OWNER_EMAIL) {
    req.staffEmail = verified.email;
    req.staffUid = verified.uid;
    req.staffRole = 'owner';
    next();
    return;
  }

  const activeManager = await isActiveManagerViaFirestore(verified.email, idToken);
  if (activeManager) {
    req.staffEmail = verified.email;
    req.staffUid = verified.uid;
    req.staffRole = 'manager';
    next();
    return;
  }

  res.status(403).json({
    error: 'Access restricted. Only the cafe owner or an active owner-appointed manager can access this view.',
  });
}

function signGuestToken(guestId: string): string {
  const sig = crypto
    .createHmac('sha256', GUEST_SIGNING_SECRET)
    .update(guestId)
    .digest('base64url');
  return `${guestId}.${sig}`;
}

function verifyGuestToken(token: string | undefined): string | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [guestId, sig] = parts;
  if (!/^gst_[a-f0-9]{24}$/.test(guestId)) return null;
  const expected = crypto
    .createHmac('sha256', GUEST_SIGNING_SECRET)
    .update(guestId)
    .digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return guestId;
}

function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie;
  if (!header) return {};
  const result: Record<string, string> = {};
  for (const pair of header.split(';')) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim();
    const val = decodeURIComponent(pair.slice(idx + 1).trim());
    result[key] = val;
  }
  return result;
}

function resolveOrCreateGuest(req: Request, res: Response): { guestId: string; guestToken: string } {
  const headerToken = req.headers['x-guest-token'];
  if (typeof headerToken === 'string') {
    const verified = verifyGuestToken(headerToken.trim());
    if (verified) return { guestId: verified, guestToken: headerToken.trim() };
  }

  const cookies = parseCookies(req);
  if (cookies[GUEST_COOKIE_NAME]) {
    const verified = verifyGuestToken(cookies[GUEST_COOKIE_NAME]);
    if (verified) return { guestId: verified, guestToken: cookies[GUEST_COOKIE_NAME] };
  }

  const newGuestId = `gst_${crypto.randomBytes(12).toString('hex')}`;
  const signedToken = signGuestToken(newGuestId);
  res.setHeader(
    'Set-Cookie',
    [
      `${GUEST_COOKIE_NAME}=${encodeURIComponent(signedToken)}`,
      'Path=/',
      'HttpOnly',
      'Secure',
      'SameSite=None',
      'Partitioned',
      `Max-Age=${60 * 60 * 24 * 60}`,
    ].join('; ')
  );
  return { guestId: newGuestId, guestToken: signedToken };
}

function getGatewayCapabilities() {
  const razorpayKeyId = process.env.RAZORPAY_KEY_ID?.trim() || '';
  const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET?.trim() || '';
  const cashfreeAppId = process.env.CASHFREE_APP_ID?.trim() || '';
  const cashfreeSecretKey = process.env.CASHFREE_SECRET_KEY?.trim() || '';
  const cashfreeEnv =
    process.env.CASHFREE_ENV?.trim().toLowerCase() === 'production' ? 'production' : 'sandbox';

  return {
    razorpayLive: Boolean(razorpayKeyId && razorpayKeySecret),
    cashfreeLive: Boolean(cashfreeAppId && cashfreeSecretKey),
    razorpayKeyId: razorpayKeyId || undefined,
    cashfreeEnv,
  } as const;
}

function buildUpiUri(amount: number, note: string): string {
  const params = new URLSearchParams({
    pa: CAFE_UPI_ID,
    pn: CAFE_INFO.name,
    cu: 'INR',
    tn: note,
  });
  if (amount > 0) {
    params.set('am', amount.toFixed(2));
  }
  return `upi://pay?${params.toString()}`;
}

function csrfGuard(req: Request, res: Response, next: NextFunction): void {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const requestedWith = req.headers['x-requested-with'];
    if (requestedWith !== 'IMMYsCafe') {
      res.status(403).json({ error: 'Invalid request origin header.' });
      return;
    }
  }
  next();
}

async function createRazorpayOrder(amountInr: number, receiptId: string) {
  const keyId = process.env.RAZORPAY_KEY_ID?.trim();
  const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim();
  if (!keyId || !keySecret) return null;

  const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  const response = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: Math.round(amountInr * 100),
      currency: 'INR',
      receipt: receiptId,
      notes: {
        cafe: CAFE_INFO.name,
        upi_id: CAFE_UPI_ID,
      },
    }),
  });

  if (!response.ok) {
    throw new Error('Could not initialize Razorpay order.');
  }
  const data = (await response.json()) as { id: string };
  return data.id;
}

async function fetchRazorpayPaymentStatus(paymentId: string) {
  const keyId = process.env.RAZORPAY_KEY_ID?.trim();
  const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim();
  if (!keyId || !keySecret) return null;

  const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  const response = await fetch(
    `https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`,
    {
      headers: { Authorization: `Basic ${auth}` },
    }
  );
  if (!response.ok) return null;
  return (await response.json()) as {
    id: string;
    status: string;
    amount: number;
    method?: string;
    acquirer_data?: { rrn?: string; upi_transaction_id?: string };
  };
}

async function createCashfreeOrder(
  orderId: string,
  amountInr: number,
  customerPhone: string,
  customerName: string
) {
  const appId = process.env.CASHFREE_APP_ID?.trim();
  const secretKey = process.env.CASHFREE_SECRET_KEY?.trim();
  if (!appId || !secretKey) return null;

  const isProd = process.env.CASHFREE_ENV?.trim().toLowerCase() === 'production';
  const baseUrl = isProd
    ? 'https://api.cashfree.com/pg/orders'
    : 'https://sandbox.cashfree.com/pg/orders';

  const response = await fetch(baseUrl, {
    method: 'POST',
    headers: {
      'x-client-id': appId,
      'x-client-secret': secretKey,
      'x-api-version': '2023-08-01',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      order_id: orderId,
      order_amount: Number(amountInr.toFixed(2)),
      order_currency: 'INR',
      customer_details: {
        customer_id: `cust_${orderId.toLowerCase()}`,
        customer_phone: customerPhone || CAFE_INFO.phone,
        customer_name: customerName || 'Cafe Guest',
      },
      order_note: `IMMYs Coffee Cafe UPI Order ${orderId}`,
    }),
  });

  if (!response.ok) {
    throw new Error('Could not initialize Cashfree order.');
  }
  const data = (await response.json()) as { cf_order_id?: string; payment_session_id?: string };
  return {
    cfOrderId: data.cf_order_id || orderId,
    paymentSessionId: data.payment_session_id,
  };
}

async function fetchCashfreeOrderPayments(orderId: string) {
  const appId = process.env.CASHFREE_APP_ID?.trim();
  const secretKey = process.env.CASHFREE_SECRET_KEY?.trim();
  if (!appId || !secretKey) return null;

  const isProd = process.env.CASHFREE_ENV?.trim().toLowerCase() === 'production';
  const baseUrl = isProd
    ? `https://api.cashfree.com/pg/orders/${encodeURIComponent(orderId)}/payments`
    : `https://sandbox.cashfree.com/pg/orders/${encodeURIComponent(orderId)}/payments`;

  const response = await fetch(baseUrl, {
    headers: {
      'x-client-id': appId,
      'x-client-secret': secretKey,
      'x-api-version': '2023-08-01',
    },
  });
  if (!response.ok) return null;
  const list = (await response.json()) as Array<{
    cf_payment_id?: string | number;
    payment_status?: string;
    payment_amount?: number;
    bank_reference?: string;
  }>;
  return Array.isArray(list) ? list : [];
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '200kb' }));
  app.use('/api', csrfGuard);

  // Public quick counter UPI QR code (strictly QR image only — UPI ID never exposed in API)
  app.get('/api/upi/quick-qr', async (_req: Request, res: Response) => {
    try {
      const upiUri = buildUpiUri(0, 'IMMYs Coffee Cafe Counter Payment');
      const qrDataUrl = await QRCode.toDataURL(upiUri, {
        width: 280,
        margin: 2,
        color: { dark: '#1D1815', light: '#FAF8F5' },
      });
      res.json({
        qrDataUrl,
        gateways: getGatewayCapabilities(),
      });
    } catch {
      res.status(500).json({ error: 'Unable to generate UPI QR code.' });
    }
  });

  // Public Weekly Opening Hours & Live Open/Closed Status (IST)
  app.get('/api/hours', (_req: Request, res: Response) => {
    res.json({
      weeklyHours: store.weeklyHours,
      openStatus: evaluateCafeOpenNow(store.weeklyHours),
    });
  });

  // Public live cafe operations (sold-out items & acceptingOrders synced with Firestore — zero PII)
  app.get('/api/operations', async (_req: Request, res: Response) => {
    const liveOps = await fetchLiveCafeOperations();
    const { updatedByUid: _uid, ...safeOps } = liveOps;
    res.json({
      operations: {
        acceptingOrders: safeOps.acceptingOrders,
        prepTimeMinutes: safeOps.prepTimeMinutes,
        dailySpecialNotice: safeOps.dailySpecialNotice,
        unavailableItemIds: safeOps.unavailableItemIds,
        updatedByRole: safeOps.updatedByRole,
      },
    });
  });

  // Server-side staff role check (never exposes OWNER_EMAIL to client bundle)
  app.get('/api/staff/me', async (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.json({ role: 'none' });
      return;
    }
    const idToken = authHeader.slice(7).trim();
    const verified = await verifyFirebaseIdToken(idToken);
    if (!verified) {
      res.json({ role: 'unauthorized' });
      return;
    }
    if (verified.email === OWNER_EMAIL) {
      res.json({ role: 'owner' });
      return;
    }
    const activeManager = await isActiveManagerViaFirestore(verified.email, idToken);
    res.json({ role: activeManager ? 'manager' : 'unauthorized' });
  });

  // Public Garden Table Availability (Strictly anonymous counts — respects weekly opening hours)
  app.get('/api/bookings/availability', (req: Request, res: Response) => {
    const rawDate = typeof req.query.date === 'string' ? req.query.date.trim() : '';
    const dateStr = isValidBookingDate(rawDate) ? rawDate : getTodayIstIsoDate();
    const dayAvail = getSlotAvailabilityForDate(dateStr);
    res.json({
      date: dateStr,
      today: getTodayIstIsoDate(),
      dayKey: dayAvail.dayKey,
      dayLabel: dayAvail.dayLabel,
      isDayClosed: dayAvail.isDayClosed,
      scheduleLabel: dayAvail.scheduleLabel,
      openStatus: evaluateCafeOpenNow(store.weeklyHours),
      totalTables: store.tableConfig.totalTables,
      slots: dayAvail.slots,
    });
  });

  // Fetch this visitor's own table bookings (no login / no OTP)
  app.get('/api/bookings', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const bookings = store.tableBookings
      .filter((b) => b.guestId === guestId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .map(sanitizeBookingForClient);
    res.json({
      bookings,
      totalTables: store.tableConfig.totalTables,
      guestToken,
    });
  });

  // Create a Garden Table Booking with Name + Phone Number + Date + Time Slot (NO OTP)
  // Strictly enforces live opening hours AND selected day's [openTime, closeTime] window
  app.post('/api/bookings', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const openStatus = evaluateCafeOpenNow(store.weeklyHours);
    if (!openStatus.isOpenNow) {
      res.status(409).json({
        error:
          openStatus.closedReason ||
          "Table booking is disabled outside IMMY's Coffee Cafe opening hours.",
      });
      return;
    }

    const guestName = sanitizeText(req.body?.guestName, 60);
    const guestPhone = sanitizeOptionalPhone(req.body?.guestPhone);
    const bookingDate = sanitizeText(req.body?.bookingDate, 20) || getTodayIstIsoDate();
    const timeSlot = sanitizeText(req.body?.timeSlot, 20);
    const partySize = Math.round(Number(req.body?.partySize));
    const notes = sanitizeText(req.body?.notes, 160);

    if (guestName.length < 2) {
      res.status(400).json({ error: 'Please enter your name (at least 2 characters).' });
      return;
    }
    if (!/^\d{10}$/.test(guestPhone)) {
      res.status(400).json({
        error: 'Please enter a valid 10-digit mobile number (no OTP required).',
      });
      return;
    }
    if (!isValidBookingDate(bookingDate)) {
      res.status(400).json({
        error: 'Please select today or a future date within the next 14 days.',
      });
      return;
    }

    const dayAvail = getSlotAvailabilityForDate(bookingDate);
    if (dayAvail.isDayClosed) {
      res.status(409).json({
        error: `IMMY's Coffee Cafe is closed on ${dayAvail.dayLabel}s. Please select another day.`,
      });
      return;
    }

    const matchedSlot = dayAvail.slots.find((s) => s.timeSlot === timeSlot);
    if (!matchedSlot) {
      res.status(400).json({
        error: `Selected time slot is outside ${dayAvail.dayLabel} opening hours (${dayAvail.scheduleLabel} IST).`,
      });
      return;
    }
    if (matchedSlot.isPast) {
      res.status(409).json({
        error: `The ${timeSlot} slot has already passed today. Please choose an upcoming time slot.`,
      });
      return;
    }

    if (!Number.isInteger(partySize) || partySize < 1 || partySize > 12) {
      res.status(400).json({ error: 'Party size must be between 1 and 12 guests.' });
      return;
    }

    const duplicate = store.tableBookings.find(
      (b) =>
        b.guestPhone === guestPhone &&
        b.bookingDate === bookingDate &&
        b.timeSlot === timeSlot &&
        (b.status === 'confirmed' || b.status === 'seated')
    );
    if (duplicate) {
      res.status(409).json({
        error: `A garden table booking (${duplicate.id}) is already confirmed for this number at ${timeSlot} on ${bookingDate}.`,
      });
      return;
    }

    const tablesAllocated = Math.ceil(partySize / 4);
    const assignedTables = allocateFreeTableNumbers(bookingDate, timeSlot, tablesAllocated);
    if (!assignedTables) {
      const remaining = matchedSlot.remainingTables;
      res.status(409).json({
        error:
          remaining === 0
            ? `All ${store.tableConfig.totalTables} garden tables are booked for ${timeSlot} on ${bookingDate}. Please choose another time slot.`
            : `Only ${remaining} garden ${remaining === 1 ? 'table is' : 'tables are'} left for ${timeSlot} (your group of ${partySize} needs ${tablesAllocated}). Please choose another time slot.`,
      });
      return;
    }

    const booking: TableBooking = {
      id: `TBL-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      guestId,
      guestName,
      guestPhone,
      bookingDate,
      timeSlot,
      partySize,
      tablesAllocated,
      tableNumbers: assignedTables,
      notes,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };

    store.tableBookings.unshift(booking);
    persistStore();

    const updatedAvail = getSlotAvailabilityForDate(bookingDate);
    res.status(201).json({
      booking: sanitizeBookingForClient(booking),
      guestToken,
      availability: {
        date: bookingDate,
        dayKey: updatedAvail.dayKey,
        dayLabel: updatedAvail.dayLabel,
        isDayClosed: updatedAvail.isDayClosed,
        scheduleLabel: updatedAvail.scheduleLabel,
        totalTables: store.tableConfig.totalTables,
        slots: updatedAvail.slots,
      },
    });
  });

  // Cancel a guest's own table booking (immediately frees the table slot)
  app.delete('/api/bookings/:bookingId', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const bookingId = sanitizeText(req.params.bookingId, 40);
    const booking = store.tableBookings.find((b) => b.id === bookingId && b.guestId === guestId);
    if (!booking) {
      res.status(404).json({ error: 'Table booking not found.' });
      return;
    }

    booking.status = 'cancelled';
    persistStore();

    const updatedAvail = getSlotAvailabilityForDate(booking.bookingDate);
    res.json({
      booking: sanitizeBookingForClient(booking),
      guestToken,
      availability: {
        date: booking.bookingDate,
        dayKey: updatedAvail.dayKey,
        dayLabel: updatedAvail.dayLabel,
        isDayClosed: updatedAvail.isDayClosed,
        scheduleLabel: updatedAvail.scheduleLabel,
        totalTables: store.tableConfig.totalTables,
        slots: updatedAvail.slots,
      },
    });
  });

  // Fetch this visitor's persistent order history without any customer login
  app.get('/api/orders', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const orders = store.orders
      .filter((order) => order.guestId === guestId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .map(sanitizeOrderForClient);
    const deletedOrders = store.deletedOrders
      .filter((order) => order.guestId === guestId)
      .sort(
        (a, b) =>
          new Date(b.deletedAt || b.createdAt).getTime() -
          new Date(a.deletedAt || a.createdAt).getTime()
      )
      .slice(0, 15)
      .map(sanitizeOrderForClient);
    res.json({
      orders,
      deletedOrders,
      guestToken,
      gateways: getGatewayCapabilities(),
    });
  });

  // Delete / cancel a guest's own order (archived server-side for one-click Undo)
  app.delete('/api/orders/:orderId', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const orderId = sanitizeText(req.params.orderId, 40);
    const index = store.orders.findIndex((o) => o.id === orderId && o.guestId === guestId);
    if (index === -1) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    const deletedOrder = archiveDeletedOrder(index, 'customer');
    res.json({ deletedOrder: sanitizeOrderForClient(deletedOrder), guestToken });
  });

  // Undo deletion and restore a guest's own recently deleted order
  app.post('/api/orders/:orderId/restore', (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const orderId = sanitizeText(req.params.orderId, 40);
    const index = store.deletedOrders.findIndex((o) => o.id === orderId && o.guestId === guestId);
    if (index === -1) {
      res.status(404).json({ error: 'Deleted order not found or no longer available to undo.' });
      return;
    }

    const result = restoreArchivedOrder(index);
    if (result.conflictError || !result.order) {
      res.status(409).json({ error: result.conflictError || 'Unable to restore order.' });
      return;
    }
    res.json({ order: sanitizeOrderForClient(result.order), guestToken });
  });

  // Create order with server-authoritative pricing + UPI QR (`yaakshuu@fam`) + Razorpay/Cashfree reference
  app.post('/api/payments/create-order', async (req: Request, res: Response) => {
    const { guestId, guestToken } = resolveOrCreateGuest(req, res);
    const rawItems = Array.isArray(req.body?.items) ? req.body.items : [];
    const gateway: PaymentGateway = req.body?.gateway === 'cashfree' ? 'cashfree' : 'razorpay';
    const diningMode: DiningMode = req.body?.diningMode === 'takeaway' ? 'takeaway' : 'dine-in';
    const customerName = sanitizeText(req.body?.customerName, 60) || 'Cafe Guest';
    const customerPhone = sanitizeOptionalPhone(req.body?.customerPhone);
    const tableOrNotes = sanitizeText(req.body?.tableOrNotes, 180);

    if (rawItems.length === 0 || rawItems.length > 30) {
      res.status(400).json({ error: 'Your bag must contain between 1 and 30 menu items.' });
      return;
    }

    // Authoritative live check: block orders outside opening hours, when paused, or when items are sold out
    const openStatus = evaluateCafeOpenNow(store.weeklyHours);
    if (!openStatus.isOpenNow) {
      res.status(409).json({
        error:
          openStatus.closedReason ||
          "Ordering is currently closed outside IMMY's Coffee Cafe opening hours.",
        isOpenNow: false,
      });
      return;
    }

    const liveOps = await fetchLiveCafeOperations();
    if (!liveOps.acceptingOrders) {
      res.status(409).json({
        error: "IMMY's Coffee Cafe is temporarily paused for new orders. Please check back shortly.",
        acceptingOrders: false,
      });
      return;
    }

    const soldOutSet = new Set(liveOps.unavailableItemIds);
    const orderItems: OrderItem[] = [];
    const soldOutFound: Array<{ id: string; name: string }> = [];
    let subtotal = 0;

    for (const entry of rawItems) {
      const itemId = typeof entry?.itemId === 'string' ? entry.itemId : '';
      const qty = Number(entry?.quantity);
      const catalogItem = MENU_ITEMS_BY_ID[itemId];
      if (!catalogItem || !Number.isInteger(qty) || qty < 1 || qty > 25) {
        res.status(400).json({ error: 'Invalid menu item or quantity in your bag.' });
        return;
      }
      if (soldOutSet.has(catalogItem.id)) {
        soldOutFound.push({ id: catalogItem.id, name: catalogItem.name });
        continue;
      }
      const lineTotal = catalogItem.price * qty;
      subtotal += lineTotal;
      orderItems.push({
        itemId: catalogItem.id,
        name: catalogItem.name,
        price: catalogItem.price,
        quantity: qty,
        lineTotal,
      });
    }

    if (soldOutFound.length > 0) {
      res.status(409).json({
        error: `Cannot place order — currently sold out: ${soldOutFound.map((i) => i.name).join(', ')}. Please remove sold-out items from your bag.`,
        soldOutItemIds: soldOutFound.map((i) => i.id),
      });
      return;
    }

    const tax = Math.round(subtotal * 0.05);
    const total = subtotal + tax;
    const orderId = `IMMY-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

    let gatewayOrderId =
      gateway === 'razorpay'
        ? `rzp_ord_${crypto.randomBytes(6).toString('hex')}`
        : `cf_ord_${crypto.randomBytes(6).toString('hex')}`;
    let paymentSessionId: string | undefined;

    const caps = getGatewayCapabilities();
    try {
      if (gateway === 'razorpay' && caps.razorpayLive) {
        const liveId = await createRazorpayOrder(total, orderId);
        if (liveId) gatewayOrderId = liveId;
      } else if (gateway === 'cashfree' && caps.cashfreeLive) {
        const cfRes = await createCashfreeOrder(orderId, total, customerPhone, customerName);
        if (cfRes) {
          gatewayOrderId = cfRes.cfOrderId;
          paymentSessionId = cfRes.paymentSessionId;
        }
      }
    } catch {
      res.status(502).json({
        error: `Unable to reach ${gateway === 'razorpay' ? 'Razorpay' : 'Cashfree'} right now. Please try again.`,
      });
      return;
    }

    const upiUri = buildUpiUri(total, `${orderId} IMMYs Coffee Cafe`);
    const qrDataUrl = await QRCode.toDataURL(upiUri, {
      width: 300,
      margin: 2,
      color: { dark: '#1D1815', light: '#FAF8F5' },
    });

    const order: CafeOrder = {
      id: orderId,
      guestId,
      customerName,
      customerPhone,
      diningMode,
      tableOrNotes,
      items: orderItems,
      subtotal,
      tax,
      total,
      gateway,
      gatewayOrderId,
      paymentStatus: 'PENDING',
      kitchenStatus: 'received',
      verificationMode: 'pending',
      verificationMessage: `Scan the official IMMY's Coffee Cafe UPI QR to pay ₹${total}, then enter your 12-digit UTR number to confirm.`,
      createdAt: new Date().toISOString(),
    };

    store.orders.unshift(order);
    persistStore();

    res.status(201).json({
      order: sanitizeOrderForClient(order),
      qrDataUrl,
      guestToken,
      paymentSessionId,
      gateways: caps,
    });
  });

  // Confirm transaction with 12-digit UPI UTR + Razorpay / Cashfree verification
  app.post('/api/payments/verify', async (req: Request, res: Response) => {
    const { guestId } = resolveOrCreateGuest(req, res);
    const orderId = sanitizeText(req.body?.orderId, 40);
    const gateway: PaymentGateway = req.body?.gateway === 'cashfree' ? 'cashfree' : 'razorpay';
    const upiRefUtr = sanitizeText(req.body?.upiRefUtr, 40);
    const razorpayPaymentId = sanitizeText(req.body?.razorpayPaymentId, 64);
    const razorpaySignature = sanitizeText(req.body?.razorpaySignature, 128);

    const order = store.orders.find((o) => o.id === orderId && o.guestId === guestId);
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    if (order.paymentStatus === 'PAID_VERIFIED') {
      res.json({ order: sanitizeOrderForClient(order), verified: true });
      return;
    }

    order.gateway = gateway;
    const caps = getGatewayCapabilities();

    const cleanedUtr = upiRefUtr.replace(/\D/g, '');
    if (!/^\d{12}$/.test(cleanedUtr)) {
      res.status(400).json({
        error:
          'Please enter the exact 12-digit UPI UTR number from your payment app (GPay, PhonePe, Paytm, or FamPay) to confirm this transaction.',
      });
      return;
    }

    if (store.usedUtrs[cleanedUtr] && store.usedUtrs[cleanedUtr] !== order.id) {
      res.status(409).json({
        error: 'This 12-digit UTR number has already been used for another order.',
      });
      return;
    }

    if (gateway === 'razorpay' && caps.razorpayLive && razorpayPaymentId) {
      const secret = process.env.RAZORPAY_KEY_SECRET!.trim();
      if (razorpaySignature) {
        const expected = crypto
          .createHmac('sha256', secret)
          .update(`${order.gatewayOrderId}|${razorpayPaymentId}`)
          .digest('hex');
        const sigBuf = Buffer.from(razorpaySignature, 'utf8');
        const expBuf = Buffer.from(expected, 'utf8');
        if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
          res.status(400).json({ error: 'Razorpay signature verification failed.' });
          return;
        }
      }

      const rzpPayment = await fetchRazorpayPaymentStatus(razorpayPaymentId);
      if (
        !rzpPayment ||
        rzpPayment.status !== 'captured' ||
        rzpPayment.amount !== Math.round(order.total * 100)
      ) {
        res.status(400).json({
          error: 'Razorpay has not confirmed capture for this payment yet.',
        });
        return;
      }

      store.usedUtrs[cleanedUtr] = order.id;
      order.paymentStatus = 'PAID_VERIFIED';
      order.gatewayPaymentId = rzpPayment.id;
      order.upiRefUtr = cleanedUtr;
      order.verificationMode = 'live-razorpay';
      order.verificationMessage = `UTR ${cleanedUtr} confirmed & verified live via Razorpay (${rzpPayment.id}).`;
      order.verifiedAt = new Date().toISOString();
      persistStore();
      res.json({ order: sanitizeOrderForClient(order), verified: true });
      return;
    }

    if (gateway === 'cashfree' && caps.cashfreeLive) {
      const cfPayments = await fetchCashfreeOrderPayments(order.id);
      const successTx = cfPayments?.find(
        (tx) =>
          tx.payment_status === 'SUCCESS' &&
          Math.abs(Number(tx.payment_amount || 0) - order.total) < 0.01
      );
      if (successTx) {
        store.usedUtrs[cleanedUtr] = order.id;
        order.paymentStatus = 'PAID_VERIFIED';
        order.gatewayPaymentId = String(successTx.cf_payment_id || '');
        order.upiRefUtr = cleanedUtr;
        order.verificationMode = 'live-cashfree';
        order.verificationMessage = `UTR ${cleanedUtr} confirmed & verified live via Cashfree (Ref ${successTx.cf_payment_id}).`;
        order.verifiedAt = new Date().toISOString();
        persistStore();
        res.json({ order: sanitizeOrderForClient(order), verified: true });
        return;
      }
    }

    store.usedUtrs[cleanedUtr] = order.id;
    order.upiRefUtr = cleanedUtr;
    order.gatewayPaymentId =
      gateway === 'razorpay'
        ? `rzp_utr_${cleanedUtr.slice(-8)}`
        : `cf_utr_${cleanedUtr.slice(-8)}`;
    order.paymentStatus = 'PAID_VERIFIED';
    order.verificationMode = 'upi-utr-confirmed';
    order.verificationMessage = `Transaction confirmed with UTR ${cleanedUtr} via ${
      gateway === 'razorpay' ? 'Razorpay' : 'Cashfree'
    } UPI QR verification.`;
    order.verifiedAt = new Date().toISOString();
    persistStore();

    res.json({ order: sanitizeOrderForClient(order), verified: true });
  });

  // Re-check guest order payment status
  app.get('/api/payments/status/:orderId', async (req: Request, res: Response) => {
    const { guestId } = resolveOrCreateGuest(req, res);
    const orderId = sanitizeText(req.params.orderId, 40);
    const order = store.orders.find((o) => o.id === orderId && o.guestId === guestId);
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    const caps = getGatewayCapabilities();
    if (order.paymentStatus === 'PENDING' && order.gateway === 'cashfree' && caps.cashfreeLive) {
      const cfPayments = await fetchCashfreeOrderPayments(order.id);
      const successTx = cfPayments?.find(
        (tx) =>
          tx.payment_status === 'SUCCESS' &&
          Math.abs(Number(tx.payment_amount || 0) - order.total) < 0.01
      );
      if (successTx) {
        order.paymentStatus = 'PAID_VERIFIED';
        order.gatewayPaymentId = String(successTx.cf_payment_id || '');
        order.upiRefUtr = successTx.bank_reference || order.upiRefUtr;
        order.verificationMode = 'live-cashfree';
        order.verificationMessage = `Verified live via Cashfree (Ref ${successTx.cf_payment_id}).`;
        order.verifiedAt = new Date().toISOString();
        persistStore();
      }
    }

    res.json({
      order: sanitizeOrderForClient(order),
      checkedAt: new Date().toISOString(),
      gateways: caps,
    });
  });

  // ---------------------------------------------------------------------------
  // Staff-Only Routes (Strictly Verified Owner OR Active Appointed Manager)
  // ---------------------------------------------------------------------------
  app.get('/api/staff/orders', requireStaffAuth, (req: StaffAuthedRequest, res: Response) => {
    const orders = [...store.orders]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .map(sanitizeOrderForClient);
    const deletedOrders = [...store.deletedOrders]
      .sort(
        (a, b) =>
          new Date(b.deletedAt || b.createdAt).getTime() -
          new Date(a.deletedAt || a.createdAt).getTime()
      )
      .slice(0, 25)
      .map(sanitizeOrderForClient);
    const confirmedOrders = orders.filter((o) => o.paymentStatus === 'PAID_VERIFIED');
    const verifiedRevenue = confirmedOrders.reduce((sum, o) => sum + o.total, 0);

    res.json({
      role: req.staffRole,
      orders,
      deletedOrders,
      summary: {
        totalOrders: orders.length,
        confirmedCount: confirmedOrders.length,
        pendingCount: orders.length - confirmedOrders.length,
        verifiedRevenue,
      },
    });
  });

  app.delete(
    '/api/staff/orders/:orderId',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const orderId = sanitizeText(req.params.orderId, 40);
      const index = store.orders.findIndex((o) => o.id === orderId);
      if (index === -1) {
        res.status(404).json({ error: 'Order not found.' });
        return;
      }

      const deletedOrder = archiveDeletedOrder(index, req.staffRole || 'staff');
      res.json({ deletedOrder: sanitizeOrderForClient(deletedOrder) });
    }
  );

  app.post(
    '/api/staff/orders/:orderId/restore',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const orderId = sanitizeText(req.params.orderId, 40);
      const index = store.deletedOrders.findIndex((o) => o.id === orderId);
      if (index === -1) {
        res.status(404).json({ error: 'Deleted order not found or no longer available to undo.' });
        return;
      }

      const result = restoreArchivedOrder(index);
      if (result.conflictError || !result.order) {
        res.status(409).json({ error: result.conflictError || 'Unable to restore order.' });
        return;
      }
      result.order.updatedByStaffRole = req.staffRole;
      persistStore();
      res.json({ order: sanitizeOrderForClient(result.order) });
    }
  );

  app.patch(
    '/api/staff/orders/:orderId/kitchen',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const orderId = sanitizeText(req.params.orderId, 40);
      const nextStatus = req.body?.kitchenStatus as KitchenStatus;
      const validStatuses: KitchenStatus[] = ['received', 'preparing', 'ready', 'completed'];
      if (!validStatuses.includes(nextStatus)) {
        res.status(400).json({ error: 'Invalid kitchen status.' });
        return;
      }

      const order = store.orders.find((o) => o.id === orderId);
      if (!order) {
        res.status(404).json({ error: 'Order not found.' });
        return;
      }

      order.kitchenStatus = nextStatus;
      order.updatedByStaffRole = req.staffRole;
      persistStore();
      res.json({ order: sanitizeOrderForClient(order) });
    }
  );

  app.post(
    '/api/staff/orders/:orderId/confirm-utr',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const orderId = sanitizeText(req.params.orderId, 40);
      const gateway: PaymentGateway = req.body?.gateway === 'cashfree' ? 'cashfree' : 'razorpay';
      const cleanedUtr = sanitizeText(req.body?.upiRefUtr, 40).replace(/\D/g, '');

      if (!/^\d{12}$/.test(cleanedUtr)) {
        res.status(400).json({ error: 'Enter a valid 12-digit UPI UTR number.' });
        return;
      }

      const order = store.orders.find((o) => o.id === orderId);
      if (!order) {
        res.status(404).json({ error: 'Order not found.' });
        return;
      }

      if (store.usedUtrs[cleanedUtr] && store.usedUtrs[cleanedUtr] !== order.id) {
        res.status(409).json({
          error: 'This 12-digit UTR number is already recorded for another order.',
        });
        return;
      }

      store.usedUtrs[cleanedUtr] = order.id;
      order.gateway = gateway;
      order.upiRefUtr = cleanedUtr;
      order.gatewayPaymentId =
        gateway === 'razorpay'
          ? `rzp_utr_${cleanedUtr.slice(-8)}`
          : `cf_utr_${cleanedUtr.slice(-8)}`;
      order.paymentStatus = 'PAID_VERIFIED';
      order.verificationMode = 'upi-utr-confirmed';
      order.verificationMessage = `UTR ${cleanedUtr} confirmed by cafe ${req.staffRole || 'staff'} via ${
        gateway === 'razorpay' ? 'Razorpay' : 'Cashfree'
      }.`;
      order.verifiedAt = new Date().toISOString();
      order.updatedByStaffRole = req.staffRole;
      persistStore();

      res.json({ order: sanitizeOrderForClient(order) });
    }
  );

  // Sync live Cafe Operations (sold-out items, acceptingOrders) immediately to server store
  app.put(
    '/api/staff/operations',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const acceptingOrders =
        typeof req.body?.acceptingOrders === 'boolean' ? req.body.acceptingOrders : true;
      const prepTimeMinutes = Math.min(
        120,
        Math.max(5, Math.round(Number(req.body?.prepTimeMinutes) || 15))
      );
      const dailySpecialNotice = sanitizeText(req.body?.dailySpecialNotice, 180);
      const unavailableItemIds = normalizeUnavailableIds(req.body?.unavailableItemIds);

      const nextOps: StoredCafeOperations = {
        acceptingOrders,
        prepTimeMinutes,
        dailySpecialNotice,
        unavailableItemIds,
        updatedByUid: req.staffUid || 'staff',
        updatedByRole: req.staffRole === 'manager' ? 'manager' : 'owner',
        updatedAt: new Date().toISOString(),
      };

      store.operations = nextOps;
      persistStore();
      res.json({
        operations: {
          acceptingOrders: nextOps.acceptingOrders,
          prepTimeMinutes: nextOps.prepTimeMinutes,
          dailySpecialNotice: nextOps.dailySpecialNotice,
          unavailableItemIds: nextOps.unavailableItemIds,
          updatedByRole: nextOps.updatedByRole,
        },
      });
    }
  );

  // Owner & Manager: Update Weekly Opening Hours Table (Mon–Sun IST)
  app.put(
    '/api/staff/hours',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const validated = validateWeeklyHoursPayload(req.body?.weeklyHours);
      if (validated.error || !validated.weeklyHours) {
        res.status(400).json({ error: validated.error || 'Invalid weekly opening hours.' });
        return;
      }

      store.weeklyHours = validated.weeklyHours;
      persistStore();
      res.json({
        weeklyHours: store.weeklyHours,
        openStatus: evaluateCafeOpenNow(store.weeklyHours),
      });
    }
  );

  // Owner & Manager: List all Garden Table Bookings + live capacity stats
  app.get(
    '/api/staff/bookings',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const today = getTodayIstIsoDate();

      const bookings = [...store.tableBookings]
        .sort((a, b) => {
          if (a.bookingDate !== b.bookingDate) {
            return b.bookingDate.localeCompare(a.bookingDate);
          }
          const diffSlot = parseSlot12ToMinutes(a.timeSlot) - parseSlot12ToMinutes(b.timeSlot);
          if (diffSlot !== 0) return diffSlot;
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        })
        .map(sanitizeBookingForClient);

      const activeBookings = bookings.filter(
        (b) => b.status === 'confirmed' || b.status === 'seated'
      );
      const todayCount = activeBookings.filter((b) => b.bookingDate === today).length;
      const confirmedCount = bookings.filter((b) => b.status === 'confirmed').length;
      const seatedCount = bookings.filter((b) => b.status === 'seated').length;
      const totalUpcomingGuests = activeBookings
        .filter((b) => b.bookingDate >= today)
        .reduce((sum, b) => sum + b.partySize, 0);

      res.json({
        role: req.staffRole,
        today,
        bookings,
        summary: {
          totalTables: store.tableConfig.totalTables,
          totalBookings: bookings.length,
          todayCount,
          confirmedCount,
          seatedCount,
          totalUpcomingGuests,
        },
      });
    }
  );

  // Owner & Manager: Update table booking status (confirmed / seated / completed / cancelled / no-show)
  app.patch(
    '/api/staff/bookings/:bookingId/status',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const bookingId = sanitizeText(req.params.bookingId, 40);
      const nextStatus = req.body?.status as TableBookingStatus;
      const validStatuses: TableBookingStatus[] = [
        'confirmed',
        'seated',
        'completed',
        'cancelled',
        'no-show',
      ];
      if (!validStatuses.includes(nextStatus)) {
        res.status(400).json({ error: 'Invalid booking status.' });
        return;
      }

      const booking = store.tableBookings.find((b) => b.id === bookingId);
      if (!booking) {
        res.status(404).json({ error: 'Table booking not found.' });
        return;
      }

      const becomingActive =
        (nextStatus === 'confirmed' || nextStatus === 'seated') &&
        booking.status !== 'confirmed' &&
        booking.status !== 'seated';

      if (becomingActive) {
        const reassigned = allocateFreeTableNumbers(
          booking.bookingDate,
          booking.timeSlot,
          booking.tablesAllocated,
          booking.id
        );
        if (!reassigned) {
          res.status(409).json({
            error: `Cannot reactivate booking — no free garden tables left for ${booking.timeSlot} on ${booking.bookingDate}.`,
          });
          return;
        }
        booking.tableNumbers = reassigned;
      }

      booking.status = nextStatus;
      booking.updatedByStaffRole = req.staffRole;
      persistStore();
      res.json({ booking: sanitizeBookingForClient(booking) });
    }
  );

  // Owner & Manager: Delete a table booking record
  app.delete(
    '/api/staff/bookings/:bookingId',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const bookingId = sanitizeText(req.params.bookingId, 40);
      const index = store.tableBookings.findIndex((b) => b.id === bookingId);
      if (index === -1) {
        res.status(404).json({ error: 'Table booking not found.' });
        return;
      }

      const [deletedBooking] = store.tableBookings.splice(index, 1);
      persistStore();
      res.json({ deletedBooking: sanitizeBookingForClient(deletedBooking) });
    }
  );

  // Owner & Manager: Configure total limited garden tables available per slot (1–40)
  app.put(
    '/api/staff/table-config',
    requireStaffAuth,
    (req: StaffAuthedRequest, res: Response) => {
      const nextTotal = Math.round(Number(req.body?.totalTables));
      if (!Number.isInteger(nextTotal) || nextTotal < 1 || nextTotal > 40) {
        res.status(400).json({ error: 'Total garden tables must be a whole number between 1 and 40.' });
        return;
      }
      store.tableConfig.totalTables = nextTotal;
      persistStore();
      res.json({ totalTables: nextTotal });
    }
  );

  // Frontend serving (Vite dev middleware in dev, dist/ in prod)
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`IMMY's COFFEE CAFE server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
