# Security Specification — IMMY's COFFEE CAFE RBAC (Owner & Managers)

## 1. Data Invariants
1. **Exclusive Owner Identity**: Only a Firebase-authenticated user with verified email `koulyaaksh3016@gmail.com` (`request.auth.token.email.lower() == 'koulyaaksh3016@gmail.com' && request.auth.token.email_verified == true`) is recognized as the Owner.
2. **Owner-Only Manager Appointment**: Only the Owner can create, list, update, revoke, or delete records in `/managers/{managerId}`. A manager can never appoint another manager, modify their own status, or view other managers' PII.
3. **Self-Check PII Isolation**: An authenticated non-owner user may ONLY `get` the single `/managers/{managerId}` document whose ID matches their own normalized verified email (`emailToId(request.auth.token.email)`), strictly to determine if they are an active manager.
4. **Synchronous Revocation**: Setting a manager's `status` to `'revoked'` or deleting their `/managers/{managerId}` doc immediately revokes their ability to write `/cafeSettings/operations` or read/write `/staffNotes/{noteId}`.
5. **Strict Schema & Immutability**: All documents enforce `hasAll` + `hasOnly` on create, `affectedKeys().hasOnly(...)` on action-based updates, `request.time` server timestamps, bounded string lengths, bounded arrays (`<= 200`), and safe document IDs (`^[a-zA-Z0-9_\-]+$`).
6. **Terminal State Locking**: Once a `/staffNotes/{noteId}` document transitions to `status: 'resolved'`, managers cannot modify it further; only the Owner can reopen or override resolved notes.

## 2. The "Dirty Dozen" Attack Payloads (All Must Return PERMISSION_DENIED)
1. **Spoofed Unverified Owner Email**: Signed-in user with `email: 'koulyaaksh3016@gmail.com'` and `email_verified: false` attempts to create `/managers/bob_gmail_com`.
2. **Manager Self-Appointment**: Regular user (`alice@gmail.com`) attempts to create `/managers/alice_gmail_com` with `role: 'manager', status: 'active'`.
3. **Manager Appointing Another Manager**: Active manager (`mgr@gmail.com`) attempts to create `/managers/friend_gmail_com`.
4. **Manager Listing Other Managers (PII Leak)**: Active manager attempts `list` on `/managers` or `get` on `/managers/other_gmail_com`.
5. **Revoked Manager Writing Operations**: Revoked manager (`status: 'revoked'`) attempts to update `/cafeSettings/operations`.
6. **Shadow Field Injection on Manager Create**: Owner attempts to create `/managers/mgr_gmail_com` with extra ghost field `isSuperOwner: true`.
7. **Owner Email Mismatch on Manager Create**: Owner attempts to set `appointedByEmail: 'fake@gmail.com'` or `appointedByUid: 'wrong-uid'`.
8. **Backdated Timestamp Forgery**: Manager attempts to create `/staffNotes/note_1` with client-supplied past timestamp instead of `request.time`.
9. **ID Poisoning / Denial of Wallet**: Owner attempts to create `/managers/bad$id!with*symbols` or a 200-char ID.
10. **Unbounded Array / Value Poisoning on Settings**: Manager attempts to write 210 items or an integer element into `cafeSettings/operations.unavailableItemIds` or set `prepTimeMinutes: 999`.
11. **Role Escalation in Staff Note**: Active manager attempts to create `/staffNotes/note_2` with `authorRole: 'owner'` or another user's `authorUid`.
12. **Terminal State Violation**: Active manager attempts to edit or reopen a `/staffNotes/{noteId}` whose existing `status` is `'resolved'`.
